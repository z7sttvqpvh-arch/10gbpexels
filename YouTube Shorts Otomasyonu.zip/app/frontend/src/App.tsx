import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Index from './pages/Index';
import ChannelsPage from './pages/ChannelsPage';
import ChannelDetailPage from './pages/ChannelDetailPage';
import EvolutionCenterPage from './pages/EvolutionCenterPage';
import NicheLabPage from './pages/NicheLabPage';
import JobsPage from './pages/JobsPage';
import SettingsPage from './pages/SettingsPage';
import AutomationPage from './pages/AutomationPage';
import ChannelProposalsPage from './pages/ChannelProposalsPage';
import StrategyGuidePage from './pages/StrategyGuidePage';
import AuthCallback from './pages/AuthCallback';
import AuthError from './pages/AuthError';

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <Routes>
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/auth/error" element={<AuthError />} />
          <Route element={<Layout />}>
            <Route path="/" element={<Index />} />
            <Route path="/channels" element={<ChannelsPage />} />
            <Route path="/channels/:id" element={<ChannelDetailPage />} />
            <Route path="/evolution" element={<EvolutionCenterPage />} />
            <Route path="/niche-lab" element={<NicheLabPage />} />
            <Route path="/automation" element={<AutomationPage />} />
            <Route path="/proposals" element={<ChannelProposalsPage />} />
            <Route path="/strategy" element={<StrategyGuidePage />} />
            <Route path="/jobs" element={<JobsPage />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;