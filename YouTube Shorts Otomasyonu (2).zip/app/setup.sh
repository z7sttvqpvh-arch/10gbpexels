#!/usr/bin/env bash
# ============================================================================
#  YouTube Shorts Otomasyon Sistemi — Otomatik Kurulum Scripti
#  Desteklenen OS: Ubuntu 20.04 / 22.04 / 24.04, Debian 11/12
# ============================================================================

set -euo pipefail

# ── Renkler ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# ── Değişkenler ──────────────────────────────────────────────────────────────
APP_NAME="youtube-shorts-automation"
APP_DIR="/opt/${APP_NAME}"
BACKEND_PORT=8002
FRONTEND_PORT=3000
DB_NAME="youtube_shorts"
DB_USER="ytshorts"
DB_PASS=""
DOMAIN=""
ENABLE_SSL=false
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Yardımcı Fonksiyonlar ───────────────────────────────────────────────────
log_info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[✓]${NC} $1"; }
log_warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
log_error()   { echo -e "${RED}[✗]${NC} $1"; }
log_step()    { echo -e "\n${PURPLE}${BOLD}━━━ $1 ━━━${NC}\n"; }

check_root() {
  if [[ $EUID -ne 0 ]]; then
    log_error "Bu script root yetkisi gerektirir. 'sudo bash setup.sh' ile çalıştırın."
    exit 1
  fi
}

print_banner() {
  echo -e "${CYAN}${BOLD}"
  echo "╔══════════════════════════════════════════════════════════════╗"
  echo "║                                                              ║"
  echo "║   🚀 YouTube Shorts Otomasyon Sistemi                       ║"
  echo "║      Otomatik Kurulum Scripti v1.0                          ║"
  echo "║                                                              ║"
  echo "╚══════════════════════════════════════════════════════════════╝"
  echo -e "${NC}"
}

# ── Kullanıcı Bilgileri ─────────────────────────────────────────────────────
collect_info() {
  log_step "Adım 0/7 — Kurulum Bilgileri"

  # Domain
  read -rp "$(echo -e "${CYAN}Domain adı (boş bırakırsanız IP ile erişilir):${NC} ")" DOMAIN
  DOMAIN="${DOMAIN:-}"

  # SSL
  if [[ -n "$DOMAIN" ]]; then
    read -rp "$(echo -e "${CYAN}SSL sertifikası kurulsun mu? (e/h) [e]:${NC} ")" ssl_choice
    ssl_choice="${ssl_choice:-e}"
    [[ "$ssl_choice" == "e" || "$ssl_choice" == "E" ]] && ENABLE_SSL=true
  fi

  # Veritabanı şifresi
  DB_PASS=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 20)
  log_info "Veritabanı şifresi otomatik oluşturuldu."

  # Özet
  echo ""
  echo -e "${BOLD}Kurulum Özeti:${NC}"
  echo -e "  Uygulama dizini : ${GREEN}${APP_DIR}${NC}"
  echo -e "  Veritabanı      : ${GREEN}${DB_NAME}${NC} (kullanıcı: ${DB_USER})"
  echo -e "  Backend port     : ${GREEN}${BACKEND_PORT}${NC}"
  echo -e "  Domain           : ${GREEN}${DOMAIN:-'(IP ile erişim)'}${NC}"
  echo -e "  SSL              : ${GREEN}${ENABLE_SSL}${NC}"
  echo ""

  read -rp "$(echo -e "${YELLOW}Devam etmek istiyor musunuz? (e/h) [e]:${NC} ")" confirm
  confirm="${confirm:-e}"
  if [[ "$confirm" != "e" && "$confirm" != "E" ]]; then
    log_warn "Kurulum iptal edildi."
    exit 0
  fi
}

# ── 1. Sistem Paketleri ─────────────────────────────────────────────────────
install_system_packages() {
  log_step "Adım 1/7 — Sistem Paketleri Kuruluyor"

  apt-get update -qq
  apt-get install -y -qq \
    curl wget git unzip build-essential \
    software-properties-common apt-transport-https \
    ca-certificates gnupg lsb-release \
    nginx certbot python3-certbot-nginx \
    postgresql postgresql-contrib \
    python3 python3-pip python3-venv \
    supervisor

  log_success "Sistem paketleri kuruldu."
}

# ── 2. Node.js ──────────────────────────────────────────────────────────────
install_nodejs() {
  log_step "Adım 2/7 — Node.js & pnpm Kuruluyor"

  if command -v node &>/dev/null; then
    NODE_VER=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [[ "$NODE_VER" -ge 18 ]]; then
      log_info "Node.js $(node -v) zaten kurulu."
    else
      log_warn "Node.js sürümü eski, güncelleniyor..."
      curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
      apt-get install -y -qq nodejs
    fi
  else
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y -qq nodejs
  fi

  # pnpm
  if ! command -v pnpm &>/dev/null; then
    npm install -g pnpm
  fi

  log_success "Node.js $(node -v) ve pnpm $(pnpm -v) hazır."
}

# ── 3. PostgreSQL ────────────────────────────────────────────────────────────
setup_database() {
  log_step "Adım 3/7 — PostgreSQL Veritabanı Kuruluyor"

  systemctl enable postgresql
  systemctl start postgresql

  # Kullanıcı ve veritabanı oluştur
  sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASS}';"

  sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};"

  sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"

  log_success "PostgreSQL veritabanı '${DB_NAME}' hazır."
}

# ── 4. Uygulama Dosyaları ───────────────────────────────────────────────────
deploy_application() {
  log_step "Adım 4/7 — Uygulama Dosyaları Kopyalanıyor"

  mkdir -p "${APP_DIR}"

  # Script'in bulunduğu dizinden kopyala
  if [[ -d "${SCRIPT_DIR}/app" ]]; then
    cp -r "${SCRIPT_DIR}/app/"* "${APP_DIR}/"
    log_success "Dosyalar ${APP_DIR} dizinine kopyalandı."
  else
    log_error "Uygulama dosyaları bulunamadı! '${SCRIPT_DIR}/app' dizini mevcut değil."
    log_info "Lütfen bu scripti proje kök dizininde çalıştırın."
    exit 1
  fi
}

# ── 5. Backend Kurulumu ─────────────────────────────────────────────────────
setup_backend() {
  log_step "Adım 5/7 — Backend Kuruluyor"

  cd "${APP_DIR}/backend"

  # Python sanal ortam
  python3 -m venv venv
  source venv/bin/activate

  # Bağımlılıklar
  if [[ -f requirements.txt ]]; then
    pip install --quiet --upgrade pip
    pip install --quiet -r requirements.txt
  else
    pip install --quiet --upgrade pip
    pip install --quiet \
      fastapi uvicorn[standard] sqlalchemy[asyncio] asyncpg \
      alembic pydantic python-dotenv httpx aiohttp
  fi

  # .env dosyası oluştur
  cat > .env <<EOF
# YouTube Shorts Otomasyon — Backend Yapılandırması
# Otomatik oluşturuldu: $(date '+%Y-%m-%d %H:%M:%S')

DATABASE_URL=postgresql+asyncpg://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}
DATABASE_URL_SYNC=postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}

# Sunucu
HOST=0.0.0.0
PORT=${BACKEND_PORT}
DEBUG=false
WORKERS=2

# Güvenlik
SECRET_KEY=$(openssl rand -hex 32)
CORS_ORIGINS=*

# API Anahtarları (kurulumdan sonra Settings sayfasından da ekleyebilirsiniz)
# YOUTUBE_API_KEY=
# GEMINI_API_KEY=
# ELEVENLABS_API_KEY=
# PEXELS_API_KEY=
EOF

  # Veritabanı migration
  if [[ -f alembic.ini ]]; then
    alembic upgrade head 2>/dev/null || log_warn "Migration atlandı (alembic.ini yapılandırması kontrol edin)"
  fi

  deactivate

  # Supervisor yapılandırması
  cat > /etc/supervisor/conf.d/${APP_NAME}-api.conf <<EOF
[program:${APP_NAME}-api]
command=${APP_DIR}/backend/venv/bin/uvicorn main:app --host 0.0.0.0 --port ${BACKEND_PORT} --workers 2
directory=${APP_DIR}/backend
user=www-data
autostart=true
autorestart=true
stderr_logfile=/var/log/${APP_NAME}-api.err.log
stdout_logfile=/var/log/${APP_NAME}-api.out.log
environment=PATH="${APP_DIR}/backend/venv/bin:%(ENV_PATH)s"
EOF

  log_success "Backend kurulumu tamamlandı."
}

# ── 6. Frontend Kurulumu ────────────────────────────────────────────────────
setup_frontend() {
  log_step "Adım 6/7 — Frontend Derleniyor"

  cd "${APP_DIR}/frontend"

  # API URL'yi ayarla
  if [[ -n "$DOMAIN" ]]; then
    API_BASE="https://${DOMAIN}/api"
  else
    SERVER_IP=$(hostname -I | awk '{print $1}')
    API_BASE="http://${SERVER_IP}/api"
  fi

  # .env dosyası
  cat > .env <<EOF
VITE_API_BASE_URL=${API_BASE}
EOF

  # Bağımlılıkları kur ve derle
  pnpm install --frozen-lockfile 2>/dev/null || pnpm install
  pnpm run build

  log_success "Frontend derlendi (dist/ dizini hazır)."
}

# ── 7. Nginx & SSL ──────────────────────────────────────────────────────────
setup_nginx() {
  log_step "Adım 7/7 — Nginx Yapılandırılıyor"

  SERVER_NAME="${DOMAIN:-_}"

  cat > /etc/nginx/sites-available/${APP_NAME} <<EOF
server {
    listen 80;
    server_name ${SERVER_NAME};

    # Güvenlik başlıkları
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Gzip sıkıştırma
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml text/javascript;
    gzip_min_length 256;

    # Frontend (React SPA)
    location / {
        root ${APP_DIR}/frontend/dist;
        try_files \$uri \$uri/ /index.html;

        # Statik dosya önbellekleme
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
            expires 30d;
            add_header Cache-Control "public, immutable";
        }
    }

    # Backend API proxy
    location /api/ {
        rewrite ^/api/(.*) /\$1 break;
        proxy_pass http://127.0.0.1:${BACKEND_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
    }

    # Sağlık kontrolü
    location /health {
        proxy_pass http://127.0.0.1:${BACKEND_PORT}/health;
    }
}
EOF

  # Varsayılan nginx yapılandırmasını kaldır
  rm -f /etc/nginx/sites-enabled/default

  # Aktifleştir
  ln -sf /etc/nginx/sites-available/${APP_NAME} /etc/nginx/sites-enabled/

  # Nginx yapılandırmasını test et
  nginx -t

  # SSL
  if [[ "$ENABLE_SSL" == true && -n "$DOMAIN" ]]; then
    log_info "SSL sertifikası alınıyor..."
    certbot --nginx -d "${DOMAIN}" --non-interactive --agree-tos --email "admin@${DOMAIN}" || \
      log_warn "SSL sertifikası alınamadı. Manuel olarak 'certbot --nginx -d ${DOMAIN}' çalıştırın."
  fi

  # Servisleri yeniden başlat
  systemctl restart nginx
  supervisorctl reread
  supervisorctl update
  supervisorctl restart ${APP_NAME}-api 2>/dev/null || supervisorctl start ${APP_NAME}-api

  log_success "Nginx yapılandırıldı ve servisler başlatıldı."
}

# ── Dosya İzinleri ──────────────────────────────────────────────────────────
fix_permissions() {
  chown -R www-data:www-data "${APP_DIR}"
  chmod -R 755 "${APP_DIR}"
  chmod 600 "${APP_DIR}/backend/.env"
  chmod 600 "${APP_DIR}/frontend/.env"
}

# ── Kurulum Özeti ────────────────────────────────────────────────────────────
print_summary() {
  SERVER_IP=$(hostname -I | awk '{print $1}')

  echo ""
  echo -e "${GREEN}${BOLD}"
  echo "╔══════════════════════════════════════════════════════════════╗"
  echo "║                                                              ║"
  echo "║   ✅ Kurulum Başarıyla Tamamlandı!                          ║"
  echo "║                                                              ║"
  echo "╚══════════════════════════════════════════════════════════════╝"
  echo -e "${NC}"

  echo -e "${BOLD}Erişim Bilgileri:${NC}"
  if [[ -n "$DOMAIN" ]]; then
    if [[ "$ENABLE_SSL" == true ]]; then
      echo -e "  🌐 Web Arayüzü  : ${GREEN}https://${DOMAIN}${NC}"
      echo -e "  🔌 API Endpoint  : ${GREEN}https://${DOMAIN}/api${NC}"
    else
      echo -e "  🌐 Web Arayüzü  : ${GREEN}http://${DOMAIN}${NC}"
      echo -e "  🔌 API Endpoint  : ${GREEN}http://${DOMAIN}/api${NC}"
    fi
  else
    echo -e "  🌐 Web Arayüzü  : ${GREEN}http://${SERVER_IP}${NC}"
    echo -e "  🔌 API Endpoint  : ${GREEN}http://${SERVER_IP}/api${NC}"
  fi

  echo ""
  echo -e "${BOLD}Veritabanı Bilgileri:${NC}"
  echo -e "  📦 Veritabanı    : ${CYAN}${DB_NAME}${NC}"
  echo -e "  👤 Kullanıcı     : ${CYAN}${DB_USER}${NC}"
  echo -e "  🔑 Şifre         : ${CYAN}${DB_PASS}${NC}"

  echo ""
  echo -e "${BOLD}Dosya Konumları:${NC}"
  echo -e "  📁 Uygulama      : ${CYAN}${APP_DIR}${NC}"
  echo -e "  📝 Backend .env  : ${CYAN}${APP_DIR}/backend/.env${NC}"
  echo -e "  📝 Frontend .env : ${CYAN}${APP_DIR}/frontend/.env${NC}"
  echo -e "  📋 API Log       : ${CYAN}/var/log/${APP_NAME}-api.out.log${NC}"
  echo -e "  📋 Hata Log      : ${CYAN}/var/log/${APP_NAME}-api.err.log${NC}"

  echo ""
  echo -e "${BOLD}Faydalı Komutlar:${NC}"
  echo -e "  ${YELLOW}# Servisleri kontrol et${NC}"
  echo -e "  sudo supervisorctl status ${APP_NAME}-api"
  echo -e "  sudo systemctl status nginx"
  echo ""
  echo -e "  ${YELLOW}# Servisleri yeniden başlat${NC}"
  echo -e "  sudo supervisorctl restart ${APP_NAME}-api"
  echo -e "  sudo systemctl restart nginx"
  echo ""
  echo -e "  ${YELLOW}# Logları izle${NC}"
  echo -e "  sudo tail -f /var/log/${APP_NAME}-api.out.log"
  echo ""
  echo -e "  ${YELLOW}# Backend .env düzenle${NC}"
  echo -e "  sudo nano ${APP_DIR}/backend/.env"
  echo ""

  echo -e "${PURPLE}${BOLD}Sonraki Adımlar:${NC}"
  echo -e "  1. Web arayüzüne girin ve ${GREEN}Kurulum Rehberi${NC} sayfasını takip edin"
  echo -e "  2. Settings sayfasından YouTube API anahtarınızı ekleyin"
  echo -e "  3. Niche Lab'dan niş keşfi yapın"
  echo -e "  4. Otomasyonu başlatın!"
  echo ""

  # Bilgileri dosyaya kaydet
  cat > "${APP_DIR}/INSTALL_INFO.txt" <<EOF
YouTube Shorts Otomasyon — Kurulum Bilgileri
Tarih: $(date '+%Y-%m-%d %H:%M:%S')
================================================
Web: http://${DOMAIN:-$SERVER_IP}
API: http://${DOMAIN:-$SERVER_IP}/api
DB Name: ${DB_NAME}
DB User: ${DB_USER}
DB Pass: ${DB_PASS}
App Dir: ${APP_DIR}
================================================
EOF
  chmod 600 "${APP_DIR}/INSTALL_INFO.txt"
  log_info "Kurulum bilgileri ${APP_DIR}/INSTALL_INFO.txt dosyasına kaydedildi."
}

# ── Ana Akış ─────────────────────────────────────────────────────────────────
main() {
  print_banner
  check_root
  collect_info
  install_system_packages
  install_nodejs
  setup_database
  deploy_application
  setup_backend
  setup_frontend
  fix_permissions
  setup_nginx
  print_summary
}

main "$@"