import { createClient } from '@metagptx/web-sdk';

export const client = createClient();

// Helper types for our entities
export interface Niche {
  id: number;
  name: string;
  slug: string;
  category: string;
  sub_category: string;
  description: string;
  saturation_level: string;
  visual_suitability: number;
  repeatability_score: number;
  global_transfer_score: number;
  monetization_potential: number;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface Channel {
  id: number;
  name: string;
  slug: string;
  status: string;
  stage: string;
  primary_language: string;
  content_mode: string;
  core_niche_id: number;
  authority_score: number;
  topic_drift_score: number;
  expansion_readiness_score: number;
  global_readiness_score: number;
  domination_readiness_score: number;
  subscriber_count: number;
  total_views: number;
  total_videos: number;
  avg_watch_pct: number;
  first_3s_hold: number;
  rewatch_rate: number;
  upload_frequency_hours: number;
  youtube_channel_id: string;
  current_strategy_id: number;
  created_at: string;
  updated_at: string;
}

export interface NicheCandidate {
  id: number;
  niche_name: string;
  category: string;
  sub_category: string;
  source: string;
  gap_score: number;
  visual_score: number;
  repeatability_score: number;
  global_transfer_score: number;
  monetization_score: number;
  saturation_score: number;
  brandability_score: number;
  risk_score: number;
  total_score: number;
  recommended_action: string;
  status: string;
  notes: string;
  content_ideas_count: number;
  created_at: string;
  updated_at: string;
}

export interface Video {
  id: number;
  channel_id: number;
  title: string;
  description: string;
  tags: string;
  hook_text: string;
  script_text: string;
  content_pillar: string;
  content_type: string;
  status: string;
  youtube_video_id: string;
  duration_seconds: number;
  views: number;
  likes: number;
  comments_count: number;
  first_3s_hold: number;
  avg_watch_pct: number;
  rewatch_rate: number;
  published_at: string;
  created_at: string;
  updated_at: string;
}

export interface StageHistory {
  id: number;
  channel_id: number;
  from_stage: string;
  to_stage: string;
  decision: string;
  reason: string;
  authority_score_at: number;
  topic_drift_at: number;
  subscriber_count_at: number;
  total_videos_at: number;
  triggered_by: string;
  created_at: string;
}

export interface GenerationJob {
  id: number;
  channel_id: number;
  video_id: number;
  job_type: string;
  status: string;
  priority: number;
  input_data: string;
  output_data: string;
  error_message: string;
  retry_count: number;
  max_retries: number;
  started_at: string;
  finished_at: string;
  next_run_at: string;
  created_at: string;
}

export interface UploadJob {
  id: number;
  channel_id: number;
  video_id: number;
  status: string;
  priority: number;
  youtube_video_id: string;
  upload_attempts: number;
  max_attempts: number;
  error_message: string;
  scheduled_at: string;
  started_at: string;
  finished_at: string;
  created_at: string;
}

export interface AnalyticsSnapshot {
  id: number;
  channel_id: number;
  period_start: string;
  period_end: string;
  total_views: number;
  total_subscribers_gained: number;
  total_subscribers_lost: number;
  avg_first_3s_hold: number;
  avg_watch_pct: number;
  avg_rewatch_rate: number;
  authority_score: number;
  topic_drift_score: number;
  audience_match_score: number;
  comments_quality_score: number;
  global_readiness_score: number;
  spam_audience_score: number;
  core_audience_drop: number;
  adjacent_hit_rate: number;
  videos_published: number;
  top_performing_video_id: number;
  created_at: string;
}

export interface StagePolicy {
  id: number;
  stage: string;
  min_videos_to_promote: number;
  min_authority_score: number;
  max_topic_drift: number;
  min_first_3s_hold: number;
  min_avg_watch_pct: number;
  min_rewatch_rate: number;
  max_core_audience_drop: number;
  min_adjacent_hit_rate: number;
  min_global_readiness: number;
  max_spam_audience_score: number;
  min_comments_quality: number;
  core_content_ratio: number;
  adjacent_content_ratio: number;
  trend_content_ratio: number;
  rollback_authority_threshold: number;
  rollback_drift_threshold: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ApiKey {
  id: number;
  service_name: string;
  key_label: string;
  key_value: string;
  key_type: string;
  status: string;
  last_used_at: string;
  error_count: number;
  total_requests: number;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface SystemSetting {
  id: number;
  setting_key: string;
  setting_value: string;
  setting_type: string;
  category: string;
  description: string;
  is_sensitive: boolean;
  created_at: string;
  updated_at: string;
}

// Stage display helpers
export const STAGE_LABELS: Record<string, string> = {
  micro_niche: 'Micro Niche',
  adjacent_bridge: 'Adjacent Bridge',
  global_expand: 'Global Expand',
  category_domination: 'Category Domination',
};

export const STAGE_COLORS: Record<string, string> = {
  micro_niche: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  adjacent_bridge: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  global_expand: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  category_domination: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
};

export const STATUS_COLORS: Record<string, string> = {
  active: 'bg-emerald-500/20 text-emerald-400',
  incubating: 'bg-blue-500/20 text-blue-400',
  paused: 'bg-amber-500/20 text-amber-400',
  frozen: 'bg-slate-500/20 text-slate-400',
  archived: 'bg-red-500/20 text-red-400',
  pending: 'bg-amber-500/20 text-amber-400',
  running: 'bg-blue-500/20 text-blue-400',
  completed: 'bg-emerald-500/20 text-emerald-400',
  failed: 'bg-red-500/20 text-red-400',
  cancelled: 'bg-slate-500/20 text-slate-400',
  published: 'bg-emerald-500/20 text-emerald-400',
  draft: 'bg-slate-500/20 text-slate-400',
  generating: 'bg-blue-500/20 text-blue-400',
  rendered: 'bg-purple-500/20 text-purple-400',
  uploading: 'bg-amber-500/20 text-amber-400',
  approved: 'bg-emerald-500/20 text-emerald-400',
  rejected: 'bg-red-500/20 text-red-400',
  testing: 'bg-blue-500/20 text-blue-400',
  queued: 'bg-amber-500/20 text-amber-400',
  processing: 'bg-blue-500/20 text-blue-400',
};

export const JOB_TYPE_LABELS: Record<string, string> = {
  niche_scan: 'Niche Scan',
  content_planning: 'Content Planning',
  script_gen: 'Script Generation',
  hook_gen: 'Hook Generation',
  title_gen: 'Title Generation',
  desc_gen: 'Description Gen',
  asset_source: 'Asset Sourcing',
  tts: 'Text-to-Speech',
  subtitle_align: 'Subtitle Align',
  ffmpeg_render: 'FFmpeg Render',
  full_pipeline: 'Full Pipeline',
};

export function formatNumber(num: number): string {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function formatDateTime(dateStr: string): string {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// Additional interfaces
export interface ChannelBrandProfile {
  id: number;
  channel_id: number;
  channel_name_display: string;
  short_description: string;
  slogan: string;
  tone: string;
  thumbnail_style: string;
  logo_prompt: string;
  banner_prompt: string;
  color_primary: string;
  color_secondary: string;
  identity_version: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface AudienceSegment {
  id: number;
  channel_id: number;
  segment_name: string;
  percentage: number;
  age_range: string;
  primary_region: string;
  interest_tags: string;
  engagement_level: string;
  retention_rate: number;
  created_at: string;
  updated_at: string;
}

export interface StrategySnapshot {
  id: number;
  channel_id: number;
  stage: string;
  content_pillars: string;
  content_mix: string;
  hook_families: string;
  title_families: string;
  thumbnail_families: string;
  upload_tempo_hours: number;
  content_mode: string;
  target_audience: string;
  authority_score_at: number;
  topic_drift_at: number;
  is_current: boolean;
  created_at: string;
}

// Evolution review result
export interface EvolutionReview {
  channel_id: number;
  channel_name: string;
  current_stage: string;
  next_stage: string | null;
  prev_stage: string | null;
  recommendation: string;
  pass_rate: number;
  passed: number;
  total: number;
  checks: Array<{
    metric: string;
    value: number;
    threshold: number;
    operator: string;
    passed: boolean;
  }>;
  reasons: string[];
}