# YouTube Shorts Otomasyon Sistemi - Development Plan

## Design Guidelines

### Design References
- **YouTube Studio**: Dark professional dashboard aesthetic
- **Grafana**: Data-rich panels with clear metrics
- **Linear**: Clean, modern project management UI

### Color Palette
- Primary Background: #0F0F23 (Deep Navy)
- Secondary Background: #1A1A2E (Dark Indigo)
- Card Background: #16213E (Dark Blue)
- Accent Primary: #E94560 (Vibrant Red - YouTube themed)
- Accent Secondary: #533483 (Purple)
- Accent Tertiary: #0F3460 (Deep Blue)
- Success: #10B981
- Warning: #F59E0B
- Error: #EF4444
- Text Primary: #F1F5F9
- Text Secondary: #94A3B8
- Text Muted: #64748B

### Typography
- Font: Inter (sans-serif)
- H1: 700 weight, 32px
- H2: 600 weight, 24px
- H3: 500 weight, 20px
- Body: 400 weight, 14px
- Small: 400 weight, 12px

### Key Component Styles
- Cards: Dark blue bg (#16213E), 1px border (#1E3A5F), 12px rounded, subtle hover glow
- Buttons: Red accent (#E94560) for primary, outlined for secondary
- Badges: Rounded-full, color-coded by stage/status
- Tables: Striped dark rows, hover highlight
- Charts: Vibrant gradient fills

### Images to Generate
1. **hero-dashboard-bg.jpg** - Abstract dark tech visualization with data flow lines and nodes, deep navy/purple tones (Style: minimalist, dark mood)
2. **logo-shorts-automation.png** - Modern geometric logo combining play button and automation gear, red and white on transparent (Style: minimalist)
3. **empty-state-channels.jpg** - Abstract illustration of connected video screens forming a network, dark theme (Style: minimalist, dark)
4. **empty-state-niche.jpg** - Abstract illustration of a magnifying glass over data patterns, dark purple tones (Style: minimalist, dark)

---

## Database Tables (via BackendManager.create_tables)

### Core Entities:
1. **channels** - Main channel entity with stage, scores, status
2. **niches** - Niche definitions with category info
3. **niche_candidates** - Discovered niche candidates with scores
4. **channel_stage_histories** - Stage transition history
5. **videos** - Video records with metadata
6. **channel_brand_profiles** - Brand identity per channel
7. **audience_segments** - Audience segment data
8. **stage_policies** - Stage transition rules/thresholds
9. **strategy_snapshots** - Strategy state captures
10. **generation_jobs** - Content generation pipeline jobs
11. **upload_jobs** - YouTube upload queue jobs
12. **analytics_snapshots** - Analytics metric snapshots
13. **api_keys** - API key management (Pexels, etc.)
14. **system_settings** - Global system configuration

## Backend Custom APIs (via BackendManager.create_function)

1. **Evolution Engine** - Stage review, promote/stay/rollback decisions
2. **Niche Discovery** - Niche scanning and scoring
3. **Channel Spawn** - New channel creation with validation
4. **Content Planning** - Stage-aware content plan generation
5. **Generation Pipeline** - Script/hook/title/description generation
6. **Analytics Processing** - Metric calculation and snapshot creation

## Frontend Pages (React + shadcn/ui)

1. **Layout.tsx** - Main app layout with sidebar navigation
2. **DashboardPage.tsx** - Overview dashboard with stats, recent activity
3. **ChannelsPage.tsx** - Channel list with filtering, stage badges
4. **ChannelDetailPage.tsx** - Full channel detail with tabs (overview, evolution, brand, videos, analytics)
5. **EvolutionCenterPage.tsx** - Stage policies, transition history, manual overrides
6. **NicheLabPage.tsx** - Niche candidates, scoring, approve/reject
7. **JobsPage.tsx** - All queue jobs with status, errors, retry info
8. **SettingsPage.tsx** - API keys, system settings management

## Implementation Order
1. Create all database tables
2. Insert seed data
3. Generate images
4. Create backend custom APIs (edge functions)
5. Build frontend pages
6. Lint and build check
7. UI check