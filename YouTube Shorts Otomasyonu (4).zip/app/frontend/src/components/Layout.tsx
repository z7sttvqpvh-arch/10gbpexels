import { NavLink, Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  Tv2,
  FlaskConical,
  Layers,
  Settings,
  Zap,
  ChevronLeft,
  ChevronRight,
  GitBranch,
  Bot,
  Shield,
  BookOpen,
  Rocket,
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

const NAV_ITEMS = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/setup', icon: Rocket, label: 'Kurulum Rehberi' },
  { to: '/automation', icon: Bot, label: 'Otomasyon' },
  { to: '/proposals', icon: Shield, label: 'Kanal Önerileri' },
  { to: '/strategy', icon: BookOpen, label: 'Strateji Rehberi' },
  { to: '/channels', icon: Tv2, label: 'Channels' },
  { to: '/evolution', icon: GitBranch, label: 'Evolution' },
  { to: '/niche-lab', icon: FlaskConical, label: 'Niche Lab' },
  { to: '/jobs', icon: Layers, label: 'Jobs Queue' },
  { to: '/settings', icon: Settings, label: 'Settings' },
];

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="flex h-screen bg-[#0F0F23] text-slate-100 overflow-hidden">
      {/* Sidebar */}
      <aside
        className={cn(
          'flex flex-col border-r border-slate-700/50 bg-[#0A0A1A] transition-all duration-300',
          collapsed ? 'w-16' : 'w-56'
        )}
      >
        {/* Logo */}
        <div className="flex items-center gap-2 px-4 h-14 border-b border-slate-700/50 shrink-0">
          <Zap className="w-6 h-6 text-[#E94560] shrink-0" />
          {!collapsed && (
            <span className="font-bold text-sm tracking-wide whitespace-nowrap">
              Shorts Engine
            </span>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-3 space-y-1 px-2 overflow-y-auto">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all',
                  isActive
                    ? 'bg-[#E94560]/15 text-[#E94560]'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                )
              }
            >
              <item.icon className="w-5 h-5 shrink-0" />
              {!collapsed && <span className="whitespace-nowrap">{item.label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center justify-center h-10 border-t border-slate-700/50 text-slate-500 hover:text-slate-300 transition-colors"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
}