import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  BookOpen, Key, Tv2, FlaskConical, GitBranch, Bot, Zap, Shield,
  CheckCircle2, Circle, ArrowRight, ChevronDown, ChevronUp,
  Settings, Layers, Film, Target, Brain, Sparkles, AlertTriangle,
  ExternalLink, Copy, Clock, Play, Hash, Eye, Mic, Upload,
  BarChart3, RefreshCw, Rocket, Globe, Users, TrendingUp
} from 'lucide-react';
import { toast } from 'sonner';

interface SetupStep {
  id: string;
  step: number;
  title: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  route?: string;
  details: string[];
  tips?: string[];
  estimatedTime: string;
}

const SETUP_STEPS: SetupStep[] = [
  {
    id: 'api-keys',
    step: 1,
    title: 'API Anahtarlarını Ekleyin',
    description: 'YouTube Data API ve diğer servislerin anahtarlarını sisteme tanımlayın.',
    icon: Key,
    color: 'text-amber-400',
    bgColor: 'bg-amber-500/20',
    route: '/settings',
    estimatedTime: '5-10 dk',
    details: [
      'Settings sayfasına gidin ve "Add API Key" butonuna tıklayın',
      'YouTube Data API v3 anahtarınızı ekleyin (Google Cloud Console\'dan alabilirsiniz)',
      'Opsiyonel: Gemini API Key ekleyin (gelişmiş AI içerik üretimi için)',
      'Opsiyonel: ElevenLabs API Key ekleyin (profesyonel seslendirme için)',
      'Opsiyonel: Pexels/Pixabay API Key ekleyin (stok video/görsel için)',
      'Her anahtarın durumunu "active" olarak ayarlayın',
    ],
    tips: [
      'YouTube Data API Key almak için: Google Cloud Console → APIs & Services → Credentials → Create Credentials → API Key',
      'YouTube Data API v3\'ü etkinleştirmeyi unutmayın: APIs & Services → Library → YouTube Data API v3 → Enable',
      'Günlük kota limitlerini kontrol edin: YouTube API günlük 10.000 birim ücretsiz kota sunar',
    ],
  },
  {
    id: 'niche-discovery',
    step: 2,
    title: 'Niş Keşfi Yapın',
    description: 'AI destekli niş analizi ile karlı ve düşük rekabetli niş alanları keşfedin.',
    icon: FlaskConical,
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/20',
    route: '/niche-lab',
    estimatedTime: '10-15 dk',
    details: [
      'Niche Lab sayfasına gidin',
      'İlgilendiğiniz genel kategoriyi seçin (eğitim, eğlence, teknoloji vb.)',
      'AI\'dan niş önerileri isteyin — sistem rekabet, talep ve büyüme potansiyelini analiz eder',
      'En az 3-5 niş önerisi alın ve karşılaştırın',
      'Beğendiğiniz nişleri onaylayın (Approve) — onaylanan nişler kanal oluşturmada kullanılır',
      'Her niş için hedef kitle, içerik türleri ve anahtar kelimeler otomatik oluşturulur',
    ],
    tips: [
      'Dar ve spesifik nişler daha hızlı büyür (ör: "yemek" yerine "5 dakikada tatlı tarifleri")',
      'Trend nişleri takip edin ama evergreen (her zaman geçerli) nişleri tercih edin',
      'Rekabet skoru düşük, talep skoru yüksek nişleri seçin',
    ],
  },
  {
    id: 'channel-proposals',
    step: 3,
    title: 'Kanal Önerileri Oluşturun',
    description: 'Otomasyon sistemi niş bazlı kanal önerileri oluşturur. İnceleyip onaylayın.',
    icon: Shield,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/20',
    route: '/proposals',
    estimatedTime: '5-10 dk',
    details: [
      'Kanal Önerileri sayfasına gidin',
      'Sistem onayladığınız nişler için otomatik kanal önerileri oluşturur',
      'Her öneri kanal adı, açıklama, hedef kitle ve içerik stratejisi içerir',
      'Önerileri inceleyin: Beğendiklerinizi onaylayın, beğenmediklerinizi reddedin',
      'Onaylanan öneriler otomatik olarak kanal oluşturma sürecine girer',
      'İsterseniz manuel olarak da kanal önerisi oluşturabilirsiniz',
    ],
    tips: [
      'İlk başta 1-2 kanal ile başlayın, sistemi öğrendikçe artırın',
      'Kanal adı kısa, akılda kalıcı ve niş ile ilgili olmalı',
      'Farklı nişlerde kanallar açarak riski dağıtabilirsiniz',
    ],
  },
  {
    id: 'channel-creation',
    step: 4,
    title: 'Kanalları Oluşturun',
    description: 'Onaylanan önerilerden YouTube kanallarını oluşturun ve yapılandırın.',
    icon: Tv2,
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-500/20',
    route: '/channels',
    estimatedTime: '10-20 dk',
    details: [
      'Channels sayfasına gidin',
      '"New Channel" butonuyla yeni kanal oluşturun',
      'Kanal adı, açıklama ve hedef nişi seçin',
      'İçerik modu belirleyin: ai_generated, curated, veya hybrid',
      'Kanal YouTube\'da oluşturulduktan sonra YouTube Channel ID\'yi sisteme girin',
      'Kanal durumunu "active" yaparak otomasyon sürecini başlatın',
    ],
    tips: [
      'Her kanal için tutarlı bir marka kimliği oluşturun (logo, banner, renk paleti)',
      'Kanal açıklamasında anahtar kelimeleri doğal şekilde kullanın',
      'İlk 3-4 videoyu aynı anda yükleyin — YouTube\'a daha fazla test verisi sağlar',
    ],
  },
  {
    id: 'evolution',
    step: 5,
    title: 'Evrim Merkezini Yapılandırın',
    description: 'Kanalların büyüme aşamalarını ve strateji geçişlerini yönetin.',
    icon: GitBranch,
    color: 'text-cyan-400',
    bgColor: 'bg-cyan-500/20',
    route: '/evolution',
    estimatedTime: '5-10 dk',
    details: [
      'Evolution sayfasına gidin',
      'Her kanal için mevcut aşamayı (stage) kontrol edin',
      'Aşamalar: seed → sprout → growth → established → authority',
      'Her aşamada farklı strateji ve içerik karması uygulanır',
      'Sistem otomatik olarak performansa göre aşama geçişi önerir',
      'Strateji snapshot\'ları ile hook aileleri, başlık formatları ve içerik karmasını ayarlayın',
    ],
    tips: [
      'Seed aşamasında %100 core content üretin — niş tutarlılığı kritik',
      'Growth aşamasında adjacent content eklemeye başlayın (%15)',
      'Authority aşamasında trend content ile viral potansiyeli artırın',
    ],
  },
  {
    id: 'automation',
    step: 6,
    title: 'Otomasyonu Başlatın',
    description: 'Tam otomatik içerik üretimi, video oluşturma ve yükleme sürecini aktifleştirin.',
    icon: Bot,
    color: 'text-[#E94560]',
    bgColor: 'bg-[#E94560]/20',
    route: '/automation',
    estimatedTime: '5 dk',
    details: [
      'Otomasyon sayfasına gidin',
      'İçerik planlama otomasyonunu aktifleştirin',
      'Video üretim pipeline\'ını başlatın',
      'Upload zamanlama ayarlarını yapın',
      'Analitik toplama sürecini etkinleştirin',
      'Sistem artık otomatik olarak içerik üretip yükleyecek',
    ],
    tips: [
      'İlk hafta manuel kontrol yapın — AI çıktılarını gözden geçirin',
      'Upload sıklığını günde 1-2 video ile başlatın',
      'Performans düşerse 48-72 saat upload duraklatma stratejisini uygulayın',
    ],
  },
  {
    id: 'strategy',
    step: 7,
    title: 'Strateji Rehberini İnceleyin',
    description: '2026 YouTube Shorts algoritma stratejilerini öğrenin ve uygulayın.',
    icon: BookOpen,
    color: 'text-orange-400',
    bgColor: 'bg-orange-500/20',
    route: '/strategy',
    estimatedTime: '15-20 dk',
    details: [
      'Strateji Rehberi sayfasına gidin',
      '12 kritik strateji kuralını okuyun ve anlayın',
      'İlk 3 Saniye Hook kuralını her videoda uygulayın',
      '3 Dağıtım Dalgası sistemini anlayın',
      'Metadata Senkronizasyonu kurallarını takip edin',
      'Upload öncesi kontrol listesini her video için kullanın',
    ],
    tips: [
      'Kritik öncelikli kuralları ezberleyin — bunlar başarının %80\'ini belirler',
      'Her video upload\'ından önce kontrol listesini doldurun',
      'Dağıtım dalgaları sekmesindeki metrikleri hedef olarak belirleyin',
    ],
  },
  {
    id: 'monitoring',
    step: 8,
    title: 'İzleme ve Optimizasyon',
    description: 'Dashboard ve Jobs Queue ile sistemi izleyin, performansı optimize edin.',
    icon: BarChart3,
    color: 'text-teal-400',
    bgColor: 'bg-teal-500/20',
    route: '/',
    estimatedTime: 'Sürekli',
    details: [
      'Dashboard\'da genel performansı takip edin',
      'Jobs Queue\'da çalışan ve başarısız görevleri kontrol edin',
      'Kanal detay sayfasında her kanalın metriklerini inceleyin',
      'Topic drift skoru %20\'yi geçen kanalları düzeltin',
      'Düşük performanslı videoları analiz edin ve strateji güncelleyin',
      'Haftalık olarak Evolution Center\'da aşama geçişlerini değerlendirin',
    ],
    tips: [
      'Günlük en az 1 kez Dashboard\'ı kontrol edin',
      'Failed jobs varsa hemen müdahale edin',
      'İlk 3 saniye tutma oranı %30\'un altındaki videoların hook\'larını değiştirin',
    ],
  },
];

const PREREQUISITES = [
  { label: 'Google Cloud hesabı', description: 'YouTube Data API için gerekli', link: 'https://console.cloud.google.com' },
  { label: 'YouTube kanalı', description: 'En az 1 YouTube kanalı (veya yeni oluşturulacak)', link: 'https://studio.youtube.com' },
  { label: 'Modern tarayıcı', description: 'Chrome, Firefox veya Edge (güncel sürüm)', link: '' },
];

export default function SetupGuidePage() {
  const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set());
  const [expandedStep, setExpandedStep] = useState<string | null>('api-keys');
  const navigate = useNavigate();

  const toggleStep = (id: string) => {
    setExpandedStep(expandedStep === id ? null : id);
  };

  const markComplete = (id: string) => {
    setCompletedSteps((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const progress = (completedSteps.size / SETUP_STEPS.length) * 100;

  return (
    <div className="p-6 space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Rocket className="w-7 h-7 text-[#E94560]" />
          Kurulum Rehberi
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          YouTube Shorts otomasyon sistemini adım adım kurun ve çalıştırın
        </p>
      </div>

      {/* Progress Overview */}
      <Card className="bg-gradient-to-r from-[#16213E] to-[#1A1A3E] border-slate-700/50">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#E94560]/20 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-[#E94560]" />
              </div>
              <div>
                <h2 className="font-bold text-lg">Kurulum İlerlemesi</h2>
                <p className="text-xs text-slate-500">
                  {completedSteps.size}/{SETUP_STEPS.length} adım tamamlandı
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-[#E94560]">{Math.round(progress)}%</p>
              <p className="text-[10px] text-slate-500">tamamlandı</p>
            </div>
          </div>
          <div className="h-3 bg-slate-700/50 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#E94560] to-[#533483] rounded-full transition-all duration-700 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          {/* Step indicators */}
          <div className="flex items-center justify-between mt-3">
            {SETUP_STEPS.map((step) => {
              const isComplete = completedSteps.has(step.id);
              return (
                <button
                  key={step.id}
                  onClick={() => toggleStep(step.id)}
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    isComplete
                      ? 'bg-emerald-500 text-white'
                      : expandedStep === step.id
                      ? 'bg-[#E94560] text-white ring-2 ring-[#E94560]/30'
                      : 'bg-slate-700/50 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  {isComplete ? <CheckCircle2 className="w-4 h-4" /> : step.step}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Prerequisites */}
      <Card className="bg-[#16213E] border-amber-500/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            Ön Gereksinimler
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {PREREQUISITES.map((prereq, i) => (
              <div key={i} className="p-3 rounded-lg bg-slate-800/30 border border-slate-700/30">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="text-sm font-medium">{prereq.label}</span>
                </div>
                <p className="text-xs text-slate-500 mt-1 ml-6">{prereq.description}</p>
                {prereq.link && (
                  <a
                    href={prereq.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] text-blue-400 hover:text-blue-300 ml-6 mt-1 inline-flex items-center gap-1"
                  >
                    <ExternalLink className="w-3 h-3" /> Aç
                  </a>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Setup Steps */}
      <div className="space-y-3">
        {SETUP_STEPS.map((step) => {
          const Icon = step.icon;
          const isExpanded = expandedStep === step.id;
          const isComplete = completedSteps.has(step.id);

          return (
            <Card
              key={step.id}
              className={`border transition-all ${
                isComplete
                  ? 'bg-emerald-500/5 border-emerald-500/20'
                  : isExpanded
                  ? 'bg-[#16213E] border-slate-600/50'
                  : 'bg-[#16213E] border-slate-700/50'
              }`}
            >
              <CardContent className="p-0">
                {/* Step Header */}
                <button
                  onClick={() => toggleStep(step.id)}
                  className="w-full flex items-center gap-4 p-4 text-left"
                >
                  <div className={`w-10 h-10 rounded-xl ${step.bgColor} flex items-center justify-center shrink-0`}>
                    {isComplete ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <Icon className={`w-5 h-5 ${step.color}`} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <Badge className="bg-slate-700/50 text-slate-400 border-0 text-[10px] px-1.5">
                        Adım {step.step}
                      </Badge>
                      <h3 className={`font-bold text-sm ${isComplete ? 'text-emerald-300' : ''}`}>
                        {step.title}
                      </h3>
                      {isComplete && (
                        <Badge className="bg-emerald-500/20 text-emerald-400 border-0 text-[10px]">
                          ✓ Tamamlandı
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{step.description}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Badge variant="outline" className="border-slate-700 text-slate-500 text-[10px]">
                      <Clock className="w-3 h-3 mr-1" />
                      {step.estimatedTime}
                    </Badge>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-slate-500" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-500" />
                    )}
                  </div>
                </button>

                {/* Step Details */}
                {isExpanded && (
                  <div className="px-4 pb-4 space-y-4">
                    <div className="ml-14 border-t border-slate-700/30 pt-4">
                      {/* Instructions */}
                      <div className="space-y-2">
                        <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                          Yapılacaklar
                        </h4>
                        {step.details.map((detail, i) => (
                          <div key={i} className="flex items-start gap-2.5">
                            <div className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                              <span className="text-[10px] font-bold text-slate-400">{i + 1}</span>
                            </div>
                            <span className="text-sm text-slate-300 leading-relaxed">{detail}</span>
                          </div>
                        ))}
                      </div>

                      {/* Tips */}
                      {step.tips && step.tips.length > 0 && (
                        <div className="mt-4 p-3 rounded-lg bg-amber-500/5 border border-amber-500/10">
                          <h4 className="text-xs font-semibold text-amber-400 flex items-center gap-1.5 mb-2">
                            <Zap className="w-3.5 h-3.5" /> İpuçları
                          </h4>
                          <div className="space-y-1.5">
                            {step.tips.map((tip, i) => (
                              <div key={i} className="flex items-start gap-2 text-xs text-slate-400">
                                <span className="text-amber-500 shrink-0">💡</span>
                                <span>{tip}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex items-center gap-3 mt-4">
                        {step.route && (
                          <Button
                            size="sm"
                            className="bg-[#E94560] hover:bg-[#E94560]/80 text-white"
                            onClick={() => navigate(step.route!)}
                          >
                            <ArrowRight className="w-3.5 h-3.5 mr-1.5" />
                            Sayfaya Git
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant={isComplete ? 'outline' : 'default'}
                          className={
                            isComplete
                              ? 'border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10'
                              : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                          }
                          onClick={() => markComplete(step.id)}
                        >
                          {isComplete ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Tamamlanmadı Olarak İşaretle
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" /> Tamamlandı Olarak İşaretle
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Completion Card */}
      {completedSteps.size === SETUP_STEPS.length && (
        <Card className="bg-gradient-to-r from-emerald-500/10 to-[#533483]/10 border-emerald-500/30">
          <CardContent className="p-6 text-center">
            <Sparkles className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
            <h2 className="text-xl font-bold text-emerald-400">🎉 Kurulum Tamamlandı!</h2>
            <p className="text-sm text-slate-400 mt-2 max-w-md mx-auto">
              Tebrikler! YouTube Shorts otomasyon sisteminiz hazır. Artık Dashboard'dan
              tüm süreci izleyebilir ve yönetebilirsiniz.
            </p>
            <div className="flex items-center justify-center gap-3 mt-4">
              <Button
                className="bg-[#E94560] hover:bg-[#E94560]/80 text-white"
                onClick={() => navigate('/')}
              >
                <BarChart3 className="w-4 h-4 mr-1.5" /> Dashboard'a Git
              </Button>
              <Button
                variant="outline"
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
                onClick={() => navigate('/automation')}
              >
                <Bot className="w-4 h-4 mr-1.5" /> Otomasyonu Başlat
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Reference */}
      <Card className="bg-[#16213E] border-slate-700/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Globe className="w-4 h-4 text-blue-400" />
            Hızlı Referans — Sistem Akışı
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {[
              { label: 'Niş Keşfi', icon: FlaskConical, color: 'text-purple-400' },
              { label: 'Kanal Önerisi', icon: Shield, color: 'text-blue-400' },
              { label: 'Kanal Oluşturma', icon: Tv2, color: 'text-emerald-400' },
              { label: 'Strateji', icon: BookOpen, color: 'text-orange-400' },
              { label: 'İçerik Planlama', icon: Brain, color: 'text-pink-400' },
              { label: 'Video Üretim', icon: Film, color: 'text-amber-400' },
              { label: 'Upload', icon: Upload, color: 'text-cyan-400' },
              { label: 'Analitik', icon: BarChart3, color: 'text-teal-400' },
              { label: 'Evrim', icon: GitBranch, color: 'text-indigo-400' },
            ].map((item, i, arr) => (
              <div key={item.label} className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/50 border border-slate-700/30">
                  <item.icon className={`w-3.5 h-3.5 ${item.color}`} />
                  <span className="text-slate-300">{item.label}</span>
                </div>
                {i < arr.length - 1 && <ArrowRight className="w-3 h-3 text-slate-600" />}
              </div>
            ))}
          </div>
          <p className="text-[10px] text-slate-600 mt-3 text-center">
            Bu akış sürekli döngü halinde çalışır — her video sonrası analitik veriler stratejiyi günceller
          </p>
        </CardContent>
      </Card>
    </div>
  );
}