import { useEffect, useState } from 'react';
import { directApi, ApiKey, SystemSetting, STATUS_COLORS, formatDate } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Key, Settings, Plus, Eye, EyeOff, Save, Trash2, Loader2, Edit2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function SettingsPage() {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [settings, setSettings] = useState<SystemSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const [showKeys, setShowKeys] = useState<Set<number>>(new Set());

  // Add key dialog state
  const [addOpen, setAddOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingKey, setEditingKey] = useState<ApiKey | null>(null);
  const [formServiceName, setFormServiceName] = useState('youtube_data_api');
  const [formKeyLabel, setFormKeyLabel] = useState('');
  const [formKeyValue, setFormKeyValue] = useState('');
  const [formKeyType, setFormKeyType] = useState('api_key');
  const [formNotes, setFormNotes] = useState('');

  // Add setting dialog state
  const [addSettingOpen, setAddSettingOpen] = useState(false);
  const [savingSetting, setSavingSetting] = useState(false);
  const [settingKey, setSettingKey] = useState('');
  const [settingValue, setSettingValue] = useState('');
  const [settingCategory, setSettingCategory] = useState('automation');
  const [settingDescription, setSettingDescription] = useState('');
  const [settingIsSensitive, setSettingIsSensitive] = useState(false);

  const loadData = async () => {
    try {
      const [akResult, ssResult] = await Promise.allSettled([
        directApi.query<ApiKey>('api_keys', { sort: '-created_at', limit: 50 }),
        directApi.query<SystemSetting>('system_settings', { sort: 'category', limit: 50 }),
      ]);
      if (akResult.status === 'fulfilled') {
        setApiKeys(akResult.value.items || []);
      } else {
        console.error('Failed to load API keys', akResult.reason);
      }
      if (ssResult.status === 'fulfilled') {
        setSettings(ssResult.value.items || []);
      } else {
        console.error('Failed to load system settings', ssResult.reason);
      }
    } catch (e) {
      console.error('Failed to load settings', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const toggleKeyVisibility = (id: number) => {
    setShowKeys((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const maskKey = (key: string) => {
    if (!key) return '••••••••';
    if (key.length <= 8) return '••••••••';
    return key.slice(0, 4) + '••••••••' + key.slice(-4);
  };

  const resetForm = () => {
    setFormServiceName('youtube_data_api');
    setFormKeyLabel('');
    setFormKeyValue('');
    setFormKeyType('api_key');
    setFormNotes('');
    setEditingKey(null);
  };

  const handleSaveKey = async () => {
    if (!formKeyLabel.trim() || !formKeyValue.trim()) {
      toast.error('Please fill in label and key value');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        service_name: formServiceName,
        key_label: formKeyLabel.trim(),
        key_value: formKeyValue.trim(),
        key_type: formKeyType,
        status: 'active',
        error_count: 0,
        total_requests: 0,
        notes: formNotes.trim(),
      };

      if (editingKey) {
        await directApi.update('api_keys', editingKey.id, payload);
        toast.success('API key updated');
      } else {
        await directApi.create('api_keys', payload);
        toast.success('API key added');
      }
      setAddOpen(false);
      resetForm();
      await loadData();
    } catch (e: any) {
      console.error('Save API key error:', e);
      const msg = e?.message || 'Unknown error';
      toast.error(`Failed to save API key: ${msg}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteKey = async (id: number) => {
    try {
      await directApi.delete('api_keys', id);
      toast.success('API key deleted');
      await loadData();
    } catch (e: any) {
      console.error('Delete API key error:', e);
      toast.error('Failed to delete API key');
    }
  };

  const handleEditKey = (ak: ApiKey) => {
    setEditingKey(ak);
    setFormServiceName(ak.service_name);
    setFormKeyLabel(ak.key_label);
    setFormKeyValue(ak.key_value);
    setFormKeyType(ak.key_type);
    setFormNotes(ak.notes || '');
    setAddOpen(true);
  };

  const handleToggleKeyStatus = async (ak: ApiKey) => {
    try {
      const newStatus = ak.status === 'active' ? 'inactive' : 'active';
      await directApi.update('api_keys', ak.id, { status: newStatus });
      toast.success(`Key ${newStatus === 'active' ? 'activated' : 'deactivated'}`);
      await loadData();
    } catch {
      toast.error('Failed to update key status');
    }
  };

  const handleSaveSetting = async () => {
    if (!settingKey.trim() || !settingValue.trim()) {
      toast.error('Please fill in key and value');
      return;
    }
    setSavingSetting(true);
    try {
      await directApi.create('system_settings', {
        setting_key: settingKey.trim(),
        setting_value: settingValue.trim(),
        setting_type: 'string',
        category: settingCategory,
        description: settingDescription.trim(),
        is_sensitive: settingIsSensitive,
      });
      toast.success('Setting added');
      setAddSettingOpen(false);
      setSettingKey('');
      setSettingValue('');
      setSettingDescription('');
      await loadData();
    } catch {
      toast.error('Failed to save setting');
    } finally {
      setSavingSetting(false);
    }
  };

  const handleUpdateSetting = async (id: number, value: string) => {
    try {
      await directApi.update('system_settings', id, { setting_value: value });
      toast.success('Setting updated');
      await loadData();
    } catch {
      toast.error('Failed to update setting');
    }
  };

  const handleDeleteSetting = async (id: number) => {
    try {
      await directApi.delete('system_settings', id);
      toast.success('Setting deleted');
      await loadData();
    } catch {
      toast.error('Failed to delete setting');
    }
  };

  // Group settings by category
  const settingsByCategory = settings.reduce<Record<string, SystemSetting[]>>((acc, s) => {
    const cat = s.category || 'General';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(s);
    return acc;
  }, {});

  const SERVICE_OPTIONS = [
    { value: 'youtube_data_api', label: 'YouTube Data API' },
    { value: 'youtube_upload_api', label: 'YouTube Upload API' },
    { value: 'gemini', label: 'Gemini (Google AI)' },
    { value: 'pexels', label: 'Pexels (Stock Video)' },
    { value: 'elevenlabs', label: 'ElevenLabs (TTS)' },
    { value: 'pixabay', label: 'Pixabay (Stock Media)' },
    { value: 'other', label: 'Other' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E94560]" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-slate-400 text-sm mt-1">Manage API keys and system configuration</p>
      </div>

      {/* Quick Setup Guide */}
      <Card className="bg-gradient-to-r from-[#533483]/20 to-[#E94560]/20 border-purple-500/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-sm text-purple-300">Hızlı Kurulum Rehberi</h3>
              <p className="text-xs text-slate-400 mt-1">
                Sistemi tam otomatik çalıştırmak için aşağıdaki API anahtarlarını eklemeniz gerekiyor:
              </p>
              <ul className="text-xs text-slate-400 mt-2 space-y-1">
                <li className="flex items-center gap-2">
                  <span className={apiKeys.some(k => k.service_name === 'youtube_data_api' && k.status === 'active') ? 'text-emerald-400' : 'text-amber-400'}>
                    {apiKeys.some(k => k.service_name === 'youtube_data_api' && k.status === 'active') ? '✓' : '○'}
                  </span>
                  <strong>YouTube Data API Key</strong> — Kanal oluşturma ve video yükleme için
                </li>
                <li className="flex items-center gap-2">
                  <span className={apiKeys.some(k => k.service_name === 'gemini' && k.status === 'active') ? 'text-emerald-400' : 'text-amber-400'}>
                    {apiKeys.some(k => k.service_name === 'gemini' && k.status === 'active') ? '✓' : '○'}
                  </span>
                  <strong>Gemini Cookie / API Key</strong> — AI içerik üretimi için (opsiyonel, sistem dahili AI kullanır)
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="api-keys" className="space-y-4">
        <TabsList className="bg-[#16213E] border border-slate-700/50">
          <TabsTrigger value="api-keys" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">
            <Key className="w-3.5 h-3.5 mr-1" /> API Keys ({apiKeys.length})
          </TabsTrigger>
          <TabsTrigger value="system" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">
            <Settings className="w-3.5 h-3.5 mr-1" /> System Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="api-keys" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={addOpen} onOpenChange={(open) => { setAddOpen(open); if (!open) resetForm(); }}>
              <DialogTrigger asChild>
                <Button className="bg-[#E94560] hover:bg-[#E94560]/80 text-white">
                  <Plus className="w-4 h-4 mr-1" /> Add API Key
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#16213E] border-slate-700/50 text-slate-100">
                <DialogHeader>
                  <DialogTitle>{editingKey ? 'Edit API Key' : 'Add New API Key'}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-2">
                  <div>
                    <Label className="text-xs text-slate-400">Service</Label>
                    <Select value={formServiceName} onValueChange={setFormServiceName}>
                      <SelectTrigger className="bg-slate-800/50 border-slate-700/50 mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-[#16213E] border-slate-700/50">
                        {SERVICE_OPTIONS.map((s) => (
                          <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">Label *</Label>
                    <Input
                      value={formKeyLabel}
                      onChange={(e) => setFormKeyLabel(e.target.value)}
                      placeholder="e.g. My YouTube API Key"
                      className="bg-slate-800/50 border-slate-700/50 mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">Key / Token Value *</Label>
                    <Input
                      value={formKeyValue}
                      onChange={(e) => setFormKeyValue(e.target.value)}
                      placeholder="Paste your API key or cookie here"
                      className="bg-slate-800/50 border-slate-700/50 mt-1 font-mono text-xs"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">Key Type</Label>
                    <Select value={formKeyType} onValueChange={setFormKeyType}>
                      <SelectTrigger className="bg-slate-800/50 border-slate-700/50 mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-[#16213E] border-slate-700/50">
                        <SelectItem value="api_key">API Key</SelectItem>
                        <SelectItem value="oauth_token">OAuth Token</SelectItem>
                        <SelectItem value="cookie">Cookie</SelectItem>
                        <SelectItem value="bearer_token">Bearer Token</SelectItem>
                        <SelectItem value="secret">Secret</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">Notes</Label>
                    <Input
                      value={formNotes}
                      onChange={(e) => setFormNotes(e.target.value)}
                      placeholder="Optional notes..."
                      className="bg-slate-800/50 border-slate-700/50 mt-1"
                    />
                  </div>
                  <Button
                    onClick={handleSaveKey}
                    disabled={saving}
                    className="w-full bg-[#E94560] hover:bg-[#E94560]/80 text-white"
                  >
                    {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Save className="w-4 h-4 mr-1" />}
                    {saving ? 'Saving...' : editingKey ? 'Update Key' : 'Save Key'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {apiKeys.length === 0 ? (
            <Card className="bg-[#16213E] border-slate-700/50">
              <CardContent className="py-12 text-center">
                <Key className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">No API keys configured</p>
                <p className="text-xs text-slate-500 mt-1">Add your YouTube API key and Gemini cookie to get started</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {apiKeys.map((ak) => (
                <Card key={ak.id} className="bg-[#16213E] border-slate-700/50">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-semibold text-sm">{ak.key_label}</h3>
                          <Badge
                            className={`text-[10px] px-1.5 py-0 border-0 cursor-pointer ${STATUS_COLORS[ak.status] || ''}`}
                            onClick={() => handleToggleKeyStatus(ak)}
                          >
                            {ak.status}
                          </Badge>
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-slate-600">
                            {SERVICE_OPTIONS.find(s => s.value === ak.service_name)?.label || ak.service_name}
                          </Badge>
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-slate-600">
                            {ak.key_type}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          <code className="text-xs bg-slate-800 px-2 py-1 rounded font-mono text-slate-300">
                            {showKeys.has(ak.id) ? ak.key_value : maskKey(ak.key_value)}
                          </code>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0 text-slate-500 hover:text-slate-300"
                            onClick={() => toggleKeyVisibility(ak.id)}
                          >
                            {showKeys.has(ak.id) ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                          </Button>
                        </div>
                        <div className="flex gap-4 mt-2 text-[10px] text-slate-500">
                          <span>Requests: {ak.total_requests || 0}</span>
                          <span>Errors: {ak.error_count || 0}</span>
                          {ak.last_used_at && <span>Last used: {formatDate(ak.last_used_at)}</span>}
                          <span>Added: {formatDate(ak.created_at)}</span>
                        </div>
                        {ak.notes && <p className="text-xs text-slate-400 mt-1">{ak.notes}</p>}
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                          onClick={() => handleEditKey(ak)}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                          onClick={() => handleDeleteKey(ak.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="system" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={addSettingOpen} onOpenChange={setAddSettingOpen}>
              <DialogTrigger asChild>
                <Button className="bg-[#533483] hover:bg-[#533483]/80 text-white">
                  <Plus className="w-4 h-4 mr-1" /> Add Setting
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#16213E] border-slate-700/50 text-slate-100">
                <DialogHeader>
                  <DialogTitle>Add System Setting</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-2">
                  <div>
                    <Label className="text-xs text-slate-400">Category</Label>
                    <Select value={settingCategory} onValueChange={setSettingCategory}>
                      <SelectTrigger className="bg-slate-800/50 border-slate-700/50 mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-[#16213E] border-slate-700/50">
                        <SelectItem value="automation">Automation</SelectItem>
                        <SelectItem value="content">Content</SelectItem>
                        <SelectItem value="upload">Upload</SelectItem>
                        <SelectItem value="general">General</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">Setting Key *</Label>
                    <Input
                      value={settingKey}
                      onChange={(e) => setSettingKey(e.target.value)}
                      placeholder="e.g. auto_approve_min_score"
                      className="bg-slate-800/50 border-slate-700/50 mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">Value *</Label>
                    <Input
                      value={settingValue}
                      onChange={(e) => setSettingValue(e.target.value)}
                      placeholder="e.g. 65"
                      className="bg-slate-800/50 border-slate-700/50 mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">Description</Label>
                    <Input
                      value={settingDescription}
                      onChange={(e) => setSettingDescription(e.target.value)}
                      placeholder="What this setting controls..."
                      className="bg-slate-800/50 border-slate-700/50 mt-1"
                    />
                  </div>
                  <Button
                    onClick={handleSaveSetting}
                    disabled={savingSetting}
                    className="w-full bg-[#533483] hover:bg-[#533483]/80 text-white"
                  >
                    {savingSetting ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Save className="w-4 h-4 mr-1" />}
                    {savingSetting ? 'Saving...' : 'Save Setting'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {Object.keys(settingsByCategory).length === 0 ? (
            <Card className="bg-[#16213E] border-slate-700/50">
              <CardContent className="py-12 text-center">
                <Settings className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400">No system settings configured</p>
                <p className="text-xs text-slate-500 mt-1">Settings will appear here once configured</p>
              </CardContent>
            </Card>
          ) : (
            Object.entries(settingsByCategory).map(([category, catSettings]) => (
              <Card key={category} className="bg-[#16213E] border-slate-700/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm capitalize">{category}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {catSettings.map((s) => (
                    <div key={s.id} className="flex items-center gap-4">
                      <div className="flex-1">
                        <Label className="text-xs text-slate-400">{s.setting_key}</Label>
                        {s.description && <p className="text-[10px] text-slate-500">{s.description}</p>}
                      </div>
                      <SettingValueEditor
                        setting={s}
                        onSave={(val) => handleUpdateSetting(s.id, val)}
                      />
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 w-7 p-0 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                        onClick={() => handleDeleteSetting(s.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function SettingValueEditor({ setting, onSave }: { setting: SystemSetting; onSave: (val: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(setting.setting_value);

  if (editing) {
    return (
      <div className="flex items-center gap-2">
        <Input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          className="w-64 bg-slate-800/50 border-slate-700/50 text-sm h-8"
          type={setting.is_sensitive ? 'password' : 'text'}
          autoFocus
          onKeyDown={(e) => {
            if (e.key === 'Enter') { onSave(value); setEditing(false); }
            if (e.key === 'Escape') { setValue(setting.setting_value); setEditing(false); }
          }}
        />
        <Button
          size="sm"
          className="h-7 bg-emerald-600 hover:bg-emerald-700 text-white px-2"
          onClick={() => { onSave(value); setEditing(false); }}
        >
          <Save className="w-3 h-3" />
        </Button>
      </div>
    );
  }

  return (
    <div
      className="flex items-center gap-2 cursor-pointer group"
      onClick={() => setEditing(true)}
    >
      <code className="text-xs bg-slate-800/50 px-2 py-1 rounded text-slate-300 w-64 block truncate">
        {setting.is_sensitive ? '••••••••' : setting.setting_value}
      </code>
      <Edit2 className="w-3 h-3 text-slate-600 group-hover:text-slate-400 transition-colors" />
    </div>
  );
}