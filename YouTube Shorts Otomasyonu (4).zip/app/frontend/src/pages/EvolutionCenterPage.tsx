import { useEffect, useState } from 'react';
import { client, Channel, StagePolicy, StageHistory, EvolutionReview, STAGE_LABELS, STAGE_COLORS, formatDate, formatDateTime, formatNumber } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, ArrowUpCircle, ArrowDownCircle, MinusCircle, Loader2, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

export default function EvolutionCenterPage() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [policies, setPolicies] = useState<StagePolicy[]>([]);
  const [allHistory, setAllHistory] = useState<StageHistory[]>([]);
  const [reviews, setReviews] = useState<Record<number, EvolutionReview>>({});
  const [reviewingId, setReviewingId] = useState<number | null>(null);
  const [executingId, setExecutingId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [chRes, polRes, histRes] = await Promise.all([
          client.entities.channels.query({ sort: '-updated_at', limit: 50 }),
          client.entities.stage_policies.query({ limit: 20 }),
          client.entities.channel_stage_histories.query({ sort: '-created_at', limit: 50 }),
        ]);
        setChannels(chRes.data?.items || []);
        setPolicies(polRes.data?.items || []);
        setAllHistory(histRes.data?.items || []);
      } catch (e) {
        console.error('Failed to load evolution data', e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const handleReview = async (channelId: number) => {
    setReviewingId(channelId);
    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/evolution/review',
        method: 'POST',
        data: { channel_id: channelId },
      });
      setReviews((prev) => ({ ...prev, [channelId]: res.data }));
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Review failed');
    } finally {
      setReviewingId(null);
    }
  };

  const handleExecute = async (channelId: number, decision: string, reason: string) => {
    setExecutingId(channelId);
    try {
      await client.apiCall.invoke({
        url: '/api/v1/evolution/execute',
        method: 'POST',
        data: { channel_id: channelId, decision, reason, triggered_by: 'manual' },
      });
      toast.success(`Stage ${decision} executed successfully`);
      // Refresh data
      const [chRes, histRes] = await Promise.all([
        client.entities.channels.query({ sort: '-updated_at', limit: 50 }),
        client.entities.channel_stage_histories.query({ sort: '-created_at', limit: 50 }),
      ]);
      setChannels(chRes.data?.items || []);
      setAllHistory(histRes.data?.items || []);
      setReviews((prev) => {
        const copy = { ...prev };
        delete copy[channelId];
        return copy;
      });
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Execution failed');
    } finally {
      setExecutingId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E94560]" />
      </div>
    );
  }

  const activeChannels = channels.filter((c) => c.status === 'active' || c.status === 'incubating');

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Evolution Center</h1>
        <p className="text-sm text-slate-400 mt-1">Stage management, policy review, and transition history</p>
      </div>

      <Tabs defaultValue="channels" className="space-y-4">
        <TabsList className="bg-[#16213E] border border-slate-700/50">
          <TabsTrigger value="channels" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Channel Reviews</TabsTrigger>
          <TabsTrigger value="policies" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Stage Policies</TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Transition History</TabsTrigger>
        </TabsList>

        {/* Channel Reviews Tab */}
        <TabsContent value="channels" className="space-y-4">
          {activeChannels.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-8">No active channels</p>
          ) : (
            activeChannels.map((ch) => {
              const review = reviews[ch.id];
              return (
                <Card key={ch.id} className="bg-[#16213E] border-slate-700/50">
                  <CardContent className="p-4 space-y-4">
                    {/* Channel header */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Shield className="w-5 h-5 text-[#E94560]" />
                        <div>
                          <h3 className="font-semibold">{ch.name}</h3>
                          <div className="flex items-center gap-2 mt-0.5">
                            <Badge className={`text-[10px] px-1.5 py-0 border ${STAGE_COLORS[ch.stage] || ''}`}>
                              {STAGE_LABELS[ch.stage] || ch.stage}
                            </Badge>
                            <span className="text-xs text-slate-500">
                              Auth: {ch.authority_score?.toFixed(1)} · Drift: {ch.topic_drift_score?.toFixed(1)} · {formatNumber(ch.subscriber_count)} subs
                            </span>
                          </div>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => handleReview(ch.id)}
                        disabled={reviewingId === ch.id}
                        className="bg-[#533483] hover:bg-[#533483]/80 text-white"
                      >
                        {reviewingId === ch.id ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
                        Review Stage
                      </Button>
                    </div>

                    {/* Review results */}
                    {review && (
                      <div className="space-y-3 border-t border-slate-700/30 pt-3">
                        <div className="flex items-center gap-3">
                          <div className={`px-3 py-1.5 rounded-lg text-sm font-medium ${
                            review.recommendation === 'promote' ? 'bg-emerald-500/20 text-emerald-400' :
                            review.recommendation === 'rollback' ? 'bg-red-500/20 text-red-400' :
                            'bg-amber-500/20 text-amber-400'
                          }`}>
                            {review.recommendation === 'promote' && <ArrowUpCircle className="w-4 h-4 inline mr-1" />}
                            {review.recommendation === 'rollback' && <ArrowDownCircle className="w-4 h-4 inline mr-1" />}
                            {review.recommendation === 'stay' && <MinusCircle className="w-4 h-4 inline mr-1" />}
                            {review.recommendation.toUpperCase()}
                          </div>
                          <span className="text-sm text-slate-400">
                            Pass rate: {review.pass_rate}% ({review.passed}/{review.total})
                          </span>
                        </div>

                        {/* Checks grid */}
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                          {review.checks.map((c, i) => (
                            <div key={i} className={`p-2 rounded text-xs ${c.passed ? 'bg-emerald-500/10 border border-emerald-500/20' : 'bg-red-500/10 border border-red-500/20'}`}>
                              <div className="flex items-center gap-1">
                                {c.passed ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <XCircle className="w-3 h-3 text-red-400" />}
                                <span className="font-medium">{c.metric}</span>
                              </div>
                              <p className="text-slate-400 mt-0.5">
                                {c.value} {c.operator === 'gte' ? '≥' : '≤'} {c.threshold}
                              </p>
                            </div>
                          ))}
                        </div>

                        {/* Reasons */}
                        <div className="space-y-1">
                          {review.reasons.slice(0, 3).map((r, i) => (
                            <p key={i} className="text-xs text-slate-400 flex items-start gap-1">
                              <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0 mt-0.5" />
                              {r}
                            </p>
                          ))}
                        </div>

                        {/* Action buttons */}
                        <div className="flex gap-2 pt-1">
                          {review.recommendation === 'promote' && review.next_stage && (
                            <Button
                              size="sm"
                              onClick={() => handleExecute(ch.id, 'promote', `Promoted: ${review.pass_rate}% criteria met`)}
                              disabled={executingId === ch.id}
                              className="bg-emerald-600 hover:bg-emerald-700 text-white"
                            >
                              {executingId === ch.id ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <ArrowUpCircle className="w-3 h-3 mr-1" />}
                              Promote to {STAGE_LABELS[review.next_stage]}
                            </Button>
                          )}
                          {review.recommendation === 'rollback' && review.prev_stage && (
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleExecute(ch.id, 'rollback', `Rollback: metrics below threshold`)}
                              disabled={executingId === ch.id}
                            >
                              {executingId === ch.id ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <ArrowDownCircle className="w-3 h-3 mr-1" />}
                              Rollback to {STAGE_LABELS[review.prev_stage]}
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleExecute(ch.id, 'stay', 'Manual decision to stay')}
                            disabled={executingId === ch.id}
                            className="border-slate-600"
                          >
                            Keep Current Stage
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })
          )}
        </TabsContent>

        {/* Policies Tab */}
        <TabsContent value="policies" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {policies.filter((p) => p.is_active).map((p) => (
              <Card key={p.id} className="bg-[#16213E] border-slate-700/50">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Badge className={`border ${STAGE_COLORS[p.stage] || ''}`}>
                        {STAGE_LABELS[p.stage] || p.stage}
                      </Badge>
                    </CardTitle>
                    <Badge variant="outline" className="text-[10px] border-emerald-500/30 text-emerald-400">Active</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Min Videos</p>
                      <p className="font-medium">{p.min_videos_to_promote}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Min Authority</p>
                      <p className="font-medium">{p.min_authority_score}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Max Drift</p>
                      <p className="font-medium">{p.max_topic_drift}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Min 3s Hold</p>
                      <p className="font-medium">{p.min_first_3s_hold}%</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Min Watch %</p>
                      <p className="font-medium">{p.min_avg_watch_pct}%</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Min Rewatch</p>
                      <p className="font-medium">{p.min_rewatch_rate}%</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Content Mix</p>
                      <p className="font-medium text-[10px]">
                        C:{(p.core_content_ratio * 100).toFixed(0)}% A:{(p.adjacent_content_ratio * 100).toFixed(0)}% T:{(p.trend_content_ratio * 100).toFixed(0)}%
                      </p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Rollback Thresholds</p>
                      <p className="font-medium text-[10px]">
                        Auth&lt;{p.rollback_authority_threshold} Drift&gt;{p.rollback_drift_threshold}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-3">
          {allHistory.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-8">No transitions yet</p>
          ) : (
            allHistory.map((h) => {
              const ch = channels.find((c) => c.id === h.channel_id);
              return (
                <Card key={h.id} className="bg-[#16213E] border-slate-700/50">
                  <CardContent className="p-3 flex items-start gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                      h.decision === 'promote' ? 'bg-emerald-500/20 text-emerald-400' :
                      h.decision === 'rollback' ? 'bg-red-500/20 text-red-400' :
                      'bg-slate-500/20 text-slate-400'
                    }`}>
                      {h.decision === 'promote' ? '↑' : h.decision === 'rollback' ? '↓' : '→'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-sm">{ch?.name || `Channel #${h.channel_id}`}</span>
                        <Badge className={`text-[10px] px-1.5 py-0 border ${STAGE_COLORS[h.from_stage] || ''}`}>
                          {STAGE_LABELS[h.from_stage] || h.from_stage}
                        </Badge>
                        <span className="text-slate-500">→</span>
                        <Badge className={`text-[10px] px-1.5 py-0 border ${STAGE_COLORS[h.to_stage] || ''}`}>
                          {STAGE_LABELS[h.to_stage] || h.to_stage}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">{h.reason}</p>
                      <div className="flex gap-3 mt-1 text-[10px] text-slate-500">
                        <span>Auth: {h.authority_score_at?.toFixed(1)}</span>
                        <span>Drift: {h.topic_drift_at?.toFixed(1)}</span>
                        <span>{formatDateTime(h.created_at)}</span>
                        <span className="capitalize">{h.triggered_by}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}