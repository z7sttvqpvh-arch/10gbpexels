import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { client, Channel, Niche, Video, StageHistory, AnalyticsSnapshot, StagePolicy, ChannelBrandProfile, AudienceSegment, StrategySnapshot, formatNumber, STAGE_LABELS, STAGE_COLORS, STATUS_COLORS, formatDate, formatDateTime } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Users, Eye, PlayCircle, Clock, TrendingUp, Shield, Target, Zap, Palette, UserCircle, Lightbulb, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ChannelDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [channel, setChannel] = useState<Channel | null>(null);
  const [niche, setNiche] = useState<Niche | null>(null);
  const [videos, setVideos] = useState<Video[]>([]);
  const [history, setHistory] = useState<StageHistory[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsSnapshot[]>([]);
  const [policies, setPolicies] = useState<StagePolicy[]>([]);
  const [brand, setBrand] = useState<ChannelBrandProfile | null>(null);
  const [segments, setSegments] = useState<AudienceSegment[]>([]);
  const [strategies, setStrategies] = useState<StrategySnapshot[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    async function load() {
      if (!id) return;
      try {
        const chRes = await client.entities.channels.get({ id });
        const ch = chRes.data;
        setChannel(ch);

        const [vidRes, histRes, anaRes, polRes, brandRes, segRes, stratRes] = await Promise.all([
          client.entities.videos.query({ query: { channel_id: Number(id) }, sort: '-created_at', limit: 50 }),
          client.entities.channel_stage_histories.query({ query: { channel_id: Number(id) }, sort: '-created_at', limit: 20 }),
          client.entities.analytics_snapshots.query({ query: { channel_id: Number(id) }, sort: '-created_at', limit: 10 }),
          client.entities.stage_policies.query({ limit: 10 }),
          client.entities.channel_brand_profiles.query({ query: { channel_id: Number(id) }, limit: 1 }),
          client.entities.audience_segments.query({ query: { channel_id: Number(id) }, sort: '-percentage', limit: 20 }),
          client.entities.strategy_snapshots.query({ query: { channel_id: Number(id) }, sort: '-created_at', limit: 10 }),
        ]);
        setVideos(vidRes.data?.items || []);
        setHistory(histRes.data?.items || []);
        setAnalytics(anaRes.data?.items || []);
        setPolicies(polRes.data?.items || []);
        setBrand((brandRes.data?.items || [])[0] || null);
        setSegments(segRes.data?.items || []);
        setStrategies(stratRes.data?.items || []);

        if (ch?.core_niche_id) {
          const niRes = await client.entities.niches.get({ id: String(ch.core_niche_id) });
          setNiche(niRes.data);
        }
      } catch (e) {
        console.error('Failed to load channel', e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id]);

  const handleGenerateContent = async () => {
    if (!id) return;
    setGenerating(true);
    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/content-planning/generate',
        method: 'POST',
        data: { channel_id: Number(id), count: 5 },
      });
      toast.success(`Generated ${res.data.created} video ideas`);
      // Refresh videos
      const vidRes = await client.entities.videos.query({ query: { channel_id: Number(id) }, sort: '-created_at', limit: 50 });
      setVideos(vidRes.data?.items || []);
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Content generation failed');
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E94560]" />
      </div>
    );
  }

  if (!channel) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-4">
        <p className="text-slate-400">Channel not found</p>
        <Button variant="outline" onClick={() => navigate('/channels')}>Back to Channels</Button>
      </div>
    );
  }

  const currentPolicy = policies.find((p) => p.stage === channel.stage);
  const currentStrategy = strategies.find((s) => s.is_current);

  const metricCards = [
    { label: 'Subscribers', value: formatNumber(channel.subscriber_count), icon: Users, color: 'text-blue-400' },
    { label: 'Total Views', value: formatNumber(channel.total_views), icon: Eye, color: 'text-purple-400' },
    { label: 'Videos', value: channel.total_videos, icon: PlayCircle, color: 'text-amber-400' },
    { label: 'Upload Freq', value: `${channel.upload_frequency_hours}h`, icon: Clock, color: 'text-emerald-400' },
  ];

  const scoreCards = [
    { label: 'Authority', value: channel.authority_score, threshold: currentPolicy?.min_authority_score, icon: Shield },
    { label: 'Topic Drift', value: channel.topic_drift_score, threshold: currentPolicy?.max_topic_drift, icon: Target, inverted: true },
    { label: 'Expansion Ready', value: channel.expansion_readiness_score, icon: TrendingUp },
    { label: 'Global Ready', value: channel.global_readiness_score, threshold: currentPolicy?.min_global_readiness, icon: Zap },
  ];

  const engagementLevelColors: Record<string, string> = {
    high: 'bg-emerald-500/20 text-emerald-400',
    medium: 'bg-amber-500/20 text-amber-400',
    low: 'bg-red-500/20 text-red-400',
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/channels')} className="mt-1">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold">{channel.name}</h1>
            <Badge className={`border ${STAGE_COLORS[channel.stage] || ''}`}>
              {STAGE_LABELS[channel.stage] || channel.stage}
            </Badge>
            <Badge className={`border-0 ${STATUS_COLORS[channel.status] || ''}`}>
              {channel.status}
            </Badge>
          </div>
          <div className="flex items-center gap-3 mt-1 text-sm text-slate-400">
            {niche && <span>Niche: {niche.name}</span>}
            <span>·</span>
            <span>{channel.content_mode} · {channel.primary_language.toUpperCase()}</span>
            <span>·</span>
            <span>Created {formatDate(channel.created_at)}</span>
          </div>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {metricCards.map((m) => (
          <Card key={m.label} className="bg-[#16213E] border-slate-700/50">
            <CardContent className="p-3 flex items-center gap-3">
              <m.icon className={`w-6 h-6 ${m.color} opacity-60`} />
              <div>
                <p className="text-lg font-bold">{m.value}</p>
                <p className="text-[10px] text-slate-500 uppercase">{m.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="bg-[#16213E] border border-slate-700/50 flex-wrap h-auto gap-0.5 p-1">
          <TabsTrigger value="overview" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Overview</TabsTrigger>
          <TabsTrigger value="evolution" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Evolution</TabsTrigger>
          <TabsTrigger value="brand" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Brand</TabsTrigger>
          <TabsTrigger value="audience" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Audience</TabsTrigger>
          <TabsTrigger value="strategy" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Strategy</TabsTrigger>
          <TabsTrigger value="videos" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Videos</TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">Analytics</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {scoreCards.map((s) => {
              const pct = Math.min(s.value || 0, 100);
              const isGood = s.inverted ? (s.value || 0) <= (s.threshold || 100) : (s.value || 0) >= (s.threshold || 0);
              return (
                <Card key={s.label} className="bg-[#16213E] border-slate-700/50">
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between mb-2">
                      <s.icon className="w-4 h-4 text-slate-500" />
                      <span className={`text-lg font-bold ${isGood ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {(s.value || 0).toFixed(1)}
                      </span>
                    </div>
                    <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden mb-1">
                      <div className={`h-full rounded-full ${isGood ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${pct}%` }} />
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>{s.label}</span>
                      {s.threshold !== undefined && <span>Target: {s.threshold}</span>}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Retention Metrics */}
          <Card className="bg-[#16213E] border-slate-700/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Retention Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-3 rounded-lg bg-slate-800/30">
                  <p className="text-2xl font-bold text-blue-400">{channel.first_3s_hold?.toFixed(1)}%</p>
                  <p className="text-xs text-slate-500 mt-1">First 3s Hold</p>
                  {currentPolicy && <p className="text-[10px] text-slate-600">Min: {currentPolicy.min_first_3s_hold}%</p>}
                </div>
                <div className="text-center p-3 rounded-lg bg-slate-800/30">
                  <p className="text-2xl font-bold text-purple-400">{channel.avg_watch_pct?.toFixed(1)}%</p>
                  <p className="text-xs text-slate-500 mt-1">Avg Watch %</p>
                  {currentPolicy && <p className="text-[10px] text-slate-600">Min: {currentPolicy.min_avg_watch_pct}%</p>}
                </div>
                <div className="text-center p-3 rounded-lg bg-slate-800/30">
                  <p className="text-2xl font-bold text-amber-400">{channel.rewatch_rate?.toFixed(1)}%</p>
                  <p className="text-xs text-slate-500 mt-1">Rewatch Rate</p>
                  {currentPolicy && <p className="text-[10px] text-slate-600">Min: {currentPolicy.min_rewatch_rate}%</p>}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Evolution Tab */}
        <TabsContent value="evolution" className="space-y-4">
          {currentPolicy && (
            <Card className="bg-[#16213E] border-slate-700/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Current Stage Policy: {STAGE_LABELS[channel.stage]}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                  <div className="p-2 rounded bg-slate-800/30">
                    <p className="text-[10px] text-slate-500">Min Videos</p>
                    <p className="font-medium">{currentPolicy.min_videos_to_promote}</p>
                    <p className={`text-[10px] ${channel.total_videos >= currentPolicy.min_videos_to_promote ? 'text-emerald-400' : 'text-amber-400'}`}>
                      Current: {channel.total_videos}
                    </p>
                  </div>
                  <div className="p-2 rounded bg-slate-800/30">
                    <p className="text-[10px] text-slate-500">Min Authority</p>
                    <p className="font-medium">{currentPolicy.min_authority_score}</p>
                    <p className={`text-[10px] ${channel.authority_score >= currentPolicy.min_authority_score ? 'text-emerald-400' : 'text-amber-400'}`}>
                      Current: {channel.authority_score?.toFixed(1)}
                    </p>
                  </div>
                  <div className="p-2 rounded bg-slate-800/30">
                    <p className="text-[10px] text-slate-500">Max Drift</p>
                    <p className="font-medium">{currentPolicy.max_topic_drift}</p>
                    <p className={`text-[10px] ${channel.topic_drift_score <= currentPolicy.max_topic_drift ? 'text-emerald-400' : 'text-red-400'}`}>
                      Current: {channel.topic_drift_score?.toFixed(1)}
                    </p>
                  </div>
                  <div className="p-2 rounded bg-slate-800/30">
                    <p className="text-[10px] text-slate-500">Content Mix</p>
                    <p className="font-medium text-[10px]">
                      Core {(currentPolicy.core_content_ratio * 100).toFixed(0)}% · Adj {(currentPolicy.adjacent_content_ratio * 100).toFixed(0)}% · Trend {(currentPolicy.trend_content_ratio * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Card className="bg-[#16213E] border-slate-700/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Stage History</CardTitle>
            </CardHeader>
            <CardContent>
              {history.length === 0 ? (
                <p className="text-sm text-slate-500 text-center py-4">No stage transitions yet</p>
              ) : (
                <div className="space-y-3">
                  {history.map((h) => (
                    <div key={h.id} className="flex gap-3 p-3 rounded-lg bg-slate-800/30">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                        h.decision === 'promote' ? 'bg-emerald-500/20 text-emerald-400' :
                        h.decision === 'rollback' ? 'bg-red-500/20 text-red-400' :
                        'bg-slate-500/20 text-slate-400'
                      }`}>
                        {h.decision === 'promote' ? '↑' : h.decision === 'rollback' ? '↓' : '→'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge className={`text-[10px] px-1.5 py-0 border ${STAGE_COLORS[h.from_stage] || ''}`}>
                            {STAGE_LABELS[h.from_stage] || h.from_stage}
                          </Badge>
                          <span className="text-slate-500">→</span>
                          <Badge className={`text-[10px] px-1.5 py-0 border ${STAGE_COLORS[h.to_stage] || ''}`}>
                            {STAGE_LABELS[h.to_stage] || h.to_stage}
                          </Badge>
                          <Badge className={`text-[10px] px-1.5 py-0 border-0 ${
                            h.decision === 'promote' ? 'bg-emerald-500/20 text-emerald-400' :
                            h.decision === 'rollback' ? 'bg-red-500/20 text-red-400' :
                            'bg-slate-500/20 text-slate-400'
                          }`}>
                            {h.decision}
                          </Badge>
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{h.reason}</p>
                        <div className="flex gap-3 mt-1 text-[10px] text-slate-500">
                          <span>Auth: {h.authority_score_at?.toFixed(1)}</span>
                          <span>Drift: {h.topic_drift_at?.toFixed(1)}</span>
                          <span>{formatDateTime(h.created_at)}</span>
                          <span className="capitalize">{h.triggered_by}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Brand Tab */}
        <TabsContent value="brand" className="space-y-4">
          {brand ? (
            <>
              <Card className="bg-[#16213E] border-slate-700/50">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Palette className="w-4 h-4 text-[#E94560]" />
                      Brand Identity v{brand.identity_version}
                    </CardTitle>
                    <Badge variant="outline" className={`text-[10px] ${brand.is_active ? 'border-emerald-500/30 text-emerald-400' : 'border-slate-500/30 text-slate-400'}`}>
                      {brand.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase">Display Name</p>
                        <p className="font-medium">{brand.channel_name_display}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase">Description</p>
                        <p className="text-sm text-slate-300">{brand.short_description || '-'}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase">Slogan</p>
                        <p className="text-sm text-slate-300 italic">{brand.slogan || '-'}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase">Tone</p>
                        <Badge variant="outline" className="border-slate-600 capitalize">{brand.tone}</Badge>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase">Thumbnail Style</p>
                        <p className="text-sm text-slate-300">{brand.thumbnail_style || '-'}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase">Colors</p>
                        <div className="flex items-center gap-3 mt-1">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded border border-slate-600" style={{ backgroundColor: brand.color_primary || '#E94560' }} />
                            <span className="text-xs text-slate-400">{brand.color_primary}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded border border-slate-600" style={{ backgroundColor: brand.color_secondary || '#533483' }} />
                            <span className="text-xs text-slate-400">{brand.color_secondary}</span>
                          </div>
                        </div>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase">Logo Prompt</p>
                        <p className="text-xs text-slate-400 bg-slate-800/30 p-2 rounded">{brand.logo_prompt || '-'}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-500 uppercase">Banner Prompt</p>
                        <p className="text-xs text-slate-400 bg-slate-800/30 p-2 rounded">{brand.banner_prompt || '-'}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-12">
              <Palette className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-500">No brand profile yet</p>
              <p className="text-xs text-slate-600 mt-1">Brand profiles are created when spawning a new channel</p>
            </div>
          )}
        </TabsContent>

        {/* Audience Tab */}
        <TabsContent value="audience" className="space-y-4">
          {segments.length === 0 ? (
            <div className="text-center py-12">
              <UserCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-500">No audience segments yet</p>
              <p className="text-xs text-slate-600 mt-1">Audience data will be populated as the channel grows</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {segments.map((seg) => (
                <Card key={seg.id} className="bg-[#16213E] border-slate-700/50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-medium">{seg.segment_name}</h3>
                      <Badge className={`text-[10px] border-0 ${engagementLevelColors[seg.engagement_level] || 'bg-slate-500/20 text-slate-400'}`}>
                        {seg.engagement_level}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">Share</span>
                        <span className="font-medium">{seg.percentage?.toFixed(1)}%</span>
                      </div>
                      <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div className="h-full bg-[#E94560] rounded-full" style={{ width: `${seg.percentage || 0}%` }} />
                      </div>
                      <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
                        <div>
                          <p className="text-slate-500">Age Range</p>
                          <p>{seg.age_range || '-'}</p>
                        </div>
                        <div>
                          <p className="text-slate-500">Region</p>
                          <p>{seg.primary_region || '-'}</p>
                        </div>
                        <div>
                          <p className="text-slate-500">Retention</p>
                          <p>{seg.retention_rate?.toFixed(1)}%</p>
                        </div>
                        <div>
                          <p className="text-slate-500">Interests</p>
                          <p className="truncate">{seg.interest_tags || '-'}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Strategy Tab */}
        <TabsContent value="strategy" className="space-y-4">
          {strategies.length === 0 ? (
            <div className="text-center py-12">
              <Lightbulb className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-500">No strategy snapshots yet</p>
            </div>
          ) : (
            strategies.map((s) => (
              <Card key={s.id} className={`bg-[#16213E] border-slate-700/50 ${s.is_current ? 'ring-1 ring-[#E94560]/30' : ''}`}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Lightbulb className="w-4 h-4 text-amber-400" />
                      Strategy — {STAGE_LABELS[s.stage] || s.stage}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      {s.is_current && <Badge className="text-[10px] bg-[#E94560]/20 text-[#E94560] border-0">Current</Badge>}
                      <span className="text-[10px] text-slate-500">{formatDate(s.created_at)}</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Content Pillars</p>
                      <p className="font-medium mt-0.5">{s.content_pillars || '-'}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Content Mix</p>
                      <p className="font-medium mt-0.5">{s.content_mix || '-'}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Hook Families</p>
                      <p className="font-medium mt-0.5">{s.hook_families || '-'}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Title Families</p>
                      <p className="font-medium mt-0.5">{s.title_families || '-'}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Thumbnail Families</p>
                      <p className="font-medium mt-0.5">{s.thumbnail_families || '-'}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Upload Tempo</p>
                      <p className="font-medium mt-0.5">{s.upload_tempo_hours}h</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Content Mode</p>
                      <p className="font-medium mt-0.5 capitalize">{s.content_mode || '-'}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Target Audience</p>
                      <p className="font-medium mt-0.5">{s.target_audience || '-'}</p>
                    </div>
                    <div className="p-2 rounded bg-slate-800/30">
                      <p className="text-slate-500">Metrics at Creation</p>
                      <p className="font-medium mt-0.5">Auth: {s.authority_score_at?.toFixed(1)} · Drift: {s.topic_drift_at?.toFixed(1)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* Videos Tab */}
        <TabsContent value="videos" className="space-y-4">
          <div className="flex justify-end">
            <Button
              size="sm"
              onClick={handleGenerateContent}
              disabled={generating}
              className="bg-[#533483] hover:bg-[#533483]/80 text-white"
            >
              {generating ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Lightbulb className="w-4 h-4 mr-1" />}
              Generate Content Ideas
            </Button>
          </div>
          <Card className="bg-[#16213E] border-slate-700/50">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-700/50 text-left text-xs text-slate-500 uppercase">
                      <th className="p-3">Title</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Type</th>
                      <th className="p-3 text-right">Views</th>
                      <th className="p-3 text-right">3s Hold</th>
                      <th className="p-3 text-right">Watch %</th>
                      <th className="p-3 text-right">Rewatch</th>
                      <th className="p-3">Published</th>
                    </tr>
                  </thead>
                  <tbody>
                    {videos.map((v) => (
                      <tr key={v.id} className="border-b border-slate-700/20 hover:bg-slate-800/30">
                        <td className="p-3">
                          <p className="font-medium truncate max-w-[200px]">{v.title}</p>
                          <p className="text-[10px] text-slate-500">{v.content_pillar}</p>
                        </td>
                        <td className="p-3">
                          <Badge className={`text-[10px] px-1.5 py-0 border-0 ${STATUS_COLORS[v.status] || ''}`}>
                            {v.status}
                          </Badge>
                        </td>
                        <td className="p-3">
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-slate-600">
                            {v.content_type}
                          </Badge>
                        </td>
                        <td className="p-3 text-right">{v.views > 0 ? formatNumber(v.views) : '-'}</td>
                        <td className="p-3 text-right">{v.first_3s_hold > 0 ? `${v.first_3s_hold}%` : '-'}</td>
                        <td className="p-3 text-right">{v.avg_watch_pct > 0 ? `${v.avg_watch_pct}%` : '-'}</td>
                        <td className="p-3 text-right">{v.rewatch_rate > 0 ? `${v.rewatch_rate}%` : '-'}</td>
                        <td className="p-3 text-xs text-slate-500">{formatDate(v.published_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {videos.length === 0 && (
                  <p className="text-sm text-slate-500 text-center py-8">No videos yet</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          {analytics.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-8">No analytics data yet</p>
          ) : (
            <div className="space-y-3">
              {analytics.map((a) => (
                <Card key={a.id} className="bg-[#16213E] border-slate-700/50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-sm font-medium">{formatDate(a.period_start)} — {formatDate(a.period_end)}</p>
                      <Badge variant="outline" className="text-[10px] border-slate-600">{a.videos_published} videos</Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                      <div className="p-2 rounded bg-slate-800/30 text-center">
                        <p className="text-sm font-bold">{formatNumber(a.total_views)}</p>
                        <p className="text-[10px] text-slate-500">Views</p>
                      </div>
                      <div className="p-2 rounded bg-slate-800/30 text-center">
                        <p className="text-sm font-bold text-emerald-400">+{formatNumber(a.total_subscribers_gained)}</p>
                        <p className="text-[10px] text-slate-500">Subs Gained</p>
                      </div>
                      <div className="p-2 rounded bg-slate-800/30 text-center">
                        <p className="text-sm font-bold">{a.avg_first_3s_hold?.toFixed(1)}%</p>
                        <p className="text-[10px] text-slate-500">3s Hold</p>
                      </div>
                      <div className="p-2 rounded bg-slate-800/30 text-center">
                        <p className="text-sm font-bold">{a.avg_watch_pct?.toFixed(1)}%</p>
                        <p className="text-[10px] text-slate-500">Watch %</p>
                      </div>
                      <div className="p-2 rounded bg-slate-800/30 text-center">
                        <p className="text-sm font-bold">{a.authority_score?.toFixed(1)}</p>
                        <p className="text-[10px] text-slate-500">Authority</p>
                      </div>
                      <div className="p-2 rounded bg-slate-800/30 text-center">
                        <p className="text-sm font-bold">{a.topic_drift_score?.toFixed(1)}</p>
                        <p className="text-[10px] text-slate-500">Drift</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}