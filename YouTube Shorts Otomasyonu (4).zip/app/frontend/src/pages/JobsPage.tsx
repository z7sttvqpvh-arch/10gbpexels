import { useEffect, useState, useCallback } from 'react';
import { client, GenerationJob, UploadJob, Channel, JOB_TYPE_LABELS, STATUS_COLORS, formatDateTime } from '@/lib/api';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Layers, Upload, RefreshCw, XCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function JobsPage() {
  const [genJobs, setGenJobs] = useState<GenerationJob[]>([]);
  const [uploadJobs, setUploadJobs] = useState<UploadJob[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  const loadData = useCallback(async () => {
    try {
      const [gjRes, ujRes, chRes] = await Promise.all([
        client.entities.generation_jobs.query({ sort: '-created_at', limit: 100 }),
        client.entities.upload_jobs.query({ sort: '-created_at', limit: 50 }),
        client.entities.channels.query({ limit: 50 }),
      ]);
      setGenJobs(gjRes.data?.items || []);
      setUploadJobs(ujRes.data?.items || []);
      setChannels(chRes.data?.items || []);
    } catch (e) {
      console.error('Failed to load jobs', e);
    }
  }, []);

  useEffect(() => {
    loadData().finally(() => setLoading(false));
  }, [loadData]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
    toast.success('Jobs refreshed');
  };

  const handleRetry = async (jobId: number) => {
    try {
      await client.entities.generation_jobs.update({
        id: String(jobId),
        data: { status: 'pending', error_message: '' },
      });
      toast.success('Job queued for retry');
      await loadData();
    } catch {
      toast.error('Failed to retry job');
    }
  };

  const handleCancel = async (jobId: number) => {
    try {
      await client.entities.generation_jobs.update({
        id: String(jobId),
        data: { status: 'cancelled' },
      });
      toast.success('Job cancelled');
      await loadData();
    } catch {
      toast.error('Failed to cancel job');
    }
  };

  const channelMap = new Map(channels.map((c) => [c.id, c]));

  const filteredGenJobs = genJobs.filter((j) => {
    if (statusFilter !== 'all' && j.status !== statusFilter) return false;
    if (typeFilter !== 'all' && j.job_type !== typeFilter) return false;
    return true;
  });

  const running = genJobs.filter((j) => j.status === 'running').length;
  const pending = genJobs.filter((j) => j.status === 'pending').length;
  const failed = genJobs.filter((j) => j.status === 'failed').length;
  const completed = genJobs.filter((j) => j.status === 'completed').length;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E94560]" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Jobs Queue</h1>
          <p className="text-slate-400 text-sm mt-1">Monitor generation and upload pipelines</p>
        </div>
        <Button
          variant="outline"
          className="border-slate-600 text-slate-300"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          {refreshing ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <RefreshCw className="w-4 h-4 mr-1" />}
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-blue-400">{running}</p>
            <p className="text-[10px] text-slate-500 uppercase">Running</p>
          </CardContent>
        </Card>
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-amber-400">{pending}</p>
            <p className="text-[10px] text-slate-500 uppercase">Pending</p>
          </CardContent>
        </Card>
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-red-400">{failed}</p>
            <p className="text-[10px] text-slate-500 uppercase">Failed</p>
          </CardContent>
        </Card>
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-3 text-center">
            <p className="text-2xl font-bold text-emerald-400">{completed}</p>
            <p className="text-[10px] text-slate-500 uppercase">Completed</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="generation" className="space-y-4">
        <TabsList className="bg-[#16213E] border border-slate-700/50">
          <TabsTrigger value="generation" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">
            <Layers className="w-3.5 h-3.5 mr-1" /> Generation ({genJobs.length})
          </TabsTrigger>
          <TabsTrigger value="uploads" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">
            <Upload className="w-3.5 h-3.5 mr-1" /> Uploads ({uploadJobs.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="generation" className="space-y-4">
          <div className="flex gap-3">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36 bg-[#16213E] border-slate-700/50 text-sm">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent className="bg-[#16213E] border-slate-700/50">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="running">Running</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-44 bg-[#16213E] border-slate-700/50 text-sm">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent className="bg-[#16213E] border-slate-700/50">
                <SelectItem value="all">All Types</SelectItem>
                {Object.entries(JOB_TYPE_LABELS).map(([k, v]) => (
                  <SelectItem key={k} value={k}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Card className="bg-[#16213E] border-slate-700/50">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-700/50 text-left text-xs text-slate-500 uppercase">
                      <th className="p-3">ID</th>
                      <th className="p-3">Type</th>
                      <th className="p-3">Channel</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Priority</th>
                      <th className="p-3">Retries</th>
                      <th className="p-3">Started</th>
                      <th className="p-3">Error</th>
                      <th className="p-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredGenJobs.map((j) => {
                      const ch = channelMap.get(j.channel_id);
                      return (
                        <tr key={j.id} className="border-b border-slate-700/20 hover:bg-slate-800/30">
                          <td className="p-3 text-slate-500">#{j.id}</td>
                          <td className="p-3">
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-slate-600">
                              {JOB_TYPE_LABELS[j.job_type] || j.job_type}
                            </Badge>
                          </td>
                          <td className="p-3 text-xs">{ch?.name || `#${j.channel_id}`}</td>
                          <td className="p-3">
                            <Badge className={`text-[10px] px-1.5 py-0 border-0 ${STATUS_COLORS[j.status] || ''}`}>
                              {j.status}
                            </Badge>
                          </td>
                          <td className="p-3 text-center">{j.priority}</td>
                          <td className="p-3 text-center text-xs">{j.retry_count}/{j.max_retries}</td>
                          <td className="p-3 text-xs text-slate-500">{formatDateTime(j.started_at)}</td>
                          <td className="p-3 text-xs text-red-400 max-w-[150px] truncate">{j.error_message || '-'}</td>
                          <td className="p-3">
                            <div className="flex gap-1">
                              {j.status === 'failed' && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-6 w-6 p-0 text-amber-400 hover:text-amber-300"
                                  onClick={() => handleRetry(j.id)}
                                  title="Retry"
                                >
                                  <RefreshCw className="w-3 h-3" />
                                </Button>
                              )}
                              {(j.status === 'pending' || j.status === 'running') && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-6 w-6 p-0 text-red-400 hover:text-red-300"
                                  onClick={() => handleCancel(j.id)}
                                  title="Cancel"
                                >
                                  <XCircle className="w-3 h-3" />
                                </Button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {filteredGenJobs.length === 0 && (
                  <p className="text-sm text-slate-500 text-center py-8">No jobs found</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="uploads" className="space-y-4">
          <Card className="bg-[#16213E] border-slate-700/50">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-700/50 text-left text-xs text-slate-500 uppercase">
                      <th className="p-3">ID</th>
                      <th className="p-3">Channel</th>
                      <th className="p-3">Video</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Attempts</th>
                      <th className="p-3">Scheduled</th>
                      <th className="p-3">YouTube ID</th>
                      <th className="p-3">Error</th>
                    </tr>
                  </thead>
                  <tbody>
                    {uploadJobs.map((j) => {
                      const ch = channelMap.get(j.channel_id);
                      return (
                        <tr key={j.id} className="border-b border-slate-700/20 hover:bg-slate-800/30">
                          <td className="p-3 text-slate-500">#{j.id}</td>
                          <td className="p-3 text-xs">{ch?.name || `#${j.channel_id}`}</td>
                          <td className="p-3 text-xs">#{j.video_id}</td>
                          <td className="p-3">
                            <Badge className={`text-[10px] px-1.5 py-0 border-0 ${STATUS_COLORS[j.status] || ''}`}>
                              {j.status}
                            </Badge>
                          </td>
                          <td className="p-3 text-center text-xs">{j.upload_attempts}/{j.max_attempts}</td>
                          <td className="p-3 text-xs text-slate-500">{formatDateTime(j.scheduled_at)}</td>
                          <td className="p-3 text-xs text-slate-400">{j.youtube_video_id || '-'}</td>
                          <td className="p-3 text-xs text-red-400 max-w-[150px] truncate">{j.error_message || '-'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {uploadJobs.length === 0 && (
                  <p className="text-sm text-slate-500 text-center py-8">No upload jobs</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}