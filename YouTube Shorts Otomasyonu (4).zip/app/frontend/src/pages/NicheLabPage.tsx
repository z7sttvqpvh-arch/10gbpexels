import { useEffect, useState } from 'react';
import { client, NicheCandidate, Niche, STATUS_COLORS, formatDate } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FlaskConical, CheckCircle2, XCircle, Clock, Sparkles, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function NicheLabPage() {
  const [candidates, setCandidates] = useState<NicheCandidate[]>([]);
  const [niches, setNiches] = useState<Niche[]>([]);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [scanCategory, setScanCategory] = useState('Technology');
  const [scanCount, setScanCount] = useState('5');
  const [scanDialogOpen, setScanDialogOpen] = useState(false);
  const [approvingId, setApprovingId] = useState<number | null>(null);

  const loadData = async () => {
    try {
      const [candRes, niRes] = await Promise.all([
        client.entities.niche_candidates.query({ sort: '-total_score', limit: 50 }),
        client.entities.niches.query({ sort: '-created_at', limit: 50 }),
      ]);
      setCandidates(candRes.data?.items || []);
      setNiches(niRes.data?.items || []);
    } catch (e) {
      console.error('Failed to load niche data', e);
    }
  };

  useEffect(() => {
    loadData().finally(() => setLoading(false));
  }, []);

  const handleScan = async () => {
    setScanning(true);
    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/niche-discovery/discover',
        method: 'POST',
        data: { category: scanCategory, count: parseInt(scanCount) },
      });
      toast.success(`Discovered ${res.data.created} new niche candidates`);
      setScanDialogOpen(false);
      await loadData();
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Niche scan failed');
    } finally {
      setScanning(false);
    }
  };

  const handleApprove = async (candidateId: number) => {
    setApprovingId(candidateId);
    try {
      await client.apiCall.invoke({
        url: '/api/v1/niche-discovery/approve',
        method: 'POST',
        data: { candidate_id: candidateId },
      });
      toast.success('Niche candidate approved');
      await loadData();
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Approval failed');
    } finally {
      setApprovingId(null);
    }
  };

  const handleReject = async (candidateId: number) => {
    try {
      await client.entities.niche_candidates.update({
        id: String(candidateId),
        data: { status: 'rejected' },
      });
      toast.success('Niche candidate rejected');
      await loadData();
    } catch (e: any) {
      toast.error('Rejection failed');
    }
  };

  const pendingCandidates = candidates.filter((c) => c.status === 'pending');
  const approvedCandidates = candidates.filter((c) => c.status === 'approved');
  const rejectedCandidates = candidates.filter((c) => c.status === 'rejected');

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E94560]" />
      </div>
    );
  }

  const ScoreBar = ({ label, value, max = 100 }: { label: string; value: number; max?: number }) => (
    <div>
      <div className="flex justify-between text-[10px] text-slate-500 mb-0.5">
        <span>{label}</span>
        <span>{value}/{max}</span>
      </div>
      <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
          style={{ width: `${(value / max) * 100}%` }}
        />
      </div>
    </div>
  );

  const CandidateCard = ({ c }: { c: NicheCandidate }) => (
    <Card className="bg-[#16213E] border-slate-700/50 hover:border-purple-500/30 transition-all">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-semibold text-sm">{c.niche_name}</h3>
            <p className="text-[10px] text-slate-500">{c.category} · {c.sub_category}</p>
          </div>
          <Badge className={`text-[10px] px-1.5 py-0 border-0 ${STATUS_COLORS[c.status] || ''}`}>
            {c.status}
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
            {c.total_score.toFixed(1)}
          </div>
          <div className="text-[10px] text-slate-500">
            <p>Total Score</p>
            <p>{c.content_ideas_count} content ideas</p>
          </div>
        </div>

        <div className="space-y-1.5">
          <ScoreBar label="Gap Score" value={c.gap_score} />
          <ScoreBar label="Visual" value={c.visual_score} />
          <ScoreBar label="Repeatability" value={c.repeatability_score} />
          <ScoreBar label="Global Transfer" value={c.global_transfer_score} />
          <ScoreBar label="Monetization" value={c.monetization_score} />
          <ScoreBar label="Brandability" value={c.brandability_score} />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="p-2 rounded bg-slate-800/30 text-center">
            <p className={`text-sm font-bold ${c.saturation_score > 60 ? 'text-red-400' : 'text-emerald-400'}`}>
              {c.saturation_score}
            </p>
            <p className="text-[10px] text-slate-500">Saturation</p>
          </div>
          <div className="p-2 rounded bg-slate-800/30 text-center">
            <p className={`text-sm font-bold ${c.risk_score > 50 ? 'text-red-400' : 'text-emerald-400'}`}>
              {c.risk_score}
            </p>
            <p className="text-[10px] text-slate-500">Risk</p>
          </div>
        </div>

        <div className="p-2 rounded bg-slate-800/30">
          <p className="text-[10px] text-slate-500">Recommendation</p>
          <p className="text-xs font-medium capitalize">{c.recommended_action.replace(/_/g, ' ')}</p>
        </div>

        {c.notes && <p className="text-xs text-slate-400 italic">{c.notes}</p>}

        <div className="flex justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-700/30">
          <span className="capitalize">{c.source?.replace(/_/g, ' ')}</span>
          <span>{formatDate(c.created_at)}</span>
        </div>

        {c.status === 'pending' && (
          <div className="flex gap-2 pt-1">
            <Button
              size="sm"
              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs h-8"
              onClick={() => handleApprove(c.id)}
              disabled={approvingId === c.id}
            >
              {approvingId === c.id ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <CheckCircle2 className="w-3 h-3 mr-1" />}
              Approve
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="flex-1 border-red-500/30 text-red-400 hover:bg-red-500/10 text-xs h-8"
              onClick={() => handleReject(c.id)}
            >
              <XCircle className="w-3 h-3 mr-1" /> Reject
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Niche Lab</h1>
          <p className="text-slate-400 text-sm mt-1">Discover and evaluate niche opportunities</p>
        </div>
        <Dialog open={scanDialogOpen} onOpenChange={setScanDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#533483] hover:bg-[#533483]/80 text-white">
              <Sparkles className="w-4 h-4 mr-1" /> Run Niche Scan
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[#16213E] border-slate-700/50 text-slate-100">
            <DialogHeader>
              <DialogTitle>AI Niche Discovery</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Category</label>
                <Select value={scanCategory} onValueChange={setScanCategory}>
                  <SelectTrigger className="bg-slate-800/50 border-slate-700/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16213E] border-slate-700/50">
                    {['Technology', 'Science', 'Education', 'Entertainment', 'Health & Fitness', 'Finance', 'Travel', 'Food & Cooking', 'Gaming', 'DIY & Crafts', 'Nature', 'History', 'Psychology', 'Art & Design'].map((cat) => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Number of niches to discover</label>
                <Input
                  type="number"
                  value={scanCount}
                  onChange={(e) => setScanCount(e.target.value)}
                  min="1"
                  max="10"
                  className="bg-slate-800/50 border-slate-700/50"
                />
              </div>
              <Button
                onClick={handleScan}
                disabled={scanning}
                className="w-full bg-[#533483] hover:bg-[#533483]/80 text-white"
              >
                {scanning ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Sparkles className="w-4 h-4 mr-1" />}
                {scanning ? 'Discovering...' : 'Start Discovery'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="candidates" className="space-y-4">
        <TabsList className="bg-[#16213E] border border-slate-700/50">
          <TabsTrigger value="candidates" className="data-[state=active]:bg-purple-500/15 data-[state=active]:text-purple-400">
            <Clock className="w-3.5 h-3.5 mr-1" /> Pending ({pendingCandidates.length})
          </TabsTrigger>
          <TabsTrigger value="approved" className="data-[state=active]:bg-emerald-500/15 data-[state=active]:text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Approved ({approvedCandidates.length})
          </TabsTrigger>
          <TabsTrigger value="rejected" className="data-[state=active]:bg-red-500/15 data-[state=active]:text-red-400">
            <XCircle className="w-3.5 h-3.5 mr-1" /> Rejected ({rejectedCandidates.length})
          </TabsTrigger>
          <TabsTrigger value="active" className="data-[state=active]:bg-blue-500/15 data-[state=active]:text-blue-400">
            <FlaskConical className="w-3.5 h-3.5 mr-1" /> Active Niches ({niches.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="candidates">
          {pendingCandidates.length === 0 ? (
            <div className="flex flex-col items-center py-16">
              <FlaskConical className="w-16 h-16 text-slate-600 mb-4" />
              <p className="text-slate-400 text-sm">No pending niche candidates</p>
              <p className="text-xs text-slate-500 mt-1">Run a Niche Scan to discover new opportunities</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {pendingCandidates.map((c) => <CandidateCard key={c.id} c={c} />)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="approved">
          {approvedCandidates.length === 0 ? (
            <p className="text-slate-500 text-center py-8">No approved candidates</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {approvedCandidates.map((c) => <CandidateCard key={c.id} c={c} />)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="rejected">
          {rejectedCandidates.length === 0 ? (
            <p className="text-slate-500 text-center py-8">No rejected candidates</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {rejectedCandidates.map((c) => <CandidateCard key={c.id} c={c} />)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="active">
          {niches.length === 0 ? (
            <p className="text-slate-500 text-center py-8">No active niches</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {niches.map((n) => (
                <Card key={n.id} className="bg-[#16213E] border-slate-700/50">
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-sm">{n.name}</h3>
                        <p className="text-[10px] text-slate-500">{n.category} · {n.sub_category}</p>
                      </div>
                      <Badge className={`text-[10px] px-1.5 py-0 border-0 ${STATUS_COLORS[n.status] || ''}`}>
                        {n.status}
                      </Badge>
                    </div>
                    {n.description && <p className="text-xs text-slate-400">{n.description}</p>}
                    <div className="space-y-1.5">
                      <ScoreBar label="Visual Suitability" value={n.visual_suitability} />
                      <ScoreBar label="Repeatability" value={n.repeatability_score} />
                      <ScoreBar label="Global Transfer" value={n.global_transfer_score} />
                      <ScoreBar label="Monetization" value={n.monetization_potential} />
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-700/30">
                      <span className="capitalize">Saturation: {n.saturation_level}</span>
                      <span>{formatDate(n.created_at)}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}