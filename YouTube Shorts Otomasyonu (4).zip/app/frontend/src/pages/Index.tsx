import { useEffect, useState } from 'react';
import { client, Channel, GenerationJob, Video, AnalyticsSnapshot, formatNumber, STAGE_LABELS, STAGE_COLORS, STATUS_COLORS } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tv2, Eye, Users, PlayCircle, Layers, AlertTriangle, TrendingUp, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function DashboardPage() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [jobs, setJobs] = useState<GenerationJob[]>([]);
  const [videos, setVideos] = useState<Video[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsSnapshot[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    async function load() {
      try {
        const [chRes, jobRes, vidRes, anaRes] = await Promise.all([
          client.entities.channels.query({ sort: '-updated_at', limit: 20 }),
          client.entities.generation_jobs.query({ sort: '-created_at', limit: 20 }),
          client.entities.videos.query({ sort: '-created_at', limit: 10 }),
          client.entities.analytics_snapshots.query({ sort: '-created_at', limit: 20 }),
        ]);
        setChannels(chRes.data?.items || []);
        setJobs(jobRes.data?.items || []);
        setVideos(vidRes.data?.items || []);
        setAnalytics(anaRes.data?.items || []);
      } catch (e) {
        console.error('Failed to load dashboard data', e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const totalSubs = channels.reduce((s, c) => s + (c.subscriber_count || 0), 0);
  const totalViews = channels.reduce((s, c) => s + (c.total_views || 0), 0);
  const totalVids = channels.reduce((s, c) => s + (c.total_videos || 0), 0);
  const activeChannels = channels.filter((c) => c.status === 'active').length;
  const runningJobs = jobs.filter((j) => j.status === 'running').length;
  const failedJobs = jobs.filter((j) => j.status === 'failed').length;
  const pendingJobs = jobs.filter((j) => j.status === 'pending').length;

  const stats = [
    { label: 'Active Channels', value: activeChannels, total: channels.length, icon: Tv2, color: 'text-blue-400' },
    { label: 'Total Subscribers', value: formatNumber(totalSubs), icon: Users, color: 'text-emerald-400' },
    { label: 'Total Views', value: formatNumber(totalViews), icon: Eye, color: 'text-purple-400' },
    { label: 'Total Videos', value: totalVids, icon: PlayCircle, color: 'text-amber-400' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E94560]" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-slate-400 text-sm mt-1">YouTube Shorts Automation Overview</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <Card key={s.label} className="bg-[#16213E] border-slate-700/50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-wider">{s.label}</p>
                  <p className="text-2xl font-bold mt-1">{s.value}</p>
                  {'total' in s && s.total !== undefined && (
                    <p className="text-xs text-slate-500 mt-0.5">of {s.total} total</p>
                  )}
                </div>
                <s.icon className={`w-8 h-8 ${s.color} opacity-60`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Jobs Status + Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Jobs Summary */}
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400" />
              Jobs Queue
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Running</span>
              <Badge className="bg-blue-500/20 text-blue-400 border-0">{runningJobs}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Pending</span>
              <Badge className="bg-amber-500/20 text-amber-400 border-0">{pendingJobs}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Failed</span>
              <Badge className="bg-red-500/20 text-red-400 border-0">{failedJobs}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Total</span>
              <Badge className="bg-slate-500/20 text-slate-400 border-0">{jobs.length}</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Channel Health */}
        <Card className="bg-[#16213E] border-slate-700/50 lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Channel Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {channels.map((ch) => (
                <div
                  key={ch.id}
                  className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-800/30 hover:bg-slate-800/60 cursor-pointer transition-colors"
                  onClick={() => navigate(`/channels/${ch.id}`)}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm truncate">{ch.name}</span>
                      <Badge className={`text-[10px] px-1.5 py-0 border ${STAGE_COLORS[ch.stage] || ''}`}>
                        {STAGE_LABELS[ch.stage] || ch.stage}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                      <span>{formatNumber(ch.subscriber_count)} subs</span>
                      <span>{ch.total_videos} videos</span>
                    </div>
                  </div>
                  {/* Authority Score Bar */}
                  <div className="w-24 shrink-0">
                    <div className="flex items-center justify-between text-[10px] text-slate-500 mb-0.5">
                      <span>Authority</span>
                      <span>{ch.authority_score?.toFixed(0)}</span>
                    </div>
                    <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full transition-all"
                        style={{ width: `${Math.min(ch.authority_score || 0, 100)}%` }}
                      />
                    </div>
                  </div>
                  {/* Drift indicator */}
                  <div className="w-16 shrink-0 text-right">
                    <div className="text-[10px] text-slate-500">Drift</div>
                    <div className={`text-xs font-medium ${(ch.topic_drift_score || 0) > 25 ? 'text-red-400' : 'text-emerald-400'}`}>
                      {ch.topic_drift_score?.toFixed(1)}%
                    </div>
                  </div>
                </div>
              ))}
              {channels.length === 0 && (
                <p className="text-sm text-slate-500 text-center py-4">No channels yet</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Videos + Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Videos */}
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <PlayCircle className="w-4 h-4 text-amber-400" />
              Recent Videos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {videos.slice(0, 5).map((v) => (
                <div key={v.id} className="flex items-center gap-3 p-2 rounded-lg bg-slate-800/30">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{v.title}</p>
                    <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500">
                      <Badge className={`text-[10px] px-1.5 py-0 border-0 ${STATUS_COLORS[v.status] || ''}`}>
                        {v.status}
                      </Badge>
                      {v.views > 0 && <span>{formatNumber(v.views)} views</span>}
                    </div>
                  </div>
                  {v.avg_watch_pct > 0 && (
                    <div className="text-right shrink-0">
                      <div className="text-xs font-medium">{v.avg_watch_pct}%</div>
                      <div className="text-[10px] text-slate-500">watch</div>
                    </div>
                  )}
                </div>
              ))}
              {videos.length === 0 && (
                <p className="text-sm text-slate-500 text-center py-4">No videos yet</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Alerts / Warnings */}
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Alerts & Warnings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {failedJobs > 0 && (
                <div className="flex items-start gap-2 p-2.5 rounded-lg bg-red-500/5 border border-red-500/20">
                  <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-red-400">{failedJobs} Failed Job{failedJobs > 1 ? 's' : ''}</p>
                    <p className="text-xs text-slate-500 mt-0.5">Check the Jobs Queue for details</p>
                  </div>
                </div>
              )}
              {channels.filter((c) => (c.topic_drift_score || 0) > 20).map((c) => (
                <div key={c.id} className="flex items-start gap-2 p-2.5 rounded-lg bg-amber-500/5 border border-amber-500/20">
                  <TrendingUp className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-amber-400">High Topic Drift: {c.name}</p>
                    <p className="text-xs text-slate-500 mt-0.5">Drift score {c.topic_drift_score?.toFixed(1)}% exceeds threshold</p>
                  </div>
                </div>
              ))}
              {channels.filter((c) => c.status === 'paused').map((c) => (
                <div key={c.id} className="flex items-start gap-2 p-2.5 rounded-lg bg-slate-500/5 border border-slate-500/20">
                  <Clock className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-slate-400">Paused: {c.name}</p>
                    <p className="text-xs text-slate-500 mt-0.5">Channel is currently paused</p>
                  </div>
                </div>
              ))}
              {failedJobs === 0 && channels.filter((c) => (c.topic_drift_score || 0) > 20).length === 0 && channels.filter((c) => c.status === 'paused').length === 0 && (
                <p className="text-sm text-emerald-400 text-center py-4">✓ All systems healthy</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}