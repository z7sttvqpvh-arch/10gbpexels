import { useEffect, useState } from 'react';
import { client, Channel, Niche, formatNumber, STAGE_LABELS, STAGE_COLORS, STATUS_COLORS, formatDate } from '@/lib/api';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Search, Plus, Tv2, Eye, Users, PlayCircle, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function ChannelsPage() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [niches, setNiches] = useState<Niche[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [stageFilter, setStageFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [spawnOpen, setSpawnOpen] = useState(false);
  const [spawning, setSpawning] = useState(false);
  const [newName, setNewName] = useState('');
  const [newSlug, setNewSlug] = useState('');
  const [newNicheId, setNewNicheId] = useState('');
  const [newLanguage, setNewLanguage] = useState('en');
  const [newContentMode, setNewContentMode] = useState('faceless');
  const navigate = useNavigate();

  const loadData = async () => {
    try {
      const [chRes, niRes] = await Promise.all([
        client.entities.channels.query({ sort: '-updated_at', limit: 50 }),
        client.entities.niches.query({ limit: 50 }),
      ]);
      setChannels(chRes.data?.items || []);
      setNiches(niRes.data?.items || []);
    } catch (e) {
      console.error('Failed to load channels', e);
    }
  };

  useEffect(() => {
    loadData().finally(() => setLoading(false));
  }, []);

  const nicheMap = new Map(niches.map((n) => [n.id, n]));

  const filtered = channels.filter((ch) => {
    if (search && !ch.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (stageFilter !== 'all' && ch.stage !== stageFilter) return false;
    if (statusFilter !== 'all' && ch.status !== statusFilter) return false;
    return true;
  });

  const handleSpawn = async () => {
    if (!newName.trim() || !newSlug.trim() || !newNicheId) {
      toast.error('Please fill in all required fields');
      return;
    }
    setSpawning(true);
    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/channel-spawn/create',
        method: 'POST',
        data: {
          name: newName.trim(),
          slug: newSlug.trim().toLowerCase().replace(/\s+/g, '-'),
          niche_id: parseInt(newNicheId),
          language: newLanguage,
          content_mode: newContentMode,
        },
      });
      toast.success(`Channel "${res.data.name}" created successfully`);
      setSpawnOpen(false);
      setNewName('');
      setNewSlug('');
      setNewNicheId('');
      await loadData();
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Failed to create channel');
    } finally {
      setSpawning(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E94560]" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Channels</h1>
          <p className="text-slate-400 text-sm mt-1">{channels.length} channels managed</p>
        </div>
        <Dialog open={spawnOpen} onOpenChange={setSpawnOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#E94560] hover:bg-[#E94560]/80 text-white">
              <Plus className="w-4 h-4 mr-1" /> New Channel
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-[#16213E] border-slate-700/50 text-slate-100">
            <DialogHeader>
              <DialogTitle>Spawn New Channel</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Channel Name *</label>
                <Input
                  value={newName}
                  onChange={(e) => {
                    setNewName(e.target.value);
                    setNewSlug(e.target.value.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, ''));
                  }}
                  placeholder="e.g. Tech Facts Daily"
                  className="bg-slate-800/50 border-slate-700/50"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Slug *</label>
                <Input
                  value={newSlug}
                  onChange={(e) => setNewSlug(e.target.value)}
                  placeholder="e.g. tech-facts-daily"
                  className="bg-slate-800/50 border-slate-700/50"
                />
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Niche *</label>
                <Select value={newNicheId} onValueChange={setNewNicheId}>
                  <SelectTrigger className="bg-slate-800/50 border-slate-700/50">
                    <SelectValue placeholder="Select a niche" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16213E] border-slate-700/50">
                    {niches.map((n) => (
                      <SelectItem key={n.id} value={String(n.id)}>{n.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Language</label>
                  <Select value={newLanguage} onValueChange={setNewLanguage}>
                    <SelectTrigger className="bg-slate-800/50 border-slate-700/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[#16213E] border-slate-700/50">
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Spanish</SelectItem>
                      <SelectItem value="pt">Portuguese</SelectItem>
                      <SelectItem value="fr">French</SelectItem>
                      <SelectItem value="de">German</SelectItem>
                      <SelectItem value="tr">Turkish</SelectItem>
                      <SelectItem value="ja">Japanese</SelectItem>
                      <SelectItem value="ko">Korean</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Content Mode</label>
                  <Select value={newContentMode} onValueChange={setNewContentMode}>
                    <SelectTrigger className="bg-slate-800/50 border-slate-700/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[#16213E] border-slate-700/50">
                      <SelectItem value="faceless">Faceless</SelectItem>
                      <SelectItem value="avatar">Avatar</SelectItem>
                      <SelectItem value="mixed">Mixed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                onClick={handleSpawn}
                disabled={spawning}
                className="w-full bg-[#E94560] hover:bg-[#E94560]/80 text-white"
              >
                {spawning ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Plus className="w-4 h-4 mr-1" />}
                {spawning ? 'Creating...' : 'Create Channel'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <Input
            placeholder="Search channels..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-[#16213E] border-slate-700/50 text-sm"
          />
        </div>
        <Select value={stageFilter} onValueChange={setStageFilter}>
          <SelectTrigger className="w-44 bg-[#16213E] border-slate-700/50 text-sm">
            <SelectValue placeholder="All Stages" />
          </SelectTrigger>
          <SelectContent className="bg-[#16213E] border-slate-700/50">
            <SelectItem value="all">All Stages</SelectItem>
            <SelectItem value="micro_niche">Micro Niche</SelectItem>
            <SelectItem value="adjacent_bridge">Adjacent Bridge</SelectItem>
            <SelectItem value="global_expand">Global Expand</SelectItem>
            <SelectItem value="category_domination">Category Domination</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36 bg-[#16213E] border-slate-700/50 text-sm">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent className="bg-[#16213E] border-slate-700/50">
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="incubating">Incubating</SelectItem>
            <SelectItem value="paused">Paused</SelectItem>
            <SelectItem value="frozen">Frozen</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Channel Cards */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16">
          <Tv2 className="w-16 h-16 text-slate-600 mb-4" />
          <p className="text-slate-400">No channels found</p>
          <p className="text-xs text-slate-500 mt-1">Create a new channel to get started</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((ch) => {
            const niche = nicheMap.get(ch.core_niche_id);
            return (
              <Card
                key={ch.id}
                className="bg-[#16213E] border-slate-700/50 hover:border-[#E94560]/30 cursor-pointer transition-all hover:shadow-lg hover:shadow-[#E94560]/5"
                onClick={() => navigate(`/channels/${ch.id}`)}
              >
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#E94560]/20 to-[#533483]/20 flex items-center justify-center">
                        <Tv2 className="w-4 h-4 text-[#E94560]" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm">{ch.name}</h3>
                        {niche && <p className="text-[10px] text-slate-500">{niche.name}</p>}
                      </div>
                    </div>
                    <Badge className={`text-[10px] px-1.5 py-0 border-0 ${STATUS_COLORS[ch.status] || ''}`}>
                      {ch.status}
                    </Badge>
                  </div>

                  <Badge className={`text-xs px-2 py-0.5 border ${STAGE_COLORS[ch.stage] || ''}`}>
                    {STAGE_LABELS[ch.stage] || ch.stage}
                  </Badge>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-center p-2 rounded-lg bg-slate-800/30">
                      <Users className="w-3.5 h-3.5 text-slate-500 mx-auto mb-0.5" />
                      <p className="text-sm font-semibold">{formatNumber(ch.subscriber_count)}</p>
                      <p className="text-[10px] text-slate-500">Subs</p>
                    </div>
                    <div className="text-center p-2 rounded-lg bg-slate-800/30">
                      <Eye className="w-3.5 h-3.5 text-slate-500 mx-auto mb-0.5" />
                      <p className="text-sm font-semibold">{formatNumber(ch.total_views)}</p>
                      <p className="text-[10px] text-slate-500">Views</p>
                    </div>
                    <div className="text-center p-2 rounded-lg bg-slate-800/30">
                      <PlayCircle className="w-3.5 h-3.5 text-slate-500 mx-auto mb-0.5" />
                      <p className="text-sm font-semibold">{ch.total_videos}</p>
                      <p className="text-[10px] text-slate-500">Videos</p>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div>
                      <div className="flex justify-between text-[10px] text-slate-500 mb-0.5">
                        <span>Authority</span>
                        <span>{ch.authority_score?.toFixed(0)}/100</span>
                      </div>
                      <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full" style={{ width: `${ch.authority_score || 0}%` }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-[10px] text-slate-500 mb-0.5">
                        <span>Topic Drift</span>
                        <span className={(ch.topic_drift_score || 0) > 25 ? 'text-red-400' : ''}>{ch.topic_drift_score?.toFixed(1)}%</span>
                      </div>
                      <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${(ch.topic_drift_score || 0) > 25 ? 'bg-red-500' : 'bg-emerald-500'}`} style={{ width: `${ch.topic_drift_score || 0}%` }} />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-700/30">
                    <span>{ch.content_mode} · {ch.primary_language.toUpperCase()}</span>
                    <span>Updated {formatDate(ch.updated_at)}</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}