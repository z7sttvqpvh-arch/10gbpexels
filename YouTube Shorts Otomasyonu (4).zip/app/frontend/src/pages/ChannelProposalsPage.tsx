import { useState, useEffect, useCallback } from 'react';
import { client, STATUS_COLORS, formatDateTime } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  CheckCircle2, XCircle, Loader2, FileText, Tv2, Sparkles,
  RefreshCw, Edit3, Globe, Users, Tag, Youtube, Bot, Shield,
  ThumbsUp, ThumbsDown, Clock, AlertTriangle, Zap
} from 'lucide-react';
import { toast } from 'sonner';

interface Proposal {
  id: number;
  niche_id: number;
  niche_name: string;
  proposed_name: string;
  proposed_slug: string;
  proposed_description: string | null;
  proposed_language: string | null;
  content_mode: string | null;
  target_audience: string | null;
  category: string | null;
  status: string;
  channel_id: number | null;
  youtube_channel_id: string | null;
  rejection_reason: string | null;
  error_message: string | null;
  auto_content_enabled: number | null;
  created_at: string | null;
  updated_at: string | null;
}

export default function ChannelProposalsPage() {
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [approvingId, setApprovingId] = useState<number | null>(null);
  const [rejectingId, setRejectingId] = useState<number | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<Partial<Proposal>>({});
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectDialog, setShowRejectDialog] = useState<number | null>(null);

  const loadProposals = useCallback(async () => {
    try {
      const res = await client.entities.channel_proposals.query({
        sort: '-created_at',
        limit: 100,
      });
      setProposals(res.data?.items || []);
    } catch (e) {
      console.error('Failed to load proposals', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProposals();
  }, [loadProposals]);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/entities/channel_proposals/actions/generate',
        method: 'POST',
        data: {},
        timeout: 60000,
      });
      toast.success(`${res.data?.created || 0} yeni kanal önerisi oluşturuldu`);
      await loadProposals();
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Öneri oluşturma başarısız');
    } finally {
      setGenerating(false);
    }
  };

  const handleApprove = async (id: number) => {
    setApprovingId(id);
    try {
      const res = await client.apiCall.invoke({
        url: `/api/v1/entities/channel_proposals/actions/${id}/approve`,
        method: 'POST',
        data: { auto_content: true },
        timeout: 60000,
      });
      toast.success(`Kanal oluşturuldu: ${res.data?.channel_name || ''}`);
      if (res.data?.youtube_status) {
        toast.info(res.data.youtube_status);
      }
      await loadProposals();
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Onaylama başarısız');
    } finally {
      setApprovingId(null);
    }
  };

  const handleReject = async (id: number) => {
    setRejectingId(id);
    try {
      await client.apiCall.invoke({
        url: `/api/v1/entities/channel_proposals/actions/${id}/reject`,
        method: 'POST',
        data: { reason: rejectReason },
      });
      toast.success('Öneri reddedildi');
      setShowRejectDialog(null);
      setRejectReason('');
      await loadProposals();
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Reddetme başarısız');
    } finally {
      setRejectingId(null);
    }
  };

  const handleEdit = (proposal: Proposal) => {
    setEditingId(proposal.id);
    setEditForm({
      proposed_name: proposal.proposed_name,
      proposed_slug: proposal.proposed_slug,
      proposed_description: proposal.proposed_description,
      proposed_language: proposal.proposed_language,
      content_mode: proposal.content_mode,
      target_audience: proposal.target_audience,
    });
  };

  const handleSaveEdit = async (id: number) => {
    try {
      await client.entities.channel_proposals.update(id, editForm);
      toast.success('Öneri güncellendi');
      setEditingId(null);
      await loadProposals();
    } catch (e: any) {
      toast.error('Güncelleme başarısız');
    }
  };

  const pending = proposals.filter((p) => p.status === 'pending');
  const approved = proposals.filter((p) => p.status === 'created' || p.status === 'approved');
  const rejected = proposals.filter((p) => p.status === 'rejected');
  const failed = proposals.filter((p) => p.status === 'failed');

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E94560]" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Shield className="w-7 h-7 text-[#E94560]" />
            Kanal Önerileri
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            AI tarafından önerilen kanalları inceleyin, düzenleyin ve onaylayın
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={loadProposals}
            className="border-slate-600 text-slate-300 hover:bg-slate-800"
          >
            <RefreshCw className="w-4 h-4 mr-1" /> Yenile
          </Button>
          <Button
            onClick={handleGenerate}
            disabled={generating}
            className="bg-gradient-to-r from-[#E94560] to-[#533483] hover:opacity-90 text-white"
          >
            {generating ? (
              <Loader2 className="w-4 h-4 animate-spin mr-1" />
            ) : (
              <Sparkles className="w-4 h-4 mr-1" />
            )}
            {generating ? 'Oluşturuluyor...' : 'Öneri Oluştur'}
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center">
              <Clock className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{pending.length}</p>
              <p className="text-xs text-slate-500">Bekleyen</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{approved.length}</p>
              <p className="text-xs text-slate-500">Onaylanan</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
              <XCircle className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{rejected.length}</p>
              <p className="text-xs text-slate-500">Reddedilen</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-500/20 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-slate-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{failed.length}</p>
              <p className="text-xs text-slate-500">Başarısız</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList className="bg-[#16213E] border border-slate-700/50">
          <TabsTrigger value="pending" className="data-[state=active]:bg-amber-500/15 data-[state=active]:text-amber-400">
            Bekleyen ({pending.length})
          </TabsTrigger>
          <TabsTrigger value="approved" className="data-[state=active]:bg-emerald-500/15 data-[state=active]:text-emerald-400">
            Onaylanan ({approved.length})
          </TabsTrigger>
          <TabsTrigger value="rejected" className="data-[state=active]:bg-red-500/15 data-[state=active]:text-red-400">
            Reddedilen ({rejected.length})
          </TabsTrigger>
          <TabsTrigger value="all" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">
            Tümü ({proposals.length})
          </TabsTrigger>
        </TabsList>

        {/* Pending Tab */}
        <TabsContent value="pending" className="space-y-4">
          {pending.length === 0 ? (
            <div className="text-center py-12">
              <Shield className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-500">Bekleyen öneri yok</p>
              <p className="text-xs text-slate-600 mt-1">
                "Öneri Oluştur" butonuna tıklayarak yeni öneriler oluşturun
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Bulk actions */}
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={async () => {
                    for (const p of pending) {
                      await handleApprove(p.id);
                    }
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  <ThumbsUp className="w-3.5 h-3.5 mr-1" /> Tümünü Onayla
                </Button>
              </div>

              {pending.map((proposal) => (
                <ProposalCard
                  key={proposal.id}
                  proposal={proposal}
                  isEditing={editingId === proposal.id}
                  editForm={editForm}
                  setEditForm={setEditForm}
                  approvingId={approvingId}
                  rejectingId={rejectingId}
                  showRejectDialog={showRejectDialog}
                  rejectReason={rejectReason}
                  setRejectReason={setRejectReason}
                  onApprove={() => handleApprove(proposal.id)}
                  onReject={() => handleReject(proposal.id)}
                  onEdit={() => handleEdit(proposal)}
                  onSaveEdit={() => handleSaveEdit(proposal.id)}
                  onCancelEdit={() => setEditingId(null)}
                  onShowReject={() => setShowRejectDialog(proposal.id)}
                  onHideReject={() => { setShowRejectDialog(null); setRejectReason(''); }}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* Approved Tab */}
        <TabsContent value="approved" className="space-y-4">
          {approved.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle2 className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-500">Henüz onaylanan öneri yok</p>
            </div>
          ) : (
            <div className="space-y-3">
              {approved.map((proposal) => (
                <Card key={proposal.id} className="bg-[#16213E] border-emerald-500/20">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                          <Tv2 className="w-5 h-5 text-emerald-400" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-sm">{proposal.proposed_name}</h3>
                          <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5">
                            <span>{proposal.niche_name}</span>
                            <span>·</span>
                            <span>{proposal.proposed_language}</span>
                            {proposal.channel_id && (
                              <>
                                <span>·</span>
                                <span className="text-emerald-400">Kanal #{proposal.channel_id}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {proposal.youtube_channel_id && (
                          <Badge className="bg-red-500/20 text-red-400 border-0 text-[10px]">
                            <Youtube className="w-3 h-3 mr-0.5" /> YT Bağlı
                          </Badge>
                        )}
                        {proposal.auto_content_enabled ? (
                          <Badge className="bg-blue-500/20 text-blue-400 border-0 text-[10px]">
                            <Bot className="w-3 h-3 mr-0.5" /> Oto İçerik
                          </Badge>
                        ) : null}
                        <Badge className="bg-emerald-500/20 text-emerald-400 border-0 text-xs">
                          Oluşturuldu
                        </Badge>
                      </div>
                    </div>
                    {proposal.error_message && (
                      <p className="text-[10px] text-amber-400 mt-2 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> {proposal.error_message}
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Rejected Tab */}
        <TabsContent value="rejected" className="space-y-4">
          {rejected.length === 0 ? (
            <div className="text-center py-12">
              <XCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-500">Reddedilen öneri yok</p>
            </div>
          ) : (
            <div className="space-y-3">
              {rejected.map((proposal) => (
                <Card key={proposal.id} className="bg-[#16213E] border-red-500/20 opacity-75">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-sm text-slate-400">{proposal.proposed_name}</h3>
                        <p className="text-[10px] text-slate-500 mt-0.5">{proposal.niche_name} · {proposal.category}</p>
                        {proposal.rejection_reason && (
                          <p className="text-xs text-red-400 mt-1">Sebep: {proposal.rejection_reason}</p>
                        )}
                      </div>
                      <Badge className="bg-red-500/20 text-red-400 border-0 text-xs">Reddedildi</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* All Tab */}
        <TabsContent value="all" className="space-y-3">
          {proposals.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-500">Henüz öneri yok</p>
            </div>
          ) : (
            <div className="space-y-2">
              {proposals.map((proposal) => (
                <Card key={proposal.id} className="bg-[#16213E] border-slate-700/50">
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${
                          proposal.status === 'pending' ? 'bg-amber-400' :
                          proposal.status === 'created' ? 'bg-emerald-400' :
                          proposal.status === 'rejected' ? 'bg-red-400' :
                          proposal.status === 'failed' ? 'bg-orange-400' : 'bg-slate-400'
                        }`} />
                        <div>
                          <span className="text-sm font-medium">{proposal.proposed_name}</span>
                          <span className="text-[10px] text-slate-500 ml-2">{proposal.niche_name}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-slate-600">
                          {proposal.created_at ? formatDateTime(proposal.created_at) : ''}
                        </span>
                        <Badge className={`text-[10px] border-0 ${STATUS_COLORS[proposal.status] || 'bg-slate-500/20 text-slate-400'}`}>
                          {proposal.status}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}


// Proposal Card Component for pending proposals
function ProposalCard({
  proposal,
  isEditing,
  editForm,
  setEditForm,
  approvingId,
  rejectingId,
  showRejectDialog,
  rejectReason,
  setRejectReason,
  onApprove,
  onReject,
  onEdit,
  onSaveEdit,
  onCancelEdit,
  onShowReject,
  onHideReject,
}: {
  proposal: Proposal;
  isEditing: boolean;
  editForm: Partial<Proposal>;
  setEditForm: (f: Partial<Proposal>) => void;
  approvingId: number | null;
  rejectingId: number | null;
  showRejectDialog: number | null;
  rejectReason: string;
  setRejectReason: (r: string) => void;
  onApprove: () => void;
  onReject: () => void;
  onEdit: () => void;
  onSaveEdit: () => void;
  onCancelEdit: () => void;
  onShowReject: () => void;
  onHideReject: () => void;
}) {
  const isApproving = approvingId === proposal.id;
  const isRejecting = rejectingId === proposal.id;
  const showReject = showRejectDialog === proposal.id;

  return (
    <Card className="bg-[#16213E] border-amber-500/20 hover:border-amber-500/40 transition-all">
      <CardContent className="p-5">
        {isEditing ? (
          /* Edit Mode */
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-slate-500 mb-1 block">Kanal Adı</label>
                <Input
                  value={editForm.proposed_name || ''}
                  onChange={(e) => setEditForm({ ...editForm, proposed_name: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-sm h-9"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 mb-1 block">Slug</label>
                <Input
                  value={editForm.proposed_slug || ''}
                  onChange={(e) => setEditForm({ ...editForm, proposed_slug: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-sm h-9"
                />
              </div>
            </div>
            <div>
              <label className="text-[10px] text-slate-500 mb-1 block">Açıklama</label>
              <Textarea
                value={editForm.proposed_description || ''}
                onChange={(e) => setEditForm({ ...editForm, proposed_description: e.target.value })}
                className="bg-slate-800 border-slate-600 text-sm min-h-[60px]"
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-[10px] text-slate-500 mb-1 block">Dil</label>
                <Input
                  value={editForm.proposed_language || ''}
                  onChange={(e) => setEditForm({ ...editForm, proposed_language: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-sm h-9"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 mb-1 block">İçerik Modu</label>
                <Input
                  value={editForm.content_mode || ''}
                  onChange={(e) => setEditForm({ ...editForm, content_mode: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-sm h-9"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 mb-1 block">Hedef Kitle</label>
                <Input
                  value={editForm.target_audience || ''}
                  onChange={(e) => setEditForm({ ...editForm, target_audience: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-sm h-9"
                />
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button size="sm" variant="outline" onClick={onCancelEdit} className="border-slate-600 text-slate-400">
                İptal
              </Button>
              <Button size="sm" onClick={onSaveEdit} className="bg-blue-600 hover:bg-blue-700 text-white">
                Kaydet
              </Button>
            </div>
          </div>
        ) : (
          /* View Mode */
          <div>
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500/20 to-[#E94560]/20 flex items-center justify-center">
                  <Tv2 className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <h3 className="font-bold text-base">{proposal.proposed_name}</h3>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                    <Tag className="w-3 h-3" />
                    <span>{proposal.niche_name}</span>
                    <span>·</span>
                    <span>{proposal.category}</span>
                  </div>
                </div>
              </div>
              <Badge className="bg-amber-500/20 text-amber-400 border-0 text-xs">
                <Clock className="w-3 h-3 mr-1" /> Onay Bekliyor
              </Badge>
            </div>

            {proposal.proposed_description && (
              <p className="text-sm text-slate-400 mb-3 leading-relaxed">
                {proposal.proposed_description}
              </p>
            )}

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Globe className="w-3.5 h-3.5 text-blue-400" />
                <span>{proposal.proposed_language || 'en'}</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Zap className="w-3.5 h-3.5 text-purple-400" />
                <span>{proposal.content_mode || 'faceless'}</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Users className="w-3.5 h-3.5 text-cyan-400" />
                <span className="truncate">{proposal.target_audience || 'Genel'}</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Bot className="w-3.5 h-3.5 text-emerald-400" />
                <span>{proposal.auto_content_enabled ? 'Oto İçerik Açık' : 'Manuel'}</span>
              </div>
            </div>

            {/* Reject dialog */}
            {showReject && (
              <div className="mb-4 p-3 rounded-lg bg-red-500/5 border border-red-500/20">
                <p className="text-xs text-red-400 mb-2">Reddetme sebebi (opsiyonel):</p>
                <Textarea
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  placeholder="Neden reddediyorsunuz?"
                  className="bg-slate-800 border-red-500/30 text-sm min-h-[50px] mb-2"
                />
                <div className="flex gap-2 justify-end">
                  <Button size="sm" variant="outline" onClick={onHideReject} className="border-slate-600 text-slate-400">
                    İptal
                  </Button>
                  <Button
                    size="sm"
                    onClick={onReject}
                    disabled={isRejecting}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    {isRejecting ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" /> : <XCircle className="w-3.5 h-3.5 mr-1" />}
                    Reddet
                  </Button>
                </div>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex items-center gap-2">
              <Button
                onClick={onApprove}
                disabled={isApproving}
                className="bg-emerald-600 hover:bg-emerald-700 text-white flex-1"
              >
                {isApproving ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-1" />
                ) : (
                  <ThumbsUp className="w-4 h-4 mr-1" />
                )}
                {isApproving ? 'Oluşturuluyor...' : 'Onayla & Oluştur'}
              </Button>
              <Button
                variant="outline"
                onClick={onEdit}
                className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
              >
                <Edit3 className="w-4 h-4" />
              </Button>
              {!showReject && (
                <Button
                  variant="outline"
                  onClick={onShowReject}
                  className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                >
                  <ThumbsDown className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}