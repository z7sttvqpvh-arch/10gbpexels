import { useState, useEffect } from 'react';
import { client, Channel } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import {
  Zap, Play, Loader2, CheckCircle2, XCircle, Search, Tv2,
  FileText, Upload, BarChart3, GitBranch, Sparkles, Bot, Rocket,
  Film, Image, Mic, Youtube, AlertTriangle, Settings, ArrowRight
} from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

interface StepResult {
  step: string;
  [key: string]: any;
}

interface AutomationResult {
  started_at: string;
  finished_at?: string;
  status: string;
  steps: StepResult[];
  errors: string[];
}

interface YouTubeStatus {
  api_key_configured: boolean;
  cookie_configured: boolean;
  ready: boolean;
  message: string;
}

const PIPELINE_STEPS = [
  { key: 'niche', label: 'Niş Keşfi', icon: Search, color: 'text-purple-400' },
  { key: 'approve', label: 'Otomatik Onay', icon: CheckCircle2, color: 'text-emerald-400' },
  { key: 'spawn', label: 'Kanal Oluştur', icon: Tv2, color: 'text-blue-400' },
  { key: 'content', label: 'İçerik Planla', icon: FileText, color: 'text-cyan-400' },
  { key: 'script', label: 'Script Yaz', icon: Mic, color: 'text-amber-400' },
  { key: 'render', label: 'Video Render', icon: Film, color: 'text-pink-400' },
  { key: 'thumbnail', label: 'Thumbnail', icon: Image, color: 'text-orange-400' },
  { key: 'upload', label: 'YouTube Yükle', icon: Youtube, color: 'text-red-400' },
];

export default function AutomationPage() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(true);
  const [runningFull, setRunningFull] = useState(false);
  const [runningPipeline, setRunningPipeline] = useState<number | null>(null);
  const [runningDiscover, setRunningDiscover] = useState(false);
  const [runningApprove, setRunningApprove] = useState(false);
  const [runningSpawn, setRunningSpawn] = useState(false);
  const [lastResult, setLastResult] = useState<AutomationResult | null>(null);
  const [pipelineResults, setPipelineResults] = useState<Record<number, any>>({});
  const [ytStatus, setYtStatus] = useState<YouTubeStatus | null>(null);
  const [currentStep, setCurrentStep] = useState(-1);
  const navigate = useNavigate();

  useEffect(() => {
    async function load() {
      try {
        const [chRes, ytRes] = await Promise.all([
          client.entities.channels.query({ sort: '-updated_at', limit: 50 }),
          client.apiCall.invoke({ url: '/api/v1/youtube/status', method: 'GET' }).catch(() => ({ data: null })),
        ]);
        setChannels(chRes.data?.items || []);
        if (ytRes.data) setYtStatus(ytRes.data);
      } catch (e) {
        console.error('Failed to load', e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const handleRunAll = async () => {
    setRunningFull(true);
    setLastResult(null);
    setCurrentStep(0);

    // Animate through steps
    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev >= PIPELINE_STEPS.length - 1) {
          clearInterval(stepInterval);
          return prev;
        }
        return prev + 1;
      });
    }, 3000);

    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/automation/run-all',
        method: 'POST',
        data: {},
        timeout: 300000,
      });
      clearInterval(stepInterval);
      setCurrentStep(PIPELINE_STEPS.length);
      setLastResult(res.data);
      toast.success('Tam otomasyon döngüsü tamamlandı!');
      // Refresh
      const chRes = await client.entities.channels.query({ sort: '-updated_at', limit: 50 });
      setChannels(chRes.data?.items || []);
      const ytRes = await client.apiCall.invoke({ url: '/api/v1/youtube/status', method: 'GET' }).catch(() => ({ data: null }));
      if (ytRes.data) setYtStatus(ytRes.data);
    } catch (e: any) {
      clearInterval(stepInterval);
      setCurrentStep(-1);
      toast.error(e?.data?.detail || 'Otomasyon başarısız');
    } finally {
      setRunningFull(false);
    }
  };

  const handleRunPipeline = async (channelId: number) => {
    setRunningPipeline(channelId);
    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/automation/pipeline',
        method: 'POST',
        data: { channel_id: channelId },
        timeout: 120000,
      });
      setPipelineResults((prev) => ({ ...prev, [channelId]: res.data }));
      toast.success('Pipeline tamamlandı');
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Pipeline başarısız');
    } finally {
      setRunningPipeline(null);
    }
  };

  const handleDiscover = async () => {
    setRunningDiscover(true);
    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/automation/discover',
        method: 'POST',
        data: {},
        timeout: 120000,
      });
      toast.success(`${res.data.total_discovered} yeni niş keşfedildi`);
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Keşif başarısız');
    } finally {
      setRunningDiscover(false);
    }
  };

  const handleAutoApprove = async () => {
    setRunningApprove(true);
    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/automation/auto-approve',
        method: 'POST',
        data: { min_score: 65.0 },
      });
      toast.success(`${res.data.approved} niş otomatik onaylandı`);
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Otomatik onay başarısız');
    } finally {
      setRunningApprove(false);
    }
  };

  const handleAutoSpawn = async () => {
    setRunningSpawn(true);
    try {
      const res = await client.apiCall.invoke({
        url: '/api/v1/automation/auto-spawn',
        method: 'POST',
        data: {},
      });
      const proposalsCreated = res.data?.proposals_created || 0;
      if (proposalsCreated > 0) {
        toast.success(`${proposalsCreated} kanal önerisi oluşturuldu. Onay sayfasına gidin.`);
      } else {
        toast.info(res.data?.message || 'Yeni öneri oluşturulmadı');
      }
      const chRes = await client.entities.channels.query({ sort: '-updated_at', limit: 50 });
      setChannels(chRes.data?.items || []);
    } catch (e: any) {
      toast.error(e?.data?.detail || 'Kanal oluşturma başarısız');
    } finally {
      setRunningSpawn(false);
    }
  };

  const activeChannels = channels.filter((c) => c.status === 'active' || c.status === 'incubating');
  const progress = runningFull ? Math.min(((currentStep + 1) / PIPELINE_STEPS.length) * 100, 100) : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E94560]" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Bot className="w-7 h-7 text-[#E94560]" />
          Otomasyon Merkezi
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Tam otomatik YouTube Shorts üretim hattı
        </p>
      </div>

      {/* YouTube Status Banner */}
      {ytStatus && (
        <Card className={`border ${ytStatus.ready ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-amber-500/5 border-amber-500/20'}`}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Youtube className={`w-6 h-6 ${ytStatus.ready ? 'text-emerald-400' : 'text-amber-400'}`} />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">YouTube Entegrasyon Durumu</span>
                    <Badge className={`text-[10px] border-0 ${ytStatus.ready ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
                      {ytStatus.ready ? 'Hazır' : 'Yapılandırma Gerekli'}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{ytStatus.message}</p>
                  <div className="flex gap-4 mt-1 text-[10px]">
                    <span className={ytStatus.api_key_configured ? 'text-emerald-400' : 'text-slate-500'}>
                      {ytStatus.api_key_configured ? '✓' : '○'} API Key
                    </span>
                    <span className={ytStatus.cookie_configured ? 'text-emerald-400' : 'text-slate-500'}>
                      {ytStatus.cookie_configured ? '✓' : '○'} Cookie
                    </span>
                  </div>
                </div>
              </div>
              {!ytStatus.ready && (
                <Button
                  size="sm"
                  variant="outline"
                  className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10"
                  onClick={() => navigate('/settings')}
                >
                  <Settings className="w-3.5 h-3.5 mr-1" /> Ayarlar
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Action - Run All */}
      <Card className="bg-gradient-to-r from-[#E94560]/10 to-[#533483]/10 border-[#E94560]/30">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#E94560] to-[#533483] flex items-center justify-center">
                <Rocket className="w-7 h-7 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold">Tam Otomasyon Çalıştır</h2>
                <p className="text-sm text-slate-400 mt-0.5">
                  Tüm adımları sırayla otomatik çalıştırır
                </p>
              </div>
            </div>
            <Button
              size="lg"
              onClick={handleRunAll}
              disabled={runningFull}
              className="bg-gradient-to-r from-[#E94560] to-[#533483] hover:opacity-90 text-white px-8 h-12"
            >
              {runningFull ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin mr-2" />
                  Çalışıyor...
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 mr-2" />
                  Başlat
                </>
              )}
            </Button>
          </div>

          {/* Pipeline Steps Visualization */}
          <div className="space-y-3">
            {runningFull && (
              <Progress value={progress} className="h-2 bg-slate-700" />
            )}
            <div className="flex items-center gap-1 overflow-x-auto pb-1">
              {PIPELINE_STEPS.map((step, i) => {
                const Icon = step.icon;
                const isActive = runningFull && currentStep === i;
                const isDone = currentStep > i;
                const isWaiting = currentStep < i;

                return (
                  <div key={step.key} className="flex items-center">
                    <div
                      className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        isActive
                          ? 'bg-[#E94560]/20 text-[#E94560] ring-1 ring-[#E94560]/50 animate-pulse'
                          : isDone
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : isWaiting
                          ? 'bg-slate-800/30 text-slate-500'
                          : 'bg-slate-800/30 text-slate-400'
                      }`}
                    >
                      {isDone ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      ) : isActive ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Icon className={`w-3.5 h-3.5 ${isWaiting ? 'text-slate-600' : step.color}`} />
                      )}
                      <span className="whitespace-nowrap">{step.label}</span>
                    </div>
                    {i < PIPELINE_STEPS.length - 1 && (
                      <ArrowRight className={`w-3 h-3 mx-0.5 shrink-0 ${isDone ? 'text-emerald-500' : 'text-slate-700'}`} />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Last Result */}
      {lastResult && (
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-[#E94560]" />
                Son Otomasyon Sonucu
              </CardTitle>
              <Badge className={`text-[10px] border-0 ${lastResult.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
                {lastResult.status === 'completed' ? 'Başarılı' : 'Kısmen Başarılı'}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {lastResult.steps.map((step, i) => (
              <div key={i} className="p-3 rounded-lg bg-slate-800/30">
                <div className="flex items-center gap-2 mb-1">
                  {step.step === 'niche_discovery' && <Search className="w-4 h-4 text-purple-400" />}
                  {step.step === 'auto_approve' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  {step.step === 'auto_spawn' && <Tv2 className="w-4 h-4 text-blue-400" />}
                  {step.step === 'pipeline' && <Zap className="w-4 h-4 text-amber-400" />}
                  <span className="text-sm font-medium capitalize">{step.step.replace(/_/g, ' ')}</span>
                </div>
                <div className="text-xs text-slate-400 space-y-0.5">
                  {step.total_discovered !== undefined && (
                    <p>Keşfedilen niş: <strong className="text-slate-300">{step.total_discovered}</strong></p>
                  )}
                  {step.approved !== undefined && (
                    <p>Onaylanan: <strong className="text-slate-300">{step.approved}</strong> {step.names?.length > 0 && `(${step.names.join(', ')})`}</p>
                  )}
                  {step.spawned !== undefined && (
                    <p>Oluşturulan kanal: <strong className="text-slate-300">{step.spawned}</strong> {step.names?.length > 0 && `(${step.names.join(', ')})`}</p>
                  )}
                  {step.channels_processed !== undefined && (
                    <p>İşlenen kanal: <strong className="text-slate-300">{step.channels_processed}</strong></p>
                  )}
                  {step.details && Array.isArray(step.details) && step.details.length > 0 && (
                    <div className="mt-1 space-y-1">
                      {step.details.slice(0, 5).map((d: any, j: number) => (
                        <p key={j} className="text-[10px] text-slate-500">
                          {d.category && `${d.category}: ${d.discovered ?? d.error}`}
                          {d.channel && `${d.channel}: ${d.steps?.join(' → ') || d.error || 'OK'}`}
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {lastResult.errors.length > 0 && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                <p className="text-xs font-medium text-red-400 mb-1 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Hatalar:
                </p>
                {lastResult.errors.map((e, i) => (
                  <p key={i} className="text-[10px] text-red-300 flex items-start gap-1">
                    <XCircle className="w-3 h-3 shrink-0 mt-0.5" /> {e}
                  </p>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="individual" className="space-y-4">
        <TabsList className="bg-[#16213E] border border-slate-700/50">
          <TabsTrigger value="individual" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">
            Bireysel Adımlar
          </TabsTrigger>
          <TabsTrigger value="channels" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">
            Kanal Pipeline ({activeChannels.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="individual" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {/* Niche Discovery */}
            <Card className="bg-[#16213E] border-slate-700/50 hover:border-purple-500/30 transition-all">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">Niş Keşfi</h3>
                    <p className="text-[10px] text-slate-500">AI ile yeni niş fırsatları keşfet</p>
                  </div>
                </div>
                <Button
                  onClick={handleDiscover}
                  disabled={runningDiscover}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                >
                  {runningDiscover ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Search className="w-4 h-4 mr-1" />}
                  {runningDiscover ? 'Keşfediliyor...' : 'Niş Keşfet'}
                </Button>
              </CardContent>
            </Card>

            {/* Auto Approve */}
            <Card className="bg-[#16213E] border-slate-700/50 hover:border-emerald-500/30 transition-all">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">Otomatik Onay</h3>
                    <p className="text-[10px] text-slate-500">Yüksek puanlı nişleri otomatik onayla (≥65)</p>
                  </div>
                </div>
                <Button
                  onClick={handleAutoApprove}
                  disabled={runningApprove}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  {runningApprove ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <CheckCircle2 className="w-4 h-4 mr-1" />}
                  {runningApprove ? 'Onaylanıyor...' : 'Otomatik Onayla'}
                </Button>
              </CardContent>
            </Card>

            {/* Auto Spawn → Proposals */}
            <Card className="bg-[#16213E] border-slate-700/50 hover:border-blue-500/30 transition-all">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
                    <Tv2 className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">Kanal Önerisi Oluştur</h3>
                    <p className="text-[10px] text-slate-500">Nişler için kanal önerisi oluştur (onayınız gerekli)</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={handleAutoSpawn}
                    disabled={runningSpawn}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {runningSpawn ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Tv2 className="w-4 h-4 mr-1" />}
                    {runningSpawn ? 'Oluşturuluyor...' : 'Öneri Oluştur'}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => navigate('/proposals')}
                    className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Video Render */}
            <Card className="bg-[#16213E] border-slate-700/50 hover:border-pink-500/30 transition-all">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-pink-500/20 flex items-center justify-center">
                    <Film className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">Video Render Pipeline</h3>
                    <p className="text-[10px] text-slate-500">AI sahne planı, stok görsel sorguları, metin katmanları</p>
                  </div>
                </div>
                <Badge variant="outline" className="border-slate-600 text-slate-400 text-xs">
                  Kanal Pipeline ile birlikte çalışır
                </Badge>
              </CardContent>
            </Card>

            {/* YouTube Upload */}
            <Card className="bg-[#16213E] border-slate-700/50 hover:border-red-500/30 transition-all">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
                    <Youtube className="w-5 h-5 text-red-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">YouTube Yükleme</h3>
                    <p className="text-[10px] text-slate-500">
                      {ytStatus?.ready ? 'YouTube API hazır — otomatik yükleme aktif' : 'API key gerekli — Settings\'den ekleyin'}
                    </p>
                  </div>
                </div>
                {ytStatus?.ready ? (
                  <Badge className="bg-emerald-500/20 text-emerald-400 border-0 text-xs">
                    <CheckCircle2 className="w-3 h-3 mr-1" /> Entegrasyon Aktif
                  </Badge>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full border-amber-500/30 text-amber-400 hover:bg-amber-500/10"
                    onClick={() => navigate('/settings')}
                  >
                    <Settings className="w-3.5 h-3.5 mr-1" /> API Key Ekle
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Evolution */}
            <Card className="bg-[#16213E] border-slate-700/50 hover:border-amber-500/30 transition-all">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center">
                    <GitBranch className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">Evrim Kontrolü</h3>
                    <p className="text-[10px] text-slate-500">Kanal aşama geçişleri ve otomatik terfi</p>
                  </div>
                </div>
                <Badge variant="outline" className="border-slate-600 text-slate-400 text-xs">
                  Tam Otomasyon ile birlikte çalışır
                </Badge>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="channels" className="space-y-4">
          {activeChannels.length === 0 ? (
            <div className="text-center py-12">
              <Tv2 className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-500">Aktif kanal yok</p>
              <p className="text-xs text-slate-600 mt-1">Önce Tam Otomasyon çalıştırarak kanal oluşturun</p>
            </div>
          ) : (
            <div className="space-y-3">
              {activeChannels.map((ch) => {
                const result = pipelineResults[ch.id];
                return (
                  <Card key={ch.id} className="bg-[#16213E] border-slate-700/50">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#E94560]/20 to-[#533483]/20 flex items-center justify-center">
                            <Tv2 className="w-4 h-4 text-[#E94560]" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-sm">{ch.name}</h3>
                            <div className="flex items-center gap-2 text-[10px] text-slate-500">
                              <span>{ch.stage}</span>
                              <span>·</span>
                              <span>{ch.total_videos} video</span>
                              <span>·</span>
                              <span>{ch.subscriber_count} abone</span>
                            </div>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => handleRunPipeline(ch.id)}
                          disabled={runningPipeline === ch.id}
                          className="bg-[#E94560] hover:bg-[#E94560]/80 text-white"
                        >
                          {runningPipeline === ch.id ? (
                            <Loader2 className="w-4 h-4 animate-spin mr-1" />
                          ) : (
                            <Play className="w-4 h-4 mr-1" />
                          )}
                          {runningPipeline === ch.id ? 'Çalışıyor...' : 'Pipeline Çalıştır'}
                        </Button>
                      </div>

                      {result && (
                        <div className="mt-3 p-3 rounded-lg bg-slate-800/30 space-y-1">
                          <Badge className={`text-[10px] border-0 mb-1 ${result.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
                            {result.status === 'completed' ? 'Tamamlandı' : 'Kısmen Tamamlandı'}
                          </Badge>
                          {result.steps_completed?.map((s: string, i: number) => (
                            <p key={i} className="text-xs text-slate-400 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" /> {s}
                            </p>
                          ))}
                          {result.errors?.map((e: string, i: number) => (
                            <p key={i} className="text-xs text-red-400 flex items-center gap-1">
                              <XCircle className="w-3 h-3 shrink-0" /> {e}
                            </p>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}