import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BookOpen, Zap, Eye, Clock, Target, TrendingUp, AlertTriangle,
  CheckCircle2, Lightbulb, BarChart3, Layers, Film, Mic, Hash,
  Sparkles, Shield, Users, Globe, ArrowRight, Play, RefreshCw,
  Timer, ThumbsUp, MessageSquare, Share2, Repeat, Brain, Flame
} from 'lucide-react';

interface StrategyRule {
  id: string;
  title: string;
  description: string;
  details: string[];
  source: string;
  priority: 'critical' | 'high' | 'medium';
  category: string;
}

const STRATEGY_RULES: StrategyRule[] = [
  {
    id: 'hook-3s',
    title: 'İlk 3 Saniye Kuralı (Hook)',
    description: 'İzleyicilerin %70\'i ilk 2-3 saniyede kaydırıyor. Hook başarısız olursa video asla FYP\'ye çıkmaz.',
    details: [
      'İlk 3 saniyede izleyiciyi durduracak görsel veya söz kullanın',
      'Soru sorma, şok edici bilgi veya merak uyandırıcı açılış yapın',
      'Hızlı ve canlı bir giriş yapın — yavaş başlangıç = kayıp izleyici',
      'Hook metni başlıkla ve açıklamayla tutarlı olmalı',
      'Videonun ilk karesinde bile dikkat çekici bir görsel olmalı',
    ],
    source: 'Rasendria AF, ksLFTEPinao',
    priority: 'critical',
    category: 'content',
  },
  {
    id: 'algo-waves',
    title: '3 Dağıtım Dalgası Sistemi',
    description: 'YouTube Shorts 3 aşamalı test sürecinden geçer. Her aşamayı geçmek için belirli metrikleri karşılamanız gerekir.',
    details: [
      'Dalga 1: Mikro test grubu (100-500 kişi) — İlk 3 saniye tutma oranı kritik',
      'Dalga 2: Genişletilmiş kitle (1K-10K) — Beğeni/yorum oranı değerlendirilir',
      'Dalga 3: Geniş dağıtım (10K+) — Paylaşım ve tekrar izleme oranı',
      'Her dalga başarısız olursa video daha fazla kişiye gösterilmez',
      '24-48 saat içinde test süreci tamamlanır',
    ],
    source: 'kOZ_NM7w7Ac, AVAGOBfbI_A',
    priority: 'critical',
    category: 'algorithm',
  },
  {
    id: 'metadata-sync',
    title: 'Metadata Senkronizasyonu',
    description: 'Başlık, açıklama, etiketler ve videonun ilk 3 saniyesi aynı anahtar kelimeyi içermelidir.',
    details: [
      'Başlıkta ana anahtar kelime olacak',
      'Açıklamada aynı kelime 2-3 kez geçecek',
      'Etiketlerde 5 farklı varyasyon olacak (ör: kırmızı elma, yeşil elma)',
      'Videonun ilk 3 saniyesinde anahtar kelimeyi söyleyin',
      'YouTube artık altyazı ve transkriptten de konu analizi yapıyor',
    ],
    source: 'HfV9ugfv5jQ',
    priority: 'critical',
    category: 'seo',
  },
  {
    id: 'algo-reset',
    title: 'Algoritma Reset Stratejisi',
    description: 'Görüntülemeler düştüğünde algoritmayı resetlemek için 48-72 saat upload duraklatma ve sinyal değişikliği yapın.',
    details: [
      '48-72 saat upload durdurun — kötü veri zincirini kırın',
      'Eski videoları silmeyin, hesap değiştirmeyin',
      'Duraklamadan sonra tamamen farklı hook tarzı ile başlayın',
      'İzleyici sinyallerini değiştirin: yeni format, yeni açılış stili',
      'Algoritma niyetinizi değil, izleyici davranışını okur',
    ],
    source: '5jNb7swY6uM',
    priority: 'high',
    category: 'algorithm',
  },
  {
    id: 'originality',
    title: 'Özgünlük Kuralı',
    description: 'YouTube yapay zekaya karşı değil, özgün olmayan içeriğe karşı. Kendi sesiniz ve yüzünüz özgünlük seviyesini artırır.',
    details: [
      'AI görsel ve hikaye kullanılabilir ama seslendirme kendiniz yapın',
      'Güçlü kurgu + ses efektleri + fon müziği = özgün kabul edilme',
      'Sadece AI TTS kullanan kanallar düşük RPM alır',
      'Kendi sesiniz + AI görseller = yüksek özgünlük skoru',
      'Özgün içerik hem izlenme hem gelir potansiyelini artırır',
    ],
    source: 'qYN_0EXXFVE',
    priority: 'high',
    category: 'content',
  },
  {
    id: 'thumbnail-shorts',
    title: 'Shorts İçin Kapak Fotoğrafı',
    description: 'Shorts artık sadece akışta değil, ana sayfa, arama ve Google\'da da görünüyor. Kapak fotoğrafı şart.',
    details: [
      'Her Shorts videosuna özel kapak fotoğrafı hazırlayın',
      'Büyük yazılar, oklar ve emojiler kullanın',
      'Merak uyandıracak şekilde tasarlayın',
      'Kapak fotoğrafı tıklama oranını (CTR) doğrudan etkiler',
      'Ana sayfa ve arama sonuçlarında görünürlük sağlar',
    ],
    source: 'HfV9ugfv5jQ',
    priority: 'high',
    category: 'visual',
  },
  {
    id: 'niche-consistency',
    title: 'Niş Tutarlılığı',
    description: 'Rastgele konu değiştirmek YouTube\'u şaşırtır. Tutarlı niş = tutarlı öneri.',
    details: [
      'Bugün eğitim, yarın eğlence, öbür gün başka konu = algoritma şaşırır',
      'YouTube kanalınızı kime önereceğini bilemez',
      'Aynı hedef kitleye hitap eden içerikler üretin',
      'Yeni kanal açıyorsanız 3-4 video ile aynı anda başlayın',
      'YouTube\'un test edebileceği daha fazla veri sağlayın',
    ],
    source: '5jNb7swY6uM, AVAGOBfbI_A',
    priority: 'high',
    category: 'strategy',
  },
  {
    id: 'video-duration',
    title: 'Video Süresi Optimizasyonu',
    description: 'Shorts maksimum 60 saniye olsa da, 30 saniyenin altında tutmak daha etkili.',
    details: [
      'Hızlı tüketilen videolar olduğu için 30 saniye ideal',
      'Kısa videolar daha yüksek tamamlanma oranı sağlar',
      'Tamamlanma oranı algoritma için en önemli metriklerden biri',
      'Gereksiz uzatma yapmayın — özlü ve etkili olun',
      'Tekrar izleme (rewatch) oranını artırmak için kısa tutun',
    ],
    source: 'PuVzUfXiSOU',
    priority: 'medium',
    category: 'content',
  },
  {
    id: 'viral-formats',
    title: 'Viral Format Tipleri',
    description: 'ASMR, satisfying content, kesme/dilimleme videoları milyonlarca izlenme alıyor.',
    details: [
      'ASMR tarzı videolar (cam arkası kesme, bıçakla dilimleme) çok popüler',
      'AI ile ASMR videoları oluşturulabilir (Sora, Kling, Gemini)',
      'Ses kalitesi ASMR için en kritik nokta',
      'Satisfying content: temizlik, düzenleme, dönüşüm videoları',
      'Trend formatları takip edin ama özgün dokunuş ekleyin',
    ],
    source: 'G5Sh-gnXqCQ',
    priority: 'medium',
    category: 'content',
  },
  {
    id: 'shorts-long-synergy',
    title: 'Shorts + Uzun Video Sinerjisi',
    description: 'Shorts kanalına uzun video veya uzun video kanalına Shorts eklemek izlenmeleri artırır.',
    details: [
      'Eğitim, finans, sağlık kanallarında Shorts izleyicisi uzun videoyu da izler',
      'Shorts\'tan gelen kitle uzun videoya yönlendirilebilir',
      'Shorts ile hızlı abone kazanabilirsiniz',
      'Eğlence kanallarında bu sinerji daha zayıf olabilir',
      'Düzenli içerik üretimi her iki formatta da önemli',
    ],
    source: 'FwxjVY6_ZY0',
    priority: 'medium',
    category: 'strategy',
  },
  {
    id: 'upload-quality',
    title: 'Kalite > Sıklık',
    description: '2026\'da YouTube upload sıklığını değil, izleyici tepkisini önceliklendiriyor.',
    details: [
      'Günde 5 video yerine 1 kaliteli video daha etkili',
      'Her video bir test — kaliteli test daha iyi sonuç verir',
      'Eski videoların kötü performansı yeni videoları etkiler',
      'Watch time düşük videolar kanalın genel skorunu düşürür',
      'Konsistans önemli ama kaliteden ödün vermeyin',
    ],
    source: '5jNb7swY6uM, swaKs3uM4NQ',
    priority: 'high',
    category: 'strategy',
  },
  {
    id: 'cta-engagement',
    title: 'CTA ve Etkileşim',
    description: 'Video sonunda kanalı ziyaret etmeye ve diğer videoları izlemeye yönlendirin.',
    details: [
      'Videonun sonunda net bir CTA (Call to Action) ekleyin',
      'Beğeni, yorum ve abone olmaya teşvik edin',
      'Diğer videolarınıza yönlendirme yapın',
      'Etkileşim oranı algoritma için önemli bir sinyal',
      'Yorum bırakanlara yanıt verin — topluluk oluşturun',
    ],
    source: 'PuVzUfXiSOU, AVAGOBfbI_A',
    priority: 'medium',
    category: 'engagement',
  },
];

const CATEGORIES = [
  { key: 'all', label: 'Tümü', icon: BookOpen },
  { key: 'content', label: 'İçerik', icon: Film },
  { key: 'algorithm', label: 'Algoritma', icon: Brain },
  { key: 'seo', label: 'SEO & Metadata', icon: Hash },
  { key: 'visual', label: 'Görsel', icon: Eye },
  { key: 'strategy', label: 'Strateji', icon: Target },
  { key: 'engagement', label: 'Etkileşim', icon: MessageSquare },
];

const PRIORITY_STYLES = {
  critical: { bg: 'bg-red-500/20', text: 'text-red-400', label: 'Kritik' },
  high: { bg: 'bg-amber-500/20', text: 'text-amber-400', label: 'Yüksek' },
  medium: { bg: 'bg-blue-500/20', text: 'text-blue-400', label: 'Orta' },
};

const CHECKLIST_ITEMS = [
  { label: 'İlk 3 saniye hook metni hazır mı?', icon: Zap },
  { label: 'Başlık anahtar kelime içeriyor mu?', icon: Hash },
  { label: 'Açıklamada anahtar kelime 2-3 kez geçiyor mu?', icon: BookOpen },
  { label: 'Etiketler anahtar kelime varyasyonları içeriyor mu?', icon: Target },
  { label: 'Kapak fotoğrafı hazırlandı mı?', icon: Eye },
  { label: 'Video 30 saniyenin altında mı?', icon: Timer },
  { label: 'Niş tutarlılığı korunuyor mu?', icon: Shield },
  { label: 'CTA (abone ol, beğen) eklendi mi?', icon: ThumbsUp },
  { label: 'Ses/seslendirme özgün mü?', icon: Mic },
  { label: 'Trend format kullanıldı mı?', icon: Flame },
];

export default function StrategyGuidePage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [checkedItems, setCheckedItems] = useState<Set<number>>(new Set());

  const filteredRules = selectedCategory === 'all'
    ? STRATEGY_RULES
    : STRATEGY_RULES.filter((r) => r.category === selectedCategory);

  const toggleCheck = (index: number) => {
    setCheckedItems((prev) => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  };

  const criticalCount = STRATEGY_RULES.filter((r) => r.priority === 'critical').length;
  const highCount = STRATEGY_RULES.filter((r) => r.priority === 'high').length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <BookOpen className="w-7 h-7 text-[#E94560]" />
          Strateji Rehberi
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          YouTube Shorts 2026 algoritma stratejileri — video analizlerinden derlenen kurallar
        </p>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E94560]/20 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-[#E94560]" />
            </div>
            <div>
              <p className="text-2xl font-bold">{STRATEGY_RULES.length}</p>
              <p className="text-xs text-slate-500">Toplam Kural</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{criticalCount}</p>
              <p className="text-xs text-slate-500">Kritik Kural</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{highCount}</p>
              <p className="text-xs text-slate-500">Yüksek Öncelik</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#16213E] border-slate-700/50">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold">{checkedItems.size}/{CHECKLIST_ITEMS.length}</p>
              <p className="text-xs text-slate-500">Kontrol Listesi</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="rules" className="space-y-4">
        <TabsList className="bg-[#16213E] border border-slate-700/50">
          <TabsTrigger value="rules" className="data-[state=active]:bg-[#E94560]/15 data-[state=active]:text-[#E94560]">
            <BookOpen className="w-4 h-4 mr-1.5" /> Strateji Kuralları
          </TabsTrigger>
          <TabsTrigger value="checklist" className="data-[state=active]:bg-emerald-500/15 data-[state=active]:text-emerald-400">
            <CheckCircle2 className="w-4 h-4 mr-1.5" /> Upload Kontrol Listesi
          </TabsTrigger>
          <TabsTrigger value="waves" className="data-[state=active]:bg-purple-500/15 data-[state=active]:text-purple-400">
            <Layers className="w-4 h-4 mr-1.5" /> Dağıtım Dalgaları
          </TabsTrigger>
        </TabsList>

        {/* Rules Tab */}
        <TabsContent value="rules" className="space-y-4">
          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => {
              const Icon = cat.icon;
              const isActive = selectedCategory === cat.key;
              const count = cat.key === 'all' ? STRATEGY_RULES.length : STRATEGY_RULES.filter((r) => r.category === cat.key).length;
              return (
                <button
                  key={cat.key}
                  onClick={() => setSelectedCategory(cat.key)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-[#E94560]/20 text-[#E94560] ring-1 ring-[#E94560]/30'
                      : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800 hover:text-slate-300'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {cat.label}
                  <span className={`ml-1 text-[10px] ${isActive ? 'text-[#E94560]/70' : 'text-slate-600'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Rules Grid */}
          <div className="space-y-4">
            {filteredRules.map((rule) => {
              const pStyle = PRIORITY_STYLES[rule.priority];
              return (
                <Card key={rule.id} className="bg-[#16213E] border-slate-700/50 hover:border-slate-600/50 transition-all">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-xl ${pStyle.bg} flex items-center justify-center shrink-0 mt-0.5`}>
                          {rule.priority === 'critical' ? (
                            <AlertTriangle className={`w-5 h-5 ${pStyle.text}`} />
                          ) : rule.priority === 'high' ? (
                            <TrendingUp className={`w-5 h-5 ${pStyle.text}`} />
                          ) : (
                            <Lightbulb className={`w-5 h-5 ${pStyle.text}`} />
                          )}
                        </div>
                        <div>
                          <h3 className="font-bold text-base">{rule.title}</h3>
                          <p className="text-sm text-slate-400 mt-1 leading-relaxed">{rule.description}</p>
                        </div>
                      </div>
                      <Badge className={`${pStyle.bg} ${pStyle.text} border-0 text-[10px] shrink-0 ml-2`}>
                        {pStyle.label}
                      </Badge>
                    </div>

                    <div className="ml-13 space-y-1.5 mt-3">
                      {rule.details.map((detail, i) => (
                        <div key={i} className="flex items-start gap-2 text-sm text-slate-300">
                          <ArrowRight className="w-3.5 h-3.5 text-slate-600 shrink-0 mt-0.5" />
                          <span>{detail}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 mt-3 pt-3 border-t border-slate-700/30">
                      <Badge variant="outline" className="border-slate-700 text-slate-500 text-[10px]">
                        {rule.category}
                      </Badge>
                      <span className="text-[10px] text-slate-600">Kaynak: {rule.source}</span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Checklist Tab */}
        <TabsContent value="checklist" className="space-y-4">
          <Card className="bg-[#16213E] border-slate-700/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Video Upload Öncesi Kontrol Listesi
                </CardTitle>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">
                    {checkedItems.size}/{CHECKLIST_ITEMS.length} tamamlandı
                  </span>
                  <button
                    onClick={() => setCheckedItems(new Set())}
                    className="text-[10px] text-slate-500 hover:text-slate-400 flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" /> Sıfırla
                  </button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {/* Progress */}
              <div className="h-2 bg-slate-700 rounded-full overflow-hidden mb-4">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-full transition-all duration-500"
                  style={{ width: `${(checkedItems.size / CHECKLIST_ITEMS.length) * 100}%` }}
                />
              </div>

              {CHECKLIST_ITEMS.map((item, i) => {
                const Icon = item.icon;
                const isChecked = checkedItems.has(i);
                return (
                  <button
                    key={i}
                    onClick={() => toggleCheck(i)}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all text-left ${
                      isChecked
                        ? 'bg-emerald-500/10 border border-emerald-500/20'
                        : 'bg-slate-800/30 border border-transparent hover:bg-slate-800/50'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-all ${
                      isChecked
                        ? 'bg-emerald-500 border-emerald-500'
                        : 'border-slate-600'
                    }`}>
                      {isChecked && <CheckCircle2 className="w-3 h-3 text-white" />}
                    </div>
                    <Icon className={`w-4 h-4 shrink-0 ${isChecked ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <span className={`text-sm ${isChecked ? 'text-emerald-300 line-through' : 'text-slate-300'}`}>
                      {item.label}
                    </span>
                  </button>
                );
              })}

              {checkedItems.size === CHECKLIST_ITEMS.length && (
                <div className="mt-4 p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-center">
                  <Sparkles className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                  <p className="text-sm font-medium text-emerald-400">Tüm kontroller tamamlandı!</p>
                  <p className="text-xs text-slate-500 mt-1">Videonuz upload için hazır 🚀</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Distribution Waves Tab */}
        <TabsContent value="waves" className="space-y-4">
          <div className="space-y-4">
            {/* Wave 1 */}
            <Card className="bg-[#16213E] border-blue-500/20">
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-500/20 flex items-center justify-center">
                    <span className="text-xl font-bold text-blue-400">1</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-base">Dalga 1: Mikro Test</h3>
                    <p className="text-xs text-slate-500">İlk 100-500 izleyici</p>
                  </div>
                  <Badge className="bg-blue-500/20 text-blue-400 border-0 text-xs ml-auto">İlk 1-2 Saat</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="p-3 rounded-lg bg-slate-800/30">
                    <div className="flex items-center gap-2 mb-1">
                      <Eye className="w-4 h-4 text-blue-400" />
                      <span className="text-xs font-medium">İlk 3s Tutma</span>
                    </div>
                    <p className="text-lg font-bold text-blue-400">≥ %30</p>
                    <p className="text-[10px] text-slate-500">İzleyicilerin en az %30'u 3 saniye kalmalı</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/30">
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="w-4 h-4 text-blue-400" />
                      <span className="text-xs font-medium">Ortalama İzleme</span>
                    </div>
                    <p className="text-lg font-bold text-blue-400">≥ %40</p>
                    <p className="text-[10px] text-slate-500">Videonun en az %40'ı izlenmeli</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/30">
                    <div className="flex items-center gap-2 mb-1">
                      <Play className="w-4 h-4 text-blue-400" />
                      <span className="text-xs font-medium">Kaydırma Oranı</span>
                    </div>
                    <p className="text-lg font-bold text-blue-400">≤ %70</p>
                    <p className="text-[10px] text-slate-500">3 saniyede kaydırma %70'in altında olmalı</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Arrow */}
            <div className="flex justify-center">
              <div className="flex flex-col items-center gap-1">
                <ArrowRight className="w-5 h-5 text-slate-600 rotate-90" />
                <span className="text-[10px] text-slate-600">Başarılı → Dalga 2'ye geç</span>
              </div>
            </div>

            {/* Wave 2 */}
            <Card className="bg-[#16213E] border-purple-500/20">
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-purple-500/20 flex items-center justify-center">
                    <span className="text-xl font-bold text-purple-400">2</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-base">Dalga 2: Genişletilmiş Test</h3>
                    <p className="text-xs text-slate-500">1.000 - 10.000 izleyici</p>
                  </div>
                  <Badge className="bg-purple-500/20 text-purple-400 border-0 text-xs ml-auto">2-12 Saat</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="p-3 rounded-lg bg-slate-800/30">
                    <div className="flex items-center gap-2 mb-1">
                      <ThumbsUp className="w-4 h-4 text-purple-400" />
                      <span className="text-xs font-medium">Beğeni Oranı</span>
                    </div>
                    <p className="text-lg font-bold text-purple-400">≥ %4</p>
                    <p className="text-[10px] text-slate-500">İzleyenlerin %4'ü beğenmeli</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/30">
                    <div className="flex items-center gap-2 mb-1">
                      <MessageSquare className="w-4 h-4 text-purple-400" />
                      <span className="text-xs font-medium">Yorum Oranı</span>
                    </div>
                    <p className="text-lg font-bold text-purple-400">≥ %0.5</p>
                    <p className="text-[10px] text-slate-500">İzleyenlerin %0.5'i yorum yapmalı</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/30">
                    <div className="flex items-center gap-2 mb-1">
                      <Repeat className="w-4 h-4 text-purple-400" />
                      <span className="text-xs font-medium">Tekrar İzleme</span>
                    </div>
                    <p className="text-lg font-bold text-purple-400">≥ %10</p>
                    <p className="text-[10px] text-slate-500">İzleyicilerin %10'u tekrar izlemeli</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Arrow */}
            <div className="flex justify-center">
              <div className="flex flex-col items-center gap-1">
                <ArrowRight className="w-5 h-5 text-slate-600 rotate-90" />
                <span className="text-[10px] text-slate-600">Başarılı → Dalga 3'e geç</span>
              </div>
            </div>

            {/* Wave 3 */}
            <Card className="bg-[#16213E] border-emerald-500/20">
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 flex items-center justify-center">
                    <span className="text-xl font-bold text-emerald-400">3</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-base">Dalga 3: Geniş Dağıtım</h3>
                    <p className="text-xs text-slate-500">10.000+ izleyici → Viral Loop</p>
                  </div>
                  <Badge className="bg-emerald-500/20 text-emerald-400 border-0 text-xs ml-auto">12-48 Saat</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="p-3 rounded-lg bg-slate-800/30">
                    <div className="flex items-center gap-2 mb-1">
                      <Share2 className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-medium">Paylaşım Oranı</span>
                    </div>
                    <p className="text-lg font-bold text-emerald-400">≥ %1</p>
                    <p className="text-[10px] text-slate-500">İzleyenlerin %1'i paylaşmalı</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/30">
                    <div className="flex items-center gap-2 mb-1">
                      <Users className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-medium">Abone Dönüşüm</span>
                    </div>
                    <p className="text-lg font-bold text-emerald-400">≥ %0.5</p>
                    <p className="text-[10px] text-slate-500">İzleyenlerin %0.5'i abone olmalı</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/30">
                    <div className="flex items-center gap-2 mb-1">
                      <Globe className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-medium">FYP Oranı</span>
                    </div>
                    <p className="text-lg font-bold text-emerald-400">≥ %60</p>
                    <p className="text-[10px] text-slate-500">Trafiğin %60'ı Shorts akışından gelmeli</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Viral Loop */}
            <Card className="bg-gradient-to-r from-[#E94560]/10 to-[#533483]/10 border-[#E94560]/30">
              <CardContent className="p-5 text-center">
                <Sparkles className="w-10 h-10 text-[#E94560] mx-auto mb-3" />
                <h3 className="font-bold text-lg">🔥 Viral Loop</h3>
                <p className="text-sm text-slate-400 mt-2 max-w-lg mx-auto">
                  3 dalgayı da geçen videolar viral döngüye girer. YouTube sürekli olarak yeni kitlelere gösterir.
                  Bu aşamada video binlerce, hatta milyonlarca izlenmeye ulaşabilir.
                </p>
                <div className="flex items-center justify-center gap-4 mt-4">
                  <Badge className="bg-[#E94560]/20 text-[#E94560] border-0">
                    <TrendingUp className="w-3 h-3 mr-1" /> Sürekli Büyüme
                  </Badge>
                  <Badge className="bg-[#533483]/20 text-purple-400 border-0">
                    <BarChart3 className="w-3 h-3 mr-1" /> Yüksek RPM
                  </Badge>
                  <Badge className="bg-emerald-500/20 text-emerald-400 border-0">
                    <Users className="w-3 h-3 mr-1" /> Abone Patlaması
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}