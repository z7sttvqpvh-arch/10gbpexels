# 🚀 YouTube Shorts Otomasyon — Sunucu Kurulum Rehberi

## Hızlı Kurulum (Tek Komut)

```bash
# 1. Proje dosyalarını sunucunuza yükleyin
# 2. Proje kök dizinine gidin
cd /path/to/project

# 3. Kurulum scriptini çalıştırın
sudo bash setup.sh
```

Script size birkaç soru soracak (domain, SSL) ve gerisini otomatik yapacak.

---

## Gereksinimler

| Gereksinim | Minimum | Önerilen |
|-----------|---------|----------|
| OS | Ubuntu 20.04 | Ubuntu 22.04 / 24.04 |
| RAM | 1 GB | 2 GB+ |
| Disk | 5 GB | 20 GB+ |
| CPU | 1 vCPU | 2 vCPU+ |

> **Not:** Node.js, PostgreSQL, Nginx ve diğer bağımlılıklar script tarafından otomatik kurulur.

---

## Script Ne Yapar?

| Adım | Açıklama |
|------|----------|
| 1 | Sistem paketlerini kurar (nginx, postgresql, python3, vb.) |
| 2 | Node.js v20 ve pnpm kurar |
| 3 | PostgreSQL veritabanı ve kullanıcı oluşturur |
| 4 | Uygulama dosyalarını `/opt/youtube-shorts-automation` dizinine kopyalar |
| 5 | Backend Python ortamını kurar, bağımlılıkları yükler, .env oluşturur |
| 6 | Frontend'i derler (pnpm build) |
| 7 | Nginx reverse proxy yapılandırır, opsiyonel SSL sertifikası alır |

---

## Kurulum Sonrası

### Erişim
- **Web Arayüzü:** `http://sunucu-ip` veya `https://domain.com`
- **API:** `http://sunucu-ip/api` veya `https://domain.com/api`

### Servis Yönetimi
```bash
# Durumu kontrol et
sudo supervisorctl status youtube-shorts-automation-api
sudo systemctl status nginx

# Yeniden başlat
sudo supervisorctl restart youtube-shorts-automation-api
sudo systemctl restart nginx

# Logları izle
sudo tail -f /var/log/youtube-shorts-automation-api.out.log
sudo tail -f /var/log/youtube-shorts-automation-api.err.log
```

### Yapılandırma Dosyaları
```
/opt/youtube-shorts-automation/
├── backend/
│   ├── .env                    # Backend yapılandırması (DB, API keys)
│   └── venv/                   # Python sanal ortam
├── frontend/
│   ├── .env                    # Frontend yapılandırması
│   └── dist/                   # Derlenmiş frontend dosyaları
└── INSTALL_INFO.txt            # Kurulum bilgileri (şifreler dahil)
```

### API Anahtarları Ekleme
1. Web arayüzünde **Settings** sayfasına gidin
2. **Add API Key** butonuna tıklayın
3. YouTube Data API v3 anahtarınızı ekleyin
4. Opsiyonel: Gemini, ElevenLabs, Pexels anahtarlarını ekleyin

---

## Güncelleme

```bash
# 1. Yeni dosyaları sunucuya yükleyin
# 2. Backend güncellemesi
cd /opt/youtube-shorts-automation/backend
source venv/bin/activate
pip install -r requirements.txt
alembic upgrade head
deactivate

# 3. Frontend güncellemesi
cd /opt/youtube-shorts-automation/frontend
pnpm install
pnpm run build

# 4. Servisleri yeniden başlat
sudo supervisorctl restart youtube-shorts-automation-api
sudo systemctl restart nginx
```

---

## Sorun Giderme

### Backend başlamıyor
```bash
# Logları kontrol edin
sudo tail -50 /var/log/youtube-shorts-automation-api.err.log

# .env dosyasını kontrol edin
sudo cat /opt/youtube-shorts-automation/backend/.env

# PostgreSQL bağlantısını test edin
sudo -u postgres psql -d youtube_shorts -c "SELECT 1;"
```

### Frontend görünmüyor
```bash
# Nginx yapılandırmasını test edin
sudo nginx -t

# dist dizinini kontrol edin
ls -la /opt/youtube-shorts-automation/frontend/dist/

# Nginx loglarını kontrol edin
sudo tail -20 /var/log/nginx/error.log
```

### Port çakışması
```bash
# Hangi servis portu kullanıyor?
sudo lsof -i :8002
sudo lsof -i :80

# Portu değiştirmek için .env ve nginx yapılandırmasını güncelleyin
```

---

## Kaldırma

```bash
# Servisleri durdur
sudo supervisorctl stop youtube-shorts-automation-api
sudo rm /etc/supervisor/conf.d/youtube-shorts-automation-api.conf
sudo supervisorctl reread && sudo supervisorctl update

# Nginx yapılandırmasını kaldır
sudo rm /etc/nginx/sites-enabled/youtube-shorts-automation
sudo rm /etc/nginx/sites-available/youtube-shorts-automation
sudo systemctl restart nginx

# Veritabanını kaldır
sudo -u postgres psql -c "DROP DATABASE youtube_shorts;"
sudo -u postgres psql -c "DROP USER ytshorts;"

# Dosyaları sil
sudo rm -rf /opt/youtube-shorts-automation
```