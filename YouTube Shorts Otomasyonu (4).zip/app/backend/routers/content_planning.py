"""Content Planning API endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.content_planning_service import generate_content_plan

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/content-planning", tags=["content-planning"])


class PlanRequest(BaseModel):
    channel_id: int
    count: int = 5


@router.post("/generate")
async def generate(data: PlanRequest, db: AsyncSession = Depends(get_db)):
    """Generate a content plan for a channel."""
    try:
        result = await generate_content_plan(db, data.channel_id, data.count)
        if "error" in result:
            raise HTTPException(status_code=500, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Content planning error: {e}")
        raise HTTPException(status_code=500, detail=str(e))