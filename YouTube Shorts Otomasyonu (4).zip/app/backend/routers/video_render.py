"""Video Render Pipeline API endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.video_render_service import (
    generate_render_plan,
    generate_thumbnail,
    generate_tts_script,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/video-render", tags=["video-render"])


class RenderRequest(BaseModel):
    video_id: int


@router.post("/render-plan")
async def create_render_plan(data: RenderRequest, db: AsyncSession = Depends(get_db)):
    """Generate a render plan for a video (scene descriptions, stock queries, overlays)."""
    try:
        result = await generate_render_plan(db, data.video_id)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Render plan error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/thumbnail")
async def create_thumbnail(data: RenderRequest, db: AsyncSession = Depends(get_db)):
    """Generate a thumbnail description for a video."""
    try:
        result = await generate_thumbnail(db, data.video_id)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Thumbnail error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/tts-script")
async def create_tts_script(data: RenderRequest, db: AsyncSession = Depends(get_db)):
    """Extract narration segments from render plan for TTS processing."""
    try:
        result = await generate_tts_script(db, data.video_id)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"TTS script error: {e}")
        raise HTTPException(status_code=500, detail=str(e))