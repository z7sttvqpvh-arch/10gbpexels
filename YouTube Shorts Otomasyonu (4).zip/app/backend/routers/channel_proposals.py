import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.channel_proposals import Channel_proposalsService
from services.channel_proposal_service import (
    generate_proposals,
    get_pending_proposals,
    get_all_proposals,
    approve_proposal,
    reject_proposal,
    update_proposal as custom_update_proposal,
)

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/channel_proposals", tags=["channel_proposals"])


# ---------- Pydantic Schemas ----------
class Channel_proposalsData(BaseModel):
    """Entity data schema (for create/update)"""
    niche_id: int
    niche_name: str
    proposed_name: str
    proposed_slug: str
    proposed_description: str = None
    proposed_language: str = None
    content_mode: str = None
    target_audience: str = None
    category: str = None
    status: str
    channel_id: int = None
    youtube_channel_id: str = None
    rejection_reason: str = None
    error_message: str = None
    auto_content_enabled: int = None


class Channel_proposalsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    niche_id: Optional[int] = None
    niche_name: Optional[str] = None
    proposed_name: Optional[str] = None
    proposed_slug: Optional[str] = None
    proposed_description: Optional[str] = None
    proposed_language: Optional[str] = None
    content_mode: Optional[str] = None
    target_audience: Optional[str] = None
    category: Optional[str] = None
    status: Optional[str] = None
    channel_id: Optional[int] = None
    youtube_channel_id: Optional[str] = None
    rejection_reason: Optional[str] = None
    error_message: Optional[str] = None
    auto_content_enabled: Optional[int] = None


class Channel_proposalsResponse(BaseModel):
    """Entity response schema"""
    id: int
    niche_id: int
    niche_name: str
    proposed_name: str
    proposed_slug: str
    proposed_description: Optional[str] = None
    proposed_language: Optional[str] = None
    content_mode: Optional[str] = None
    target_audience: Optional[str] = None
    category: Optional[str] = None
    status: str
    channel_id: Optional[int] = None
    youtube_channel_id: Optional[str] = None
    rejection_reason: Optional[str] = None
    error_message: Optional[str] = None
    auto_content_enabled: Optional[int] = None

    class Config:
        from_attributes = True


class Channel_proposalsListResponse(BaseModel):
    """List response schema"""
    items: List[Channel_proposalsResponse]
    total: int
    skip: int
    limit: int


class Channel_proposalsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Channel_proposalsData]


class Channel_proposalsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Channel_proposalsUpdateData


class Channel_proposalsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Channel_proposalsBatchUpdateItem]


class Channel_proposalsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Channel_proposalsListResponse)
async def query_channel_proposalss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query channel_proposalss with filtering, sorting, and pagination"""
    logger.debug(f"Querying channel_proposalss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Channel_proposalsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} channel_proposalss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying channel_proposalss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Channel_proposalsListResponse)
async def query_channel_proposalss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query channel_proposalss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying channel_proposalss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Channel_proposalsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} channel_proposalss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying channel_proposalss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Channel_proposalsResponse)
async def get_channel_proposals(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single channel_proposals by ID"""
    logger.debug(f"Fetching channel_proposals with id: {id}, fields={fields}")
    
    service = Channel_proposalsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Channel_proposals with id {id} not found")
            raise HTTPException(status_code=404, detail="Channel_proposals not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching channel_proposals {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Channel_proposalsResponse, status_code=201)
async def create_channel_proposals(
    data: Channel_proposalsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new channel_proposals"""
    logger.debug(f"Creating new channel_proposals with data: {data}")
    
    service = Channel_proposalsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create channel_proposals")
        
        logger.info(f"Channel_proposals created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating channel_proposals: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating channel_proposals: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Channel_proposalsResponse], status_code=201)
async def create_channel_proposalss_batch(
    request: Channel_proposalsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple channel_proposalss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} channel_proposalss")
    
    service = Channel_proposalsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} channel_proposalss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Channel_proposalsResponse])
async def update_channel_proposalss_batch(
    request: Channel_proposalsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple channel_proposalss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} channel_proposalss")
    
    service = Channel_proposalsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} channel_proposalss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Channel_proposalsResponse)
async def update_channel_proposals(
    id: int,
    data: Channel_proposalsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing channel_proposals"""
    logger.debug(f"Updating channel_proposals {id} with data: {data}")

    service = Channel_proposalsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Channel_proposals with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Channel_proposals not found")
        
        logger.info(f"Channel_proposals {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating channel_proposals {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating channel_proposals {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_channel_proposalss_batch(
    request: Channel_proposalsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple channel_proposalss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} channel_proposalss")
    
    service = Channel_proposalsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} channel_proposalss successfully")
        return {"message": f"Successfully deleted {deleted_count} channel_proposalss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_channel_proposals(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single channel_proposals by ID"""
    logger.debug(f"Deleting channel_proposals with id: {id}")
    
    service = Channel_proposalsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Channel_proposals with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Channel_proposals not found")
        
        logger.info(f"Channel_proposals {id} deleted successfully")
        return {"message": "Channel_proposals deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting channel_proposals {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


# ---------- Custom Approval/Rejection Endpoints ----------

class ApproveProposalRequest(BaseModel):
    auto_content: bool = True


class RejectProposalRequest(BaseModel):
    reason: str = ""


@router.post("/actions/generate")
async def generate_new_proposals(db: AsyncSession = Depends(get_db)):
    """Generate new channel proposals for approved niches without channels."""
    try:
        result = await generate_proposals(db)
        return result
    except Exception as e:
        logger.error(f"Error generating proposals: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/actions/{proposal_id}/approve")
async def approve_channel_proposal(
    proposal_id: int,
    body: ApproveProposalRequest = ApproveProposalRequest(),
    db: AsyncSession = Depends(get_db),
):
    """Approve a channel proposal. Creates channel in DB and attempts YouTube channel creation via cookie."""
    try:
        result = await approve_proposal(db, proposal_id, body.auto_content)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error approving proposal {proposal_id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/actions/{proposal_id}/reject")
async def reject_channel_proposal(
    proposal_id: int,
    body: RejectProposalRequest = RejectProposalRequest(),
    db: AsyncSession = Depends(get_db),
):
    """Reject a channel proposal."""
    try:
        result = await reject_proposal(db, proposal_id, body.reason)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error rejecting proposal {proposal_id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))