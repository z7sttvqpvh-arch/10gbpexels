"""Generation Pipeline API endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.generation_pipeline_service import generate_script, generate_hooks

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/generation", tags=["generation"])


class ScriptRequest(BaseModel):
    video_id: int


class HooksRequest(BaseModel):
    video_id: int
    count: int = 3


@router.post("/script")
async def gen_script(data: ScriptRequest, db: AsyncSession = Depends(get_db)):
    """Generate a full script for a video."""
    try:
        result = await generate_script(db, data.video_id)
        if "error" in result:
            raise HTTPException(status_code=500, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Script generation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/hooks")
async def gen_hooks(data: HooksRequest, db: AsyncSession = Depends(get_db)):
    """Generate alternative hooks for a video."""
    try:
        result = await generate_hooks(db, data.video_id, data.count)
        if "error" in result:
            raise HTTPException(status_code=500, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Hook generation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))