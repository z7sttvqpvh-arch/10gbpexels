"""Niche Discovery API endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.niche_service import discover_niches, approve_candidate

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/niche-discovery", tags=["niche-discovery"])


class DiscoverRequest(BaseModel):
    category: str
    count: int = 5


class ApproveRequest(BaseModel):
    candidate_id: int


@router.post("/discover")
async def discover(data: DiscoverRequest, db: AsyncSession = Depends(get_db)):
    """Discover new niche candidates using AI."""
    try:
        result = await discover_niches(db, data.category, data.count)
        if "error" in result:
            raise HTTPException(status_code=500, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Niche discovery error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/approve")
async def approve(data: ApproveRequest, db: AsyncSession = Depends(get_db)):
    """Approve a niche candidate."""
    try:
        result = await approve_candidate(db, data.candidate_id)
        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Niche approve error: {e}")
        raise HTTPException(status_code=500, detail=str(e))