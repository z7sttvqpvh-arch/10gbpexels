"""Automation Engine API endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional

from core.database import get_db
from services.automation_service import (
    run_full_pipeline,
    run_auto_discovery,
    run_auto_approve,
    run_auto_spawn,
    run_full_automation,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/automation", tags=["automation"])


class PipelineRequest(BaseModel):
    channel_id: int


class DiscoveryRequest(BaseModel):
    categories: Optional[list[str]] = None


class ApproveRequest(BaseModel):
    min_score: float = 65.0


class FullAutomationRequest(BaseModel):
    pass


@router.post("/pipeline")
async def pipeline(data: PipelineRequest, db: AsyncSession = Depends(get_db)):
    """Run the full content pipeline for a specific channel."""
    try:
        result = await run_full_pipeline(db, data.channel_id)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Pipeline error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/discover")
async def discover(data: DiscoveryRequest, db: AsyncSession = Depends(get_db)):
    """Run automatic niche discovery."""
    try:
        result = await run_auto_discovery(db, data.categories)
        return result
    except Exception as e:
        logger.error(f"Auto discovery error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/auto-approve")
async def auto_approve(data: ApproveRequest, db: AsyncSession = Depends(get_db)):
    """Auto-approve high-scoring niche candidates."""
    try:
        result = await run_auto_approve(db, data.min_score)
        return result
    except Exception as e:
        logger.error(f"Auto approve error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/auto-spawn")
async def auto_spawn(db: AsyncSession = Depends(get_db)):
    """Auto-spawn channels for approved niches without channels."""
    try:
        result = await run_auto_spawn(db)
        return result
    except Exception as e:
        logger.error(f"Auto spawn error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/run-all")
async def run_all(db: AsyncSession = Depends(get_db)):
    """Run the complete automation cycle (discover → approve → spawn → pipeline)."""
    try:
        result = await run_full_automation(db)
        return result
    except Exception as e:
        logger.error(f"Full automation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))