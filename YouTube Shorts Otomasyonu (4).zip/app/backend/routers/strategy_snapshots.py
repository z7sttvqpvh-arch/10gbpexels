import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.strategy_snapshots import Strategy_snapshotsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/strategy_snapshots", tags=["strategy_snapshots"])


# ---------- Pydantic Schemas ----------
class Strategy_snapshotsData(BaseModel):
    """Entity data schema (for create/update)"""
    channel_id: int
    stage: str
    content_pillars: str = None
    content_mix: str = None
    hook_families: str = None
    title_families: str = None
    thumbnail_families: str = None
    upload_tempo_hours: int = None
    content_mode: str = None
    target_audience: str = None
    authority_score_at: float = None
    topic_drift_at: float = None
    is_current: bool = None
    created_at: Optional[datetime] = None


class Strategy_snapshotsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    channel_id: Optional[int] = None
    stage: Optional[str] = None
    content_pillars: Optional[str] = None
    content_mix: Optional[str] = None
    hook_families: Optional[str] = None
    title_families: Optional[str] = None
    thumbnail_families: Optional[str] = None
    upload_tempo_hours: Optional[int] = None
    content_mode: Optional[str] = None
    target_audience: Optional[str] = None
    authority_score_at: Optional[float] = None
    topic_drift_at: Optional[float] = None
    is_current: Optional[bool] = None
    created_at: Optional[datetime] = None


class Strategy_snapshotsResponse(BaseModel):
    """Entity response schema"""
    id: int
    channel_id: int
    stage: str
    content_pillars: Optional[str] = None
    content_mix: Optional[str] = None
    hook_families: Optional[str] = None
    title_families: Optional[str] = None
    thumbnail_families: Optional[str] = None
    upload_tempo_hours: Optional[int] = None
    content_mode: Optional[str] = None
    target_audience: Optional[str] = None
    authority_score_at: Optional[float] = None
    topic_drift_at: Optional[float] = None
    is_current: Optional[bool] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Strategy_snapshotsListResponse(BaseModel):
    """List response schema"""
    items: List[Strategy_snapshotsResponse]
    total: int
    skip: int
    limit: int


class Strategy_snapshotsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Strategy_snapshotsData]


class Strategy_snapshotsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Strategy_snapshotsUpdateData


class Strategy_snapshotsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Strategy_snapshotsBatchUpdateItem]


class Strategy_snapshotsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Strategy_snapshotsListResponse)
async def query_strategy_snapshotss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query strategy_snapshotss with filtering, sorting, and pagination"""
    logger.debug(f"Querying strategy_snapshotss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Strategy_snapshotsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} strategy_snapshotss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying strategy_snapshotss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Strategy_snapshotsListResponse)
async def query_strategy_snapshotss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query strategy_snapshotss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying strategy_snapshotss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Strategy_snapshotsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} strategy_snapshotss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying strategy_snapshotss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Strategy_snapshotsResponse)
async def get_strategy_snapshots(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single strategy_snapshots by ID"""
    logger.debug(f"Fetching strategy_snapshots with id: {id}, fields={fields}")
    
    service = Strategy_snapshotsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Strategy_snapshots with id {id} not found")
            raise HTTPException(status_code=404, detail="Strategy_snapshots not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching strategy_snapshots {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Strategy_snapshotsResponse, status_code=201)
async def create_strategy_snapshots(
    data: Strategy_snapshotsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new strategy_snapshots"""
    logger.debug(f"Creating new strategy_snapshots with data: {data}")
    
    service = Strategy_snapshotsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create strategy_snapshots")
        
        logger.info(f"Strategy_snapshots created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating strategy_snapshots: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating strategy_snapshots: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Strategy_snapshotsResponse], status_code=201)
async def create_strategy_snapshotss_batch(
    request: Strategy_snapshotsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple strategy_snapshotss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} strategy_snapshotss")
    
    service = Strategy_snapshotsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} strategy_snapshotss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Strategy_snapshotsResponse])
async def update_strategy_snapshotss_batch(
    request: Strategy_snapshotsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple strategy_snapshotss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} strategy_snapshotss")
    
    service = Strategy_snapshotsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} strategy_snapshotss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Strategy_snapshotsResponse)
async def update_strategy_snapshots(
    id: int,
    data: Strategy_snapshotsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing strategy_snapshots"""
    logger.debug(f"Updating strategy_snapshots {id} with data: {data}")

    service = Strategy_snapshotsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Strategy_snapshots with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Strategy_snapshots not found")
        
        logger.info(f"Strategy_snapshots {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating strategy_snapshots {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating strategy_snapshots {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_strategy_snapshotss_batch(
    request: Strategy_snapshotsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple strategy_snapshotss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} strategy_snapshotss")
    
    service = Strategy_snapshotsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} strategy_snapshotss successfully")
        return {"message": f"Successfully deleted {deleted_count} strategy_snapshotss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_strategy_snapshots(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single strategy_snapshots by ID"""
    logger.debug(f"Deleting strategy_snapshots with id: {id}")
    
    service = Strategy_snapshotsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Strategy_snapshots with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Strategy_snapshots not found")
        
        logger.info(f"Strategy_snapshots {id} deleted successfully")
        return {"message": "Strategy_snapshots deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting strategy_snapshots {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")