import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.niches import NichesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/niches", tags=["niches"])


# ---------- Pydantic Schemas ----------
class NichesData(BaseModel):
    """Entity data schema (for create/update)"""
    name: str
    slug: str
    category: str
    sub_category: str = None
    description: str = None
    saturation_level: str = None
    visual_suitability: float = None
    repeatability_score: float = None
    global_transfer_score: float = None
    monetization_potential: float = None
    status: str = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class NichesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    name: Optional[str] = None
    slug: Optional[str] = None
    category: Optional[str] = None
    sub_category: Optional[str] = None
    description: Optional[str] = None
    saturation_level: Optional[str] = None
    visual_suitability: Optional[float] = None
    repeatability_score: Optional[float] = None
    global_transfer_score: Optional[float] = None
    monetization_potential: Optional[float] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class NichesResponse(BaseModel):
    """Entity response schema"""
    id: int
    name: str
    slug: str
    category: str
    sub_category: Optional[str] = None
    description: Optional[str] = None
    saturation_level: Optional[str] = None
    visual_suitability: Optional[float] = None
    repeatability_score: Optional[float] = None
    global_transfer_score: Optional[float] = None
    monetization_potential: Optional[float] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class NichesListResponse(BaseModel):
    """List response schema"""
    items: List[NichesResponse]
    total: int
    skip: int
    limit: int


class NichesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[NichesData]


class NichesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: NichesUpdateData


class NichesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[NichesBatchUpdateItem]


class NichesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=NichesListResponse)
async def query_nichess(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query nichess with filtering, sorting, and pagination"""
    logger.debug(f"Querying nichess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = NichesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} nichess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying nichess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=NichesListResponse)
async def query_nichess_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query nichess with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying nichess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = NichesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} nichess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying nichess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=NichesResponse)
async def get_niches(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single niches by ID"""
    logger.debug(f"Fetching niches with id: {id}, fields={fields}")
    
    service = NichesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Niches with id {id} not found")
            raise HTTPException(status_code=404, detail="Niches not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching niches {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=NichesResponse, status_code=201)
async def create_niches(
    data: NichesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new niches"""
    logger.debug(f"Creating new niches with data: {data}")
    
    service = NichesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create niches")
        
        logger.info(f"Niches created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating niches: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating niches: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[NichesResponse], status_code=201)
async def create_nichess_batch(
    request: NichesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple nichess in a single request"""
    logger.debug(f"Batch creating {len(request.items)} nichess")
    
    service = NichesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} nichess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[NichesResponse])
async def update_nichess_batch(
    request: NichesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple nichess in a single request"""
    logger.debug(f"Batch updating {len(request.items)} nichess")
    
    service = NichesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} nichess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=NichesResponse)
async def update_niches(
    id: int,
    data: NichesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing niches"""
    logger.debug(f"Updating niches {id} with data: {data}")

    service = NichesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Niches with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Niches not found")
        
        logger.info(f"Niches {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating niches {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating niches {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_nichess_batch(
    request: NichesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple nichess by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} nichess")
    
    service = NichesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} nichess successfully")
        return {"message": f"Successfully deleted {deleted_count} nichess", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_niches(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single niches by ID"""
    logger.debug(f"Deleting niches with id: {id}")
    
    service = NichesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Niches with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Niches not found")
        
        logger.info(f"Niches {id} deleted successfully")
        return {"message": "Niches deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting niches {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")