import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.channel_brand_profiles import Channel_brand_profilesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/channel_brand_profiles", tags=["channel_brand_profiles"])


# ---------- Pydantic Schemas ----------
class Channel_brand_profilesData(BaseModel):
    """Entity data schema (for create/update)"""
    channel_id: int
    channel_name_display: str
    short_description: str = None
    slogan: str = None
    tone: str
    thumbnail_style: str = None
    logo_prompt: str = None
    banner_prompt: str = None
    color_primary: str = None
    color_secondary: str = None
    identity_version: int = None
    is_active: bool = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Channel_brand_profilesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    channel_id: Optional[int] = None
    channel_name_display: Optional[str] = None
    short_description: Optional[str] = None
    slogan: Optional[str] = None
    tone: Optional[str] = None
    thumbnail_style: Optional[str] = None
    logo_prompt: Optional[str] = None
    banner_prompt: Optional[str] = None
    color_primary: Optional[str] = None
    color_secondary: Optional[str] = None
    identity_version: Optional[int] = None
    is_active: Optional[bool] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Channel_brand_profilesResponse(BaseModel):
    """Entity response schema"""
    id: int
    channel_id: int
    channel_name_display: str
    short_description: Optional[str] = None
    slogan: Optional[str] = None
    tone: str
    thumbnail_style: Optional[str] = None
    logo_prompt: Optional[str] = None
    banner_prompt: Optional[str] = None
    color_primary: Optional[str] = None
    color_secondary: Optional[str] = None
    identity_version: Optional[int] = None
    is_active: Optional[bool] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Channel_brand_profilesListResponse(BaseModel):
    """List response schema"""
    items: List[Channel_brand_profilesResponse]
    total: int
    skip: int
    limit: int


class Channel_brand_profilesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Channel_brand_profilesData]


class Channel_brand_profilesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Channel_brand_profilesUpdateData


class Channel_brand_profilesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Channel_brand_profilesBatchUpdateItem]


class Channel_brand_profilesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Channel_brand_profilesListResponse)
async def query_channel_brand_profiless(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query channel_brand_profiless with filtering, sorting, and pagination"""
    logger.debug(f"Querying channel_brand_profiless: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Channel_brand_profilesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} channel_brand_profiless")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying channel_brand_profiless: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Channel_brand_profilesListResponse)
async def query_channel_brand_profiless_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query channel_brand_profiless with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying channel_brand_profiless: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Channel_brand_profilesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} channel_brand_profiless")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying channel_brand_profiless: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Channel_brand_profilesResponse)
async def get_channel_brand_profiles(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single channel_brand_profiles by ID"""
    logger.debug(f"Fetching channel_brand_profiles with id: {id}, fields={fields}")
    
    service = Channel_brand_profilesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Channel_brand_profiles with id {id} not found")
            raise HTTPException(status_code=404, detail="Channel_brand_profiles not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching channel_brand_profiles {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Channel_brand_profilesResponse, status_code=201)
async def create_channel_brand_profiles(
    data: Channel_brand_profilesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new channel_brand_profiles"""
    logger.debug(f"Creating new channel_brand_profiles with data: {data}")
    
    service = Channel_brand_profilesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create channel_brand_profiles")
        
        logger.info(f"Channel_brand_profiles created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating channel_brand_profiles: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating channel_brand_profiles: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Channel_brand_profilesResponse], status_code=201)
async def create_channel_brand_profiless_batch(
    request: Channel_brand_profilesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple channel_brand_profiless in a single request"""
    logger.debug(f"Batch creating {len(request.items)} channel_brand_profiless")
    
    service = Channel_brand_profilesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} channel_brand_profiless successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Channel_brand_profilesResponse])
async def update_channel_brand_profiless_batch(
    request: Channel_brand_profilesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple channel_brand_profiless in a single request"""
    logger.debug(f"Batch updating {len(request.items)} channel_brand_profiless")
    
    service = Channel_brand_profilesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} channel_brand_profiless successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Channel_brand_profilesResponse)
async def update_channel_brand_profiles(
    id: int,
    data: Channel_brand_profilesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing channel_brand_profiles"""
    logger.debug(f"Updating channel_brand_profiles {id} with data: {data}")

    service = Channel_brand_profilesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Channel_brand_profiles with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Channel_brand_profiles not found")
        
        logger.info(f"Channel_brand_profiles {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating channel_brand_profiles {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating channel_brand_profiles {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_channel_brand_profiless_batch(
    request: Channel_brand_profilesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple channel_brand_profiless by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} channel_brand_profiless")
    
    service = Channel_brand_profilesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} channel_brand_profiless successfully")
        return {"message": f"Successfully deleted {deleted_count} channel_brand_profiless", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_channel_brand_profiles(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single channel_brand_profiles by ID"""
    logger.debug(f"Deleting channel_brand_profiles with id: {id}")
    
    service = Channel_brand_profilesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Channel_brand_profiles with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Channel_brand_profiles not found")
        
        logger.info(f"Channel_brand_profiles {id} deleted successfully")
        return {"message": "Channel_brand_profiles deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting channel_brand_profiles {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")