"""Evolution Engine API endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.evolution_service import review_channel, execute_transition

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/evolution", tags=["evolution"])


class ReviewRequest(BaseModel):
    channel_id: int


class ExecuteRequest(BaseModel):
    channel_id: int
    decision: str  # promote, stay, rollback
    reason: str
    triggered_by: str = "manual"


@router.post("/review")
async def review(data: ReviewRequest, db: AsyncSession = Depends(get_db)):
    """Review a channel's stage readiness."""
    try:
        result = await review_channel(db, data.channel_id)
        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Evolution review error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/execute")
async def execute(data: ExecuteRequest, db: AsyncSession = Depends(get_db)):
    """Execute a stage transition."""
    try:
        if data.decision not in ("promote", "stay", "rollback"):
            raise HTTPException(status_code=400, detail="Decision must be promote, stay, or rollback")
        result = await execute_transition(db, data.channel_id, data.decision, data.reason, data.triggered_by)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Evolution execute error: {e}")
        raise HTTPException(status_code=500, detail=str(e))