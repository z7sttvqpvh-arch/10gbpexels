import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.audience_segments import Audience_segmentsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/audience_segments", tags=["audience_segments"])


# ---------- Pydantic Schemas ----------
class Audience_segmentsData(BaseModel):
    """Entity data schema (for create/update)"""
    channel_id: int
    segment_name: str
    percentage: float = None
    age_range: str = None
    primary_region: str = None
    interest_tags: str = None
    engagement_level: str = None
    retention_rate: float = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Audience_segmentsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    channel_id: Optional[int] = None
    segment_name: Optional[str] = None
    percentage: Optional[float] = None
    age_range: Optional[str] = None
    primary_region: Optional[str] = None
    interest_tags: Optional[str] = None
    engagement_level: Optional[str] = None
    retention_rate: Optional[float] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Audience_segmentsResponse(BaseModel):
    """Entity response schema"""
    id: int
    channel_id: int
    segment_name: str
    percentage: Optional[float] = None
    age_range: Optional[str] = None
    primary_region: Optional[str] = None
    interest_tags: Optional[str] = None
    engagement_level: Optional[str] = None
    retention_rate: Optional[float] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Audience_segmentsListResponse(BaseModel):
    """List response schema"""
    items: List[Audience_segmentsResponse]
    total: int
    skip: int
    limit: int


class Audience_segmentsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Audience_segmentsData]


class Audience_segmentsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Audience_segmentsUpdateData


class Audience_segmentsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Audience_segmentsBatchUpdateItem]


class Audience_segmentsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Audience_segmentsListResponse)
async def query_audience_segmentss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query audience_segmentss with filtering, sorting, and pagination"""
    logger.debug(f"Querying audience_segmentss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Audience_segmentsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} audience_segmentss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying audience_segmentss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Audience_segmentsListResponse)
async def query_audience_segmentss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query audience_segmentss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying audience_segmentss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Audience_segmentsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} audience_segmentss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying audience_segmentss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Audience_segmentsResponse)
async def get_audience_segments(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single audience_segments by ID"""
    logger.debug(f"Fetching audience_segments with id: {id}, fields={fields}")
    
    service = Audience_segmentsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Audience_segments with id {id} not found")
            raise HTTPException(status_code=404, detail="Audience_segments not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching audience_segments {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Audience_segmentsResponse, status_code=201)
async def create_audience_segments(
    data: Audience_segmentsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new audience_segments"""
    logger.debug(f"Creating new audience_segments with data: {data}")
    
    service = Audience_segmentsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create audience_segments")
        
        logger.info(f"Audience_segments created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating audience_segments: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating audience_segments: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Audience_segmentsResponse], status_code=201)
async def create_audience_segmentss_batch(
    request: Audience_segmentsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple audience_segmentss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} audience_segmentss")
    
    service = Audience_segmentsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} audience_segmentss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Audience_segmentsResponse])
async def update_audience_segmentss_batch(
    request: Audience_segmentsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple audience_segmentss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} audience_segmentss")
    
    service = Audience_segmentsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} audience_segmentss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Audience_segmentsResponse)
async def update_audience_segments(
    id: int,
    data: Audience_segmentsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing audience_segments"""
    logger.debug(f"Updating audience_segments {id} with data: {data}")

    service = Audience_segmentsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Audience_segments with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Audience_segments not found")
        
        logger.info(f"Audience_segments {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating audience_segments {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating audience_segments {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_audience_segmentss_batch(
    request: Audience_segmentsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple audience_segmentss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} audience_segmentss")
    
    service = Audience_segmentsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} audience_segmentss successfully")
        return {"message": f"Successfully deleted {deleted_count} audience_segmentss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_audience_segments(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single audience_segments by ID"""
    logger.debug(f"Deleting audience_segments with id: {id}")
    
    service = Audience_segmentsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Audience_segments with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Audience_segments not found")
        
        logger.info(f"Audience_segments {id} deleted successfully")
        return {"message": "Audience_segments deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting audience_segments {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")