import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.channels import ChannelsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/channels", tags=["channels"])


# ---------- Pydantic Schemas ----------
class ChannelsData(BaseModel):
    """Entity data schema (for create/update)"""
    name: str
    slug: str
    status: str
    stage: str
    primary_language: str = None
    content_mode: str = None
    core_niche_id: int = None
    authority_score: float = None
    topic_drift_score: float = None
    expansion_readiness_score: float = None
    global_readiness_score: float = None
    domination_readiness_score: float = None
    subscriber_count: int = None
    total_views: int = None
    total_videos: int = None
    avg_watch_pct: float = None
    first_3s_hold: float = None
    rewatch_rate: float = None
    upload_frequency_hours: int = None
    youtube_channel_id: str = None
    current_strategy_id: int = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class ChannelsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    name: Optional[str] = None
    slug: Optional[str] = None
    status: Optional[str] = None
    stage: Optional[str] = None
    primary_language: Optional[str] = None
    content_mode: Optional[str] = None
    core_niche_id: Optional[int] = None
    authority_score: Optional[float] = None
    topic_drift_score: Optional[float] = None
    expansion_readiness_score: Optional[float] = None
    global_readiness_score: Optional[float] = None
    domination_readiness_score: Optional[float] = None
    subscriber_count: Optional[int] = None
    total_views: Optional[int] = None
    total_videos: Optional[int] = None
    avg_watch_pct: Optional[float] = None
    first_3s_hold: Optional[float] = None
    rewatch_rate: Optional[float] = None
    upload_frequency_hours: Optional[int] = None
    youtube_channel_id: Optional[str] = None
    current_strategy_id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class ChannelsResponse(BaseModel):
    """Entity response schema"""
    id: int
    name: str
    slug: str
    status: str
    stage: str
    primary_language: Optional[str] = None
    content_mode: Optional[str] = None
    core_niche_id: Optional[int] = None
    authority_score: Optional[float] = None
    topic_drift_score: Optional[float] = None
    expansion_readiness_score: Optional[float] = None
    global_readiness_score: Optional[float] = None
    domination_readiness_score: Optional[float] = None
    subscriber_count: Optional[int] = None
    total_views: Optional[int] = None
    total_videos: Optional[int] = None
    avg_watch_pct: Optional[float] = None
    first_3s_hold: Optional[float] = None
    rewatch_rate: Optional[float] = None
    upload_frequency_hours: Optional[int] = None
    youtube_channel_id: Optional[str] = None
    current_strategy_id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ChannelsListResponse(BaseModel):
    """List response schema"""
    items: List[ChannelsResponse]
    total: int
    skip: int
    limit: int


class ChannelsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[ChannelsData]


class ChannelsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: ChannelsUpdateData


class ChannelsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[ChannelsBatchUpdateItem]


class ChannelsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=ChannelsListResponse)
async def query_channelss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query channelss with filtering, sorting, and pagination"""
    logger.debug(f"Querying channelss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = ChannelsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} channelss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying channelss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=ChannelsListResponse)
async def query_channelss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query channelss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying channelss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = ChannelsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} channelss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying channelss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=ChannelsResponse)
async def get_channels(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single channels by ID"""
    logger.debug(f"Fetching channels with id: {id}, fields={fields}")
    
    service = ChannelsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Channels with id {id} not found")
            raise HTTPException(status_code=404, detail="Channels not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching channels {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=ChannelsResponse, status_code=201)
async def create_channels(
    data: ChannelsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new channels"""
    logger.debug(f"Creating new channels with data: {data}")
    
    service = ChannelsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create channels")
        
        logger.info(f"Channels created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating channels: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating channels: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[ChannelsResponse], status_code=201)
async def create_channelss_batch(
    request: ChannelsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple channelss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} channelss")
    
    service = ChannelsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} channelss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[ChannelsResponse])
async def update_channelss_batch(
    request: ChannelsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple channelss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} channelss")
    
    service = ChannelsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} channelss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=ChannelsResponse)
async def update_channels(
    id: int,
    data: ChannelsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing channels"""
    logger.debug(f"Updating channels {id} with data: {data}")

    service = ChannelsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Channels with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Channels not found")
        
        logger.info(f"Channels {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating channels {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating channels {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_channelss_batch(
    request: ChannelsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple channelss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} channelss")
    
    service = ChannelsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} channelss successfully")
        return {"message": f"Successfully deleted {deleted_count} channelss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_channels(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single channels by ID"""
    logger.debug(f"Deleting channels with id: {id}")
    
    service = ChannelsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Channels with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Channels not found")
        
        logger.info(f"Channels {id} deleted successfully")
        return {"message": "Channels deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting channels {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")