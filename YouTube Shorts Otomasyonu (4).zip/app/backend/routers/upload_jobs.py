import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.upload_jobs import Upload_jobsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/upload_jobs", tags=["upload_jobs"])


# ---------- Pydantic Schemas ----------
class Upload_jobsData(BaseModel):
    """Entity data schema (for create/update)"""
    channel_id: int
    video_id: int
    status: str
    priority: int = None
    youtube_video_id: str = None
    upload_attempts: int = None
    max_attempts: int = None
    error_message: str = None
    scheduled_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    created_at: Optional[datetime] = None


class Upload_jobsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    channel_id: Optional[int] = None
    video_id: Optional[int] = None
    status: Optional[str] = None
    priority: Optional[int] = None
    youtube_video_id: Optional[str] = None
    upload_attempts: Optional[int] = None
    max_attempts: Optional[int] = None
    error_message: Optional[str] = None
    scheduled_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    created_at: Optional[datetime] = None


class Upload_jobsResponse(BaseModel):
    """Entity response schema"""
    id: int
    channel_id: int
    video_id: int
    status: str
    priority: Optional[int] = None
    youtube_video_id: Optional[str] = None
    upload_attempts: Optional[int] = None
    max_attempts: Optional[int] = None
    error_message: Optional[str] = None
    scheduled_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Upload_jobsListResponse(BaseModel):
    """List response schema"""
    items: List[Upload_jobsResponse]
    total: int
    skip: int
    limit: int


class Upload_jobsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Upload_jobsData]


class Upload_jobsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Upload_jobsUpdateData


class Upload_jobsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Upload_jobsBatchUpdateItem]


class Upload_jobsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Upload_jobsListResponse)
async def query_upload_jobss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query upload_jobss with filtering, sorting, and pagination"""
    logger.debug(f"Querying upload_jobss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Upload_jobsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} upload_jobss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying upload_jobss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Upload_jobsListResponse)
async def query_upload_jobss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query upload_jobss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying upload_jobss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Upload_jobsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} upload_jobss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying upload_jobss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Upload_jobsResponse)
async def get_upload_jobs(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single upload_jobs by ID"""
    logger.debug(f"Fetching upload_jobs with id: {id}, fields={fields}")
    
    service = Upload_jobsService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Upload_jobs with id {id} not found")
            raise HTTPException(status_code=404, detail="Upload_jobs not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching upload_jobs {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Upload_jobsResponse, status_code=201)
async def create_upload_jobs(
    data: Upload_jobsData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new upload_jobs"""
    logger.debug(f"Creating new upload_jobs with data: {data}")
    
    service = Upload_jobsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create upload_jobs")
        
        logger.info(f"Upload_jobs created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating upload_jobs: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating upload_jobs: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Upload_jobsResponse], status_code=201)
async def create_upload_jobss_batch(
    request: Upload_jobsBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple upload_jobss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} upload_jobss")
    
    service = Upload_jobsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} upload_jobss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Upload_jobsResponse])
async def update_upload_jobss_batch(
    request: Upload_jobsBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple upload_jobss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} upload_jobss")
    
    service = Upload_jobsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} upload_jobss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Upload_jobsResponse)
async def update_upload_jobs(
    id: int,
    data: Upload_jobsUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing upload_jobs"""
    logger.debug(f"Updating upload_jobs {id} with data: {data}")

    service = Upload_jobsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Upload_jobs with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Upload_jobs not found")
        
        logger.info(f"Upload_jobs {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating upload_jobs {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating upload_jobs {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_upload_jobss_batch(
    request: Upload_jobsBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple upload_jobss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} upload_jobss")
    
    service = Upload_jobsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} upload_jobss successfully")
        return {"message": f"Successfully deleted {deleted_count} upload_jobss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_upload_jobs(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single upload_jobs by ID"""
    logger.debug(f"Deleting upload_jobs with id: {id}")
    
    service = Upload_jobsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Upload_jobs with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Upload_jobs not found")
        
        logger.info(f"Upload_jobs {id} deleted successfully")
        return {"message": "Upload_jobs deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting upload_jobs {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")