import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.stage_policies import Stage_policiesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/stage_policies", tags=["stage_policies"])


# ---------- Pydantic Schemas ----------
class Stage_policiesData(BaseModel):
    """Entity data schema (for create/update)"""
    stage: str
    min_videos_to_promote: int = None
    min_authority_score: float = None
    max_topic_drift: float = None
    min_first_3s_hold: float = None
    min_avg_watch_pct: float = None
    min_rewatch_rate: float = None
    max_core_audience_drop: float = None
    min_adjacent_hit_rate: float = None
    min_global_readiness: float = None
    max_spam_audience_score: float = None
    min_comments_quality: float = None
    core_content_ratio: float = None
    adjacent_content_ratio: float = None
    trend_content_ratio: float = None
    rollback_authority_threshold: float = None
    rollback_drift_threshold: float = None
    is_active: bool = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Stage_policiesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    stage: Optional[str] = None
    min_videos_to_promote: Optional[int] = None
    min_authority_score: Optional[float] = None
    max_topic_drift: Optional[float] = None
    min_first_3s_hold: Optional[float] = None
    min_avg_watch_pct: Optional[float] = None
    min_rewatch_rate: Optional[float] = None
    max_core_audience_drop: Optional[float] = None
    min_adjacent_hit_rate: Optional[float] = None
    min_global_readiness: Optional[float] = None
    max_spam_audience_score: Optional[float] = None
    min_comments_quality: Optional[float] = None
    core_content_ratio: Optional[float] = None
    adjacent_content_ratio: Optional[float] = None
    trend_content_ratio: Optional[float] = None
    rollback_authority_threshold: Optional[float] = None
    rollback_drift_threshold: Optional[float] = None
    is_active: Optional[bool] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Stage_policiesResponse(BaseModel):
    """Entity response schema"""
    id: int
    stage: str
    min_videos_to_promote: Optional[int] = None
    min_authority_score: Optional[float] = None
    max_topic_drift: Optional[float] = None
    min_first_3s_hold: Optional[float] = None
    min_avg_watch_pct: Optional[float] = None
    min_rewatch_rate: Optional[float] = None
    max_core_audience_drop: Optional[float] = None
    min_adjacent_hit_rate: Optional[float] = None
    min_global_readiness: Optional[float] = None
    max_spam_audience_score: Optional[float] = None
    min_comments_quality: Optional[float] = None
    core_content_ratio: Optional[float] = None
    adjacent_content_ratio: Optional[float] = None
    trend_content_ratio: Optional[float] = None
    rollback_authority_threshold: Optional[float] = None
    rollback_drift_threshold: Optional[float] = None
    is_active: Optional[bool] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Stage_policiesListResponse(BaseModel):
    """List response schema"""
    items: List[Stage_policiesResponse]
    total: int
    skip: int
    limit: int


class Stage_policiesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Stage_policiesData]


class Stage_policiesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Stage_policiesUpdateData


class Stage_policiesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Stage_policiesBatchUpdateItem]


class Stage_policiesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Stage_policiesListResponse)
async def query_stage_policiess(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query stage_policiess with filtering, sorting, and pagination"""
    logger.debug(f"Querying stage_policiess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Stage_policiesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} stage_policiess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying stage_policiess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Stage_policiesListResponse)
async def query_stage_policiess_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query stage_policiess with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying stage_policiess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Stage_policiesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} stage_policiess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying stage_policiess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Stage_policiesResponse)
async def get_stage_policies(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single stage_policies by ID"""
    logger.debug(f"Fetching stage_policies with id: {id}, fields={fields}")
    
    service = Stage_policiesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Stage_policies with id {id} not found")
            raise HTTPException(status_code=404, detail="Stage_policies not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching stage_policies {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Stage_policiesResponse, status_code=201)
async def create_stage_policies(
    data: Stage_policiesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new stage_policies"""
    logger.debug(f"Creating new stage_policies with data: {data}")
    
    service = Stage_policiesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create stage_policies")
        
        logger.info(f"Stage_policies created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating stage_policies: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating stage_policies: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Stage_policiesResponse], status_code=201)
async def create_stage_policiess_batch(
    request: Stage_policiesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple stage_policiess in a single request"""
    logger.debug(f"Batch creating {len(request.items)} stage_policiess")
    
    service = Stage_policiesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} stage_policiess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Stage_policiesResponse])
async def update_stage_policiess_batch(
    request: Stage_policiesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple stage_policiess in a single request"""
    logger.debug(f"Batch updating {len(request.items)} stage_policiess")
    
    service = Stage_policiesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} stage_policiess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Stage_policiesResponse)
async def update_stage_policies(
    id: int,
    data: Stage_policiesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing stage_policies"""
    logger.debug(f"Updating stage_policies {id} with data: {data}")

    service = Stage_policiesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Stage_policies with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Stage_policies not found")
        
        logger.info(f"Stage_policies {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating stage_policies {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating stage_policies {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_stage_policiess_batch(
    request: Stage_policiesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple stage_policiess by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} stage_policiess")
    
    service = Stage_policiesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} stage_policiess successfully")
        return {"message": f"Successfully deleted {deleted_count} stage_policiess", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_stage_policies(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single stage_policies by ID"""
    logger.debug(f"Deleting stage_policies with id: {id}")
    
    service = Stage_policiesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Stage_policies with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Stage_policies not found")
        
        logger.info(f"Stage_policies {id} deleted successfully")
        return {"message": "Stage_policies deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting stage_policies {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")