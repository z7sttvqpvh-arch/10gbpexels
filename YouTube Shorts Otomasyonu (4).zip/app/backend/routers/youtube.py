"""YouTube Integration API endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.youtube_service import (
    validate_youtube_credentials,
    prepare_upload,
    execute_upload,
    get_upload_queue,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/youtube", tags=["youtube"])


class UploadRequest(BaseModel):
    upload_job_id: int


class PrepareRequest(BaseModel):
    video_id: int


class QueueRequest(BaseModel):
    channel_id: Optional[int] = None


@router.get("/status")
async def youtube_status(db: AsyncSession = Depends(get_db)):
    """Check YouTube API credentials status."""
    try:
        result = await validate_youtube_credentials(db)
        return result
    except Exception as e:
        logger.error(f"YouTube status error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/prepare")
async def prepare(data: PrepareRequest, db: AsyncSession = Depends(get_db)):
    """Prepare video metadata for YouTube upload."""
    try:
        result = await prepare_upload(db, data.video_id)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Prepare upload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/upload")
async def upload(data: UploadRequest, db: AsyncSession = Depends(get_db)):
    """Execute a YouTube upload job."""
    try:
        result = await execute_upload(db, data.upload_job_id)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upload error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/queue")
async def queue(data: QueueRequest, db: AsyncSession = Depends(get_db)):
    """Get the upload queue."""
    try:
        result = await get_upload_queue(db, data.channel_id)
        return {"queue": result, "total": len(result)}
    except Exception as e:
        logger.error(f"Queue error: {e}")
        raise HTTPException(status_code=500, detail=str(e))