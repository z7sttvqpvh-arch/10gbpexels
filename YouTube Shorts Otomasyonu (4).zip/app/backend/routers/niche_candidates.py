import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.niche_candidates import Niche_candidatesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/niche_candidates", tags=["niche_candidates"])


# ---------- Pydantic Schemas ----------
class Niche_candidatesData(BaseModel):
    """Entity data schema (for create/update)"""
    niche_name: str
    category: str
    sub_category: str = None
    source: str = None
    gap_score: float = None
    visual_score: float = None
    repeatability_score: float = None
    global_transfer_score: float = None
    monetization_score: float = None
    saturation_score: float = None
    brandability_score: float = None
    risk_score: float = None
    total_score: float
    recommended_action: str
    status: str
    notes: str = None
    content_ideas_count: int = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Niche_candidatesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    niche_name: Optional[str] = None
    category: Optional[str] = None
    sub_category: Optional[str] = None
    source: Optional[str] = None
    gap_score: Optional[float] = None
    visual_score: Optional[float] = None
    repeatability_score: Optional[float] = None
    global_transfer_score: Optional[float] = None
    monetization_score: Optional[float] = None
    saturation_score: Optional[float] = None
    brandability_score: Optional[float] = None
    risk_score: Optional[float] = None
    total_score: Optional[float] = None
    recommended_action: Optional[str] = None
    status: Optional[str] = None
    notes: Optional[str] = None
    content_ideas_count: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class Niche_candidatesResponse(BaseModel):
    """Entity response schema"""
    id: int
    niche_name: str
    category: str
    sub_category: Optional[str] = None
    source: Optional[str] = None
    gap_score: Optional[float] = None
    visual_score: Optional[float] = None
    repeatability_score: Optional[float] = None
    global_transfer_score: Optional[float] = None
    monetization_score: Optional[float] = None
    saturation_score: Optional[float] = None
    brandability_score: Optional[float] = None
    risk_score: Optional[float] = None
    total_score: float
    recommended_action: str
    status: str
    notes: Optional[str] = None
    content_ideas_count: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Niche_candidatesListResponse(BaseModel):
    """List response schema"""
    items: List[Niche_candidatesResponse]
    total: int
    skip: int
    limit: int


class Niche_candidatesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Niche_candidatesData]


class Niche_candidatesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Niche_candidatesUpdateData


class Niche_candidatesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Niche_candidatesBatchUpdateItem]


class Niche_candidatesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Niche_candidatesListResponse)
async def query_niche_candidatess(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query niche_candidatess with filtering, sorting, and pagination"""
    logger.debug(f"Querying niche_candidatess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Niche_candidatesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} niche_candidatess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying niche_candidatess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Niche_candidatesListResponse)
async def query_niche_candidatess_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query niche_candidatess with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying niche_candidatess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Niche_candidatesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} niche_candidatess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying niche_candidatess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Niche_candidatesResponse)
async def get_niche_candidates(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single niche_candidates by ID"""
    logger.debug(f"Fetching niche_candidates with id: {id}, fields={fields}")
    
    service = Niche_candidatesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Niche_candidates with id {id} not found")
            raise HTTPException(status_code=404, detail="Niche_candidates not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching niche_candidates {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Niche_candidatesResponse, status_code=201)
async def create_niche_candidates(
    data: Niche_candidatesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new niche_candidates"""
    logger.debug(f"Creating new niche_candidates with data: {data}")
    
    service = Niche_candidatesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create niche_candidates")
        
        logger.info(f"Niche_candidates created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating niche_candidates: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating niche_candidates: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Niche_candidatesResponse], status_code=201)
async def create_niche_candidatess_batch(
    request: Niche_candidatesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple niche_candidatess in a single request"""
    logger.debug(f"Batch creating {len(request.items)} niche_candidatess")
    
    service = Niche_candidatesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} niche_candidatess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Niche_candidatesResponse])
async def update_niche_candidatess_batch(
    request: Niche_candidatesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple niche_candidatess in a single request"""
    logger.debug(f"Batch updating {len(request.items)} niche_candidatess")
    
    service = Niche_candidatesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} niche_candidatess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Niche_candidatesResponse)
async def update_niche_candidates(
    id: int,
    data: Niche_candidatesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing niche_candidates"""
    logger.debug(f"Updating niche_candidates {id} with data: {data}")

    service = Niche_candidatesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Niche_candidates with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Niche_candidates not found")
        
        logger.info(f"Niche_candidates {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating niche_candidates {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating niche_candidates {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_niche_candidatess_batch(
    request: Niche_candidatesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple niche_candidatess by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} niche_candidatess")
    
    service = Niche_candidatesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} niche_candidatess successfully")
        return {"message": f"Successfully deleted {deleted_count} niche_candidatess", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_niche_candidates(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single niche_candidates by ID"""
    logger.debug(f"Deleting niche_candidates with id: {id}")
    
    service = Niche_candidatesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Niche_candidates with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Niche_candidates not found")
        
        logger.info(f"Niche_candidates {id} deleted successfully")
        return {"message": "Niche_candidates deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting niche_candidates {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")