import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.channel_stage_histories import Channel_stage_historiesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/channel_stage_histories", tags=["channel_stage_histories"])


# ---------- Pydantic Schemas ----------
class Channel_stage_historiesData(BaseModel):
    """Entity data schema (for create/update)"""
    channel_id: int
    from_stage: str
    to_stage: str
    decision: str
    reason: str = None
    authority_score_at: float = None
    topic_drift_at: float = None
    subscriber_count_at: int = None
    total_videos_at: int = None
    triggered_by: str = None
    created_at: Optional[datetime] = None


class Channel_stage_historiesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    channel_id: Optional[int] = None
    from_stage: Optional[str] = None
    to_stage: Optional[str] = None
    decision: Optional[str] = None
    reason: Optional[str] = None
    authority_score_at: Optional[float] = None
    topic_drift_at: Optional[float] = None
    subscriber_count_at: Optional[int] = None
    total_videos_at: Optional[int] = None
    triggered_by: Optional[str] = None
    created_at: Optional[datetime] = None


class Channel_stage_historiesResponse(BaseModel):
    """Entity response schema"""
    id: int
    channel_id: int
    from_stage: str
    to_stage: str
    decision: str
    reason: Optional[str] = None
    authority_score_at: Optional[float] = None
    topic_drift_at: Optional[float] = None
    subscriber_count_at: Optional[int] = None
    total_videos_at: Optional[int] = None
    triggered_by: Optional[str] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class Channel_stage_historiesListResponse(BaseModel):
    """List response schema"""
    items: List[Channel_stage_historiesResponse]
    total: int
    skip: int
    limit: int


class Channel_stage_historiesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Channel_stage_historiesData]


class Channel_stage_historiesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Channel_stage_historiesUpdateData


class Channel_stage_historiesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Channel_stage_historiesBatchUpdateItem]


class Channel_stage_historiesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Channel_stage_historiesListResponse)
async def query_channel_stage_historiess(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query channel_stage_historiess with filtering, sorting, and pagination"""
    logger.debug(f"Querying channel_stage_historiess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Channel_stage_historiesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} channel_stage_historiess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying channel_stage_historiess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Channel_stage_historiesListResponse)
async def query_channel_stage_historiess_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query channel_stage_historiess with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying channel_stage_historiess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Channel_stage_historiesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} channel_stage_historiess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying channel_stage_historiess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Channel_stage_historiesResponse)
async def get_channel_stage_histories(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single channel_stage_histories by ID"""
    logger.debug(f"Fetching channel_stage_histories with id: {id}, fields={fields}")
    
    service = Channel_stage_historiesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Channel_stage_histories with id {id} not found")
            raise HTTPException(status_code=404, detail="Channel_stage_histories not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching channel_stage_histories {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Channel_stage_historiesResponse, status_code=201)
async def create_channel_stage_histories(
    data: Channel_stage_historiesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new channel_stage_histories"""
    logger.debug(f"Creating new channel_stage_histories with data: {data}")
    
    service = Channel_stage_historiesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create channel_stage_histories")
        
        logger.info(f"Channel_stage_histories created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating channel_stage_histories: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating channel_stage_histories: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Channel_stage_historiesResponse], status_code=201)
async def create_channel_stage_historiess_batch(
    request: Channel_stage_historiesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple channel_stage_historiess in a single request"""
    logger.debug(f"Batch creating {len(request.items)} channel_stage_historiess")
    
    service = Channel_stage_historiesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} channel_stage_historiess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Channel_stage_historiesResponse])
async def update_channel_stage_historiess_batch(
    request: Channel_stage_historiesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple channel_stage_historiess in a single request"""
    logger.debug(f"Batch updating {len(request.items)} channel_stage_historiess")
    
    service = Channel_stage_historiesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} channel_stage_historiess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Channel_stage_historiesResponse)
async def update_channel_stage_histories(
    id: int,
    data: Channel_stage_historiesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing channel_stage_histories"""
    logger.debug(f"Updating channel_stage_histories {id} with data: {data}")

    service = Channel_stage_historiesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Channel_stage_histories with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Channel_stage_histories not found")
        
        logger.info(f"Channel_stage_histories {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating channel_stage_histories {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating channel_stage_histories {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_channel_stage_historiess_batch(
    request: Channel_stage_historiesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple channel_stage_historiess by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} channel_stage_historiess")
    
    service = Channel_stage_historiesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} channel_stage_historiess successfully")
        return {"message": f"Successfully deleted {deleted_count} channel_stage_historiess", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_channel_stage_histories(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single channel_stage_histories by ID"""
    logger.debug(f"Deleting channel_stage_histories with id: {id}")
    
    service = Channel_stage_historiesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Channel_stage_histories with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Channel_stage_histories not found")
        
        logger.info(f"Channel_stage_histories {id} deleted successfully")
        return {"message": "Channel_stage_histories deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting channel_stage_histories {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")