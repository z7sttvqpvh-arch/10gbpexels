import json
import logging
from typing import List, Optional

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.videos import VideosService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/videos", tags=["videos"])


# ---------- Pydantic Schemas ----------
class VideosData(BaseModel):
    """Entity data schema (for create/update)"""
    channel_id: int
    title: str
    description: str = None
    tags: str = None
    hook_text: str = None
    script_text: str = None
    content_pillar: str = None
    content_type: str = None
    status: str
    youtube_video_id: str = None
    duration_seconds: int = None
    render_path: str = None
    thumbnail_path: str = None
    views: int = None
    likes: int = None
    comments_count: int = None
    first_3s_hold: float = None
    avg_watch_pct: float = None
    rewatch_rate: float = None
    published_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class VideosUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    channel_id: Optional[int] = None
    title: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[str] = None
    hook_text: Optional[str] = None
    script_text: Optional[str] = None
    content_pillar: Optional[str] = None
    content_type: Optional[str] = None
    status: Optional[str] = None
    youtube_video_id: Optional[str] = None
    duration_seconds: Optional[int] = None
    render_path: Optional[str] = None
    thumbnail_path: Optional[str] = None
    views: Optional[int] = None
    likes: Optional[int] = None
    comments_count: Optional[int] = None
    first_3s_hold: Optional[float] = None
    avg_watch_pct: Optional[float] = None
    rewatch_rate: Optional[float] = None
    published_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class VideosResponse(BaseModel):
    """Entity response schema"""
    id: int
    channel_id: int
    title: str
    description: Optional[str] = None
    tags: Optional[str] = None
    hook_text: Optional[str] = None
    script_text: Optional[str] = None
    content_pillar: Optional[str] = None
    content_type: Optional[str] = None
    status: str
    youtube_video_id: Optional[str] = None
    duration_seconds: Optional[int] = None
    render_path: Optional[str] = None
    thumbnail_path: Optional[str] = None
    views: Optional[int] = None
    likes: Optional[int] = None
    comments_count: Optional[int] = None
    first_3s_hold: Optional[float] = None
    avg_watch_pct: Optional[float] = None
    rewatch_rate: Optional[float] = None
    published_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class VideosListResponse(BaseModel):
    """List response schema"""
    items: List[VideosResponse]
    total: int
    skip: int
    limit: int


class VideosBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[VideosData]


class VideosBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: VideosUpdateData


class VideosBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[VideosBatchUpdateItem]


class VideosBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=VideosListResponse)
async def query_videoss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query videoss with filtering, sorting, and pagination"""
    logger.debug(f"Querying videoss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = VideosService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} videoss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying videoss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=VideosListResponse)
async def query_videoss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query videoss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying videoss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = VideosService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} videoss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying videoss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=VideosResponse)
async def get_videos(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single videos by ID"""
    logger.debug(f"Fetching videos with id: {id}, fields={fields}")
    
    service = VideosService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Videos with id {id} not found")
            raise HTTPException(status_code=404, detail="Videos not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching videos {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=VideosResponse, status_code=201)
async def create_videos(
    data: VideosData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new videos"""
    logger.debug(f"Creating new videos with data: {data}")
    
    service = VideosService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create videos")
        
        logger.info(f"Videos created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating videos: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating videos: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[VideosResponse], status_code=201)
async def create_videoss_batch(
    request: VideosBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple videoss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} videoss")
    
    service = VideosService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} videoss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[VideosResponse])
async def update_videoss_batch(
    request: VideosBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple videoss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} videoss")
    
    service = VideosService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} videoss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=VideosResponse)
async def update_videos(
    id: int,
    data: VideosUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing videos"""
    logger.debug(f"Updating videos {id} with data: {data}")

    service = VideosService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Videos with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Videos not found")
        
        logger.info(f"Videos {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating videos {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating videos {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_videoss_batch(
    request: VideosBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple videoss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} videoss")
    
    service = VideosService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} videoss successfully")
        return {"message": f"Successfully deleted {deleted_count} videoss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_videos(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single videos by ID"""
    logger.debug(f"Deleting videos with id: {id}")
    
    service = VideosService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Videos with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Videos not found")
        
        logger.info(f"Videos {id} deleted successfully")
        return {"message": "Videos deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting videos {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")