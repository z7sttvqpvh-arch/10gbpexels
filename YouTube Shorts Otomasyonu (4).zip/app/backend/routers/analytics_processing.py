"""Analytics Processing API endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.analytics_service import create_snapshot

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/analytics", tags=["analytics"])


class SnapshotRequest(BaseModel):
    channel_id: int
    days: int = 7


@router.post("/snapshot")
async def snapshot(data: SnapshotRequest, db: AsyncSession = Depends(get_db)):
    """Create an analytics snapshot for a channel."""
    try:
        result = await create_snapshot(db, data.channel_id, data.days)
        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Analytics snapshot error: {e}")
        raise HTTPException(status_code=500, detail=str(e))