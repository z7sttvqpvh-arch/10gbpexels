"""Channel Spawn API endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.channel_spawn_service import spawn_channel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/channel-spawn", tags=["channel-spawn"])


class SpawnRequest(BaseModel):
    name: str
    slug: str
    niche_id: int
    language: str = "en"
    content_mode: str = "faceless"


@router.post("/create")
async def create(data: SpawnRequest, db: AsyncSession = Depends(get_db)):
    """Spawn a new channel."""
    try:
        result = await spawn_channel(db, data.name, data.slug, data.niche_id, data.language, data.content_mode)
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Channel spawn error: {e}")
        raise HTTPException(status_code=500, detail=str(e))