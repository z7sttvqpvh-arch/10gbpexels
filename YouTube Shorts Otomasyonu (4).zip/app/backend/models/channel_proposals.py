from core.database import Base
from sqlalchemy import Column, DateTime, Integer, String


class Channel_proposals(Base):
    __tablename__ = "channel_proposals"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    niche_id = Column(Integer, nullable=False)
    niche_name = Column(String, nullable=False)
    proposed_name = Column(String, nullable=False)
    proposed_slug = Column(String, nullable=False)
    proposed_description = Column(String, nullable=True)
    proposed_language = Column(String, nullable=True)
    content_mode = Column(String, nullable=True)
    target_audience = Column(String, nullable=True)
    category = Column(String, nullable=True)
    status = Column(String, nullable=False)
    channel_id = Column(Integer, nullable=True)
    youtube_channel_id = Column(String, nullable=True)
    rejection_reason = Column(String, nullable=True)
    error_message = Column(String, nullable=True)
    auto_content_enabled = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)