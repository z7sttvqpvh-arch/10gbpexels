from core.database import Base
from sqlalchemy import Column, DateTime, Float, Integer, String


class Channel_stage_histories(Base):
    __tablename__ = "channel_stage_histories"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    channel_id = Column(Integer, nullable=False)
    from_stage = Column(String, nullable=False)
    to_stage = Column(String, nullable=False)
    decision = Column(String, nullable=False)
    reason = Column(String, nullable=True)
    authority_score_at = Column(Float, nullable=True)
    topic_drift_at = Column(Float, nullable=True)
    subscriber_count_at = Column(Integer, nullable=True)
    total_videos_at = Column(Integer, nullable=True)
    triggered_by = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)