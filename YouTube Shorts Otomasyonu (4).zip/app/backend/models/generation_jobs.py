from core.database import Base
from sqlalchemy import Column, DateTime, Integer, String


class Generation_jobs(Base):
    __tablename__ = "generation_jobs"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    channel_id = Column(Integer, nullable=True)
    video_id = Column(Integer, nullable=True)
    job_type = Column(String, nullable=False)
    status = Column(String, nullable=False)
    priority = Column(Integer, nullable=True)
    input_data = Column(String, nullable=True)
    output_data = Column(String, nullable=True)
    error_message = Column(String, nullable=True)
    retry_count = Column(Integer, nullable=True)
    max_retries = Column(Integer, nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=True)
    finished_at = Column(DateTime(timezone=True), nullable=True)
    next_run_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)