from core.database import Base
from sqlalchemy import Column, DateTime, Integer, String


class Upload_jobs(Base):
    __tablename__ = "upload_jobs"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    channel_id = Column(Integer, nullable=False)
    video_id = Column(Integer, nullable=False)
    status = Column(String, nullable=False)
    priority = Column(Integer, nullable=True)
    youtube_video_id = Column(String, nullable=True)
    upload_attempts = Column(Integer, nullable=True)
    max_attempts = Column(Integer, nullable=True)
    error_message = Column(String, nullable=True)
    scheduled_at = Column(DateTime(timezone=True), nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=True)
    finished_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)