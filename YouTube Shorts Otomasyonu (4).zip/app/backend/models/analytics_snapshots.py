from core.database import Base
from sqlalchemy import Column, DateTime, Float, Integer


class Analytics_snapshots(Base):
    __tablename__ = "analytics_snapshots"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    channel_id = Column(Integer, nullable=False)
    period_start = Column(DateTime(timezone=True), nullable=True)
    period_end = Column(DateTime(timezone=True), nullable=True)
    total_views = Column(Integer, nullable=True)
    total_subscribers_gained = Column(Integer, nullable=True)
    total_subscribers_lost = Column(Integer, nullable=True)
    avg_first_3s_hold = Column(Float, nullable=True)
    avg_watch_pct = Column(Float, nullable=True)
    avg_rewatch_rate = Column(Float, nullable=True)
    authority_score = Column(Float, nullable=True)
    topic_drift_score = Column(Float, nullable=True)
    audience_match_score = Column(Float, nullable=True)
    comments_quality_score = Column(Float, nullable=True)
    global_readiness_score = Column(Float, nullable=True)
    spam_audience_score = Column(Float, nullable=True)
    core_audience_drop = Column(Float, nullable=True)
    adjacent_hit_rate = Column(Float, nullable=True)
    videos_published = Column(Integer, nullable=True)
    top_performing_video_id = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)