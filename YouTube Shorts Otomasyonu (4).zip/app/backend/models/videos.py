from core.database import Base
from sqlalchemy import Column, DateTime, Float, Integer, String


class Videos(Base):
    __tablename__ = "videos"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    channel_id = Column(Integer, nullable=False)
    title = Column(String, nullable=False)
    description = Column(String, nullable=True)
    tags = Column(String, nullable=True)
    hook_text = Column(String, nullable=True)
    script_text = Column(String, nullable=True)
    content_pillar = Column(String, nullable=True)
    content_type = Column(String, nullable=True)
    status = Column(String, nullable=False)
    youtube_video_id = Column(String, nullable=True)
    duration_seconds = Column(Integer, nullable=True)
    render_path = Column(String, nullable=True)
    thumbnail_path = Column(String, nullable=True)
    views = Column(Integer, nullable=True)
    likes = Column(Integer, nullable=True)
    comments_count = Column(Integer, nullable=True)
    first_3s_hold = Column(Float, nullable=True)
    avg_watch_pct = Column(Float, nullable=True)
    rewatch_rate = Column(Float, nullable=True)
    published_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)