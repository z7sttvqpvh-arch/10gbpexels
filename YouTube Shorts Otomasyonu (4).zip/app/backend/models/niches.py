from core.database import Base
from sqlalchemy import Column, DateTime, Float, Integer, String


class Niches(Base):
    __tablename__ = "niches"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    name = Column(String, nullable=False)
    slug = Column(String, nullable=False)
    category = Column(String, nullable=False)
    sub_category = Column(String, nullable=True)
    description = Column(String, nullable=True)
    saturation_level = Column(String, nullable=True)
    visual_suitability = Column(Float, nullable=True)
    repeatability_score = Column(Float, nullable=True)
    global_transfer_score = Column(Float, nullable=True)
    monetization_potential = Column(Float, nullable=True)
    status = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)