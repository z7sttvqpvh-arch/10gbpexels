from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String


class Strategy_snapshots(Base):
    __tablename__ = "strategy_snapshots"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    channel_id = Column(Integer, nullable=False)
    stage = Column(String, nullable=False)
    content_pillars = Column(String, nullable=True)
    content_mix = Column(String, nullable=True)
    hook_families = Column(String, nullable=True)
    title_families = Column(String, nullable=True)
    thumbnail_families = Column(String, nullable=True)
    upload_tempo_hours = Column(Integer, nullable=True)
    content_mode = Column(String, nullable=True)
    target_audience = Column(String, nullable=True)
    authority_score_at = Column(Float, nullable=True)
    topic_drift_at = Column(Float, nullable=True)
    is_current = Column(Boolean, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)