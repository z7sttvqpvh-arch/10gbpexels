from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String


class Stage_policies(Base):
    __tablename__ = "stage_policies"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    stage = Column(String, nullable=False)
    min_videos_to_promote = Column(Integer, nullable=True)
    min_authority_score = Column(Float, nullable=True)
    max_topic_drift = Column(Float, nullable=True)
    min_first_3s_hold = Column(Float, nullable=True)
    min_avg_watch_pct = Column(Float, nullable=True)
    min_rewatch_rate = Column(Float, nullable=True)
    max_core_audience_drop = Column(Float, nullable=True)
    min_adjacent_hit_rate = Column(Float, nullable=True)
    min_global_readiness = Column(Float, nullable=True)
    max_spam_audience_score = Column(Float, nullable=True)
    min_comments_quality = Column(Float, nullable=True)
    core_content_ratio = Column(Float, nullable=True)
    adjacent_content_ratio = Column(Float, nullable=True)
    trend_content_ratio = Column(Float, nullable=True)
    rollback_authority_threshold = Column(Float, nullable=True)
    rollback_drift_threshold = Column(Float, nullable=True)
    is_active = Column(Boolean, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)