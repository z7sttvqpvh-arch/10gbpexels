from core.database import Base
from sqlalchemy import Column, DateTime, Float, Integer, String


class Audience_segments(Base):
    __tablename__ = "audience_segments"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    channel_id = Column(Integer, nullable=False)
    segment_name = Column(String, nullable=False)
    percentage = Column(Float, nullable=True)
    age_range = Column(String, nullable=True)
    primary_region = Column(String, nullable=True)
    interest_tags = Column(String, nullable=True)
    engagement_level = Column(String, nullable=True)
    retention_rate = Column(Float, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)