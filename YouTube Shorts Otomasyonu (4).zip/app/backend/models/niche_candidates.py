from core.database import Base
from sqlalchemy import Column, DateTime, Float, Integer, String


class Niche_candidates(Base):
    __tablename__ = "niche_candidates"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    niche_name = Column(String, nullable=False)
    category = Column(String, nullable=False)
    sub_category = Column(String, nullable=True)
    source = Column(String, nullable=True)
    gap_score = Column(Float, nullable=True)
    visual_score = Column(Float, nullable=True)
    repeatability_score = Column(Float, nullable=True)
    global_transfer_score = Column(Float, nullable=True)
    monetization_score = Column(Float, nullable=True)
    saturation_score = Column(Float, nullable=True)
    brandability_score = Column(Float, nullable=True)
    risk_score = Column(Float, nullable=True)
    total_score = Column(Float, nullable=False)
    recommended_action = Column(String, nullable=False)
    status = Column(String, nullable=False)
    notes = Column(String, nullable=True)
    content_ideas_count = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)