from core.database import Base
from sqlalchemy import Column, DateTime, Integer, String


class Api_keys(Base):
    __tablename__ = "api_keys"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    service_name = Column(String, nullable=False)
    key_label = Column(String, nullable=False)
    key_value = Column(String, nullable=False)
    key_type = Column(String, nullable=False)
    status = Column(String, nullable=False)
    last_used_at = Column(DateTime(timezone=True), nullable=True)
    error_count = Column(Integer, nullable=True)
    total_requests = Column(Integer, nullable=True)
    notes = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)