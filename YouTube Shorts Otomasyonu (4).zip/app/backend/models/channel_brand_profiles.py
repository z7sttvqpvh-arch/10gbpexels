from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Integer, String


class Channel_brand_profiles(Base):
    __tablename__ = "channel_brand_profiles"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    channel_id = Column(Integer, nullable=False)
    channel_name_display = Column(String, nullable=False)
    short_description = Column(String, nullable=True)
    slogan = Column(String, nullable=True)
    tone = Column(String, nullable=False)
    thumbnail_style = Column(String, nullable=True)
    logo_prompt = Column(String, nullable=True)
    banner_prompt = Column(String, nullable=True)
    color_primary = Column(String, nullable=True)
    color_secondary = Column(String, nullable=True)
    identity_version = Column(Integer, nullable=True)
    is_active = Column(Boolean, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)