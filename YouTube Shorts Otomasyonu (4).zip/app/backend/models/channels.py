from core.database import Base
from sqlalchemy import Column, DateTime, Float, Integer, String


class Channels(Base):
    __tablename__ = "channels"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    name = Column(String, nullable=False)
    slug = Column(String, nullable=False)
    status = Column(String, nullable=False)
    stage = Column(String, nullable=False)
    primary_language = Column(String, nullable=True)
    content_mode = Column(String, nullable=True)
    core_niche_id = Column(Integer, nullable=True)
    authority_score = Column(Float, nullable=True)
    topic_drift_score = Column(Float, nullable=True)
    expansion_readiness_score = Column(Float, nullable=True)
    global_readiness_score = Column(Float, nullable=True)
    domination_readiness_score = Column(Float, nullable=True)
    subscriber_count = Column(Integer, nullable=True)
    total_views = Column(Integer, nullable=True)
    total_videos = Column(Integer, nullable=True)
    avg_watch_pct = Column(Float, nullable=True)
    first_3s_hold = Column(Float, nullable=True)
    rewatch_rate = Column(Float, nullable=True)
    upload_frequency_hours = Column(Integer, nullable=True)
    youtube_channel_id = Column(String, nullable=True)
    current_strategy_id = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)