from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Integer, String


class System_settings(Base):
    __tablename__ = "system_settings"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    setting_key = Column(String, nullable=False)
    setting_value = Column(String, nullable=False)
    setting_type = Column(String, nullable=False)
    category = Column(String, nullable=True)
    description = Column(String, nullable=True)
    is_sensitive = Column(Boolean, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)