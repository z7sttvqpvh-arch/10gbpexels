import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.channels import Channels

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class ChannelsService:
    """Service layer for Channels operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Channels]:
        """Create a new channels"""
        try:
            obj = Channels(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created channels with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating channels: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Channels]:
        """Get channels by ID"""
        try:
            query = select(Channels).where(Channels.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching channels {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of channelss"""
        try:
            query = select(Channels)
            count_query = select(func.count(Channels.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Channels, field):
                        query = query.where(getattr(Channels, field) == value)
                        count_query = count_query.where(getattr(Channels, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Channels, field_name):
                        query = query.order_by(getattr(Channels, field_name).desc())
                else:
                    if hasattr(Channels, sort):
                        query = query.order_by(getattr(Channels, sort))
            else:
                query = query.order_by(Channels.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching channels list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Channels]:
        """Update channels"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Channels {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated channels {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating channels {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete channels"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Channels {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted channels {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting channels {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Channels]:
        """Get channels by any field"""
        try:
            if not hasattr(Channels, field_name):
                raise ValueError(f"Field {field_name} does not exist on Channels")
            result = await self.db.execute(
                select(Channels).where(getattr(Channels, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching channels by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Channels]:
        """Get list of channelss filtered by field"""
        try:
            if not hasattr(Channels, field_name):
                raise ValueError(f"Field {field_name} does not exist on Channels")
            result = await self.db.execute(
                select(Channels)
                .where(getattr(Channels, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Channels.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching channelss by {field_name}: {str(e)}")
            raise