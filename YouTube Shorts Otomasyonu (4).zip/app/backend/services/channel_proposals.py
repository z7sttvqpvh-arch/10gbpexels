import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.channel_proposals import Channel_proposals

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Channel_proposalsService:
    """Service layer for Channel_proposals operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Channel_proposals]:
        """Create a new channel_proposals"""
        try:
            obj = Channel_proposals(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created channel_proposals with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating channel_proposals: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Channel_proposals]:
        """Get channel_proposals by ID"""
        try:
            query = select(Channel_proposals).where(Channel_proposals.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching channel_proposals {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of channel_proposalss"""
        try:
            query = select(Channel_proposals)
            count_query = select(func.count(Channel_proposals.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Channel_proposals, field):
                        query = query.where(getattr(Channel_proposals, field) == value)
                        count_query = count_query.where(getattr(Channel_proposals, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Channel_proposals, field_name):
                        query = query.order_by(getattr(Channel_proposals, field_name).desc())
                else:
                    if hasattr(Channel_proposals, sort):
                        query = query.order_by(getattr(Channel_proposals, sort))
            else:
                query = query.order_by(Channel_proposals.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching channel_proposals list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Channel_proposals]:
        """Update channel_proposals"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Channel_proposals {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated channel_proposals {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating channel_proposals {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete channel_proposals"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Channel_proposals {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted channel_proposals {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting channel_proposals {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Channel_proposals]:
        """Get channel_proposals by any field"""
        try:
            if not hasattr(Channel_proposals, field_name):
                raise ValueError(f"Field {field_name} does not exist on Channel_proposals")
            result = await self.db.execute(
                select(Channel_proposals).where(getattr(Channel_proposals, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching channel_proposals by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Channel_proposals]:
        """Get list of channel_proposalss filtered by field"""
        try:
            if not hasattr(Channel_proposals, field_name):
                raise ValueError(f"Field {field_name} does not exist on Channel_proposals")
            result = await self.db.execute(
                select(Channel_proposals)
                .where(getattr(Channel_proposals, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Channel_proposals.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching channel_proposalss by {field_name}: {str(e)}")
            raise