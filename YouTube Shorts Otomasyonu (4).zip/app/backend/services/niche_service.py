"""Niche Discovery - AI-powered niche scanning and scoring."""
import logging
import json
from datetime import datetime
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.niche_candidates import Niche_candidates
from models.niches import Niches
from services.aihub import AIHubService
from schemas.aihub import GenTxtRequest, ChatMessage

logger = logging.getLogger(__name__)

ai_service = AIHubService()


async def discover_niches(db: AsyncSession, category: str, count: int = 5) -> dict:
    """Use AI to discover new niche candidates in a category."""
    prompt = f"""You are a YouTube Shorts niche research expert. Discover {count} promising niche opportunities in the "{category}" category.

For each niche, provide:
- niche_name: A specific, focused niche name
- sub_category: Sub-category within {category}
- gap_score: 0-100 (how much opportunity gap exists)
- visual_score: 0-100 (how visually suitable for Shorts)
- repeatability_score: 0-100 (how easily content can be repeated)
- global_transfer_score: 0-100 (how well it transfers across cultures)
- monetization_score: 0-100 (monetization potential)
- saturation_score: 0-100 (lower = less saturated = better)
- brandability_score: 0-100 (how brandable the niche is)
- risk_score: 0-100 (lower = less risky = better)
- content_ideas_count: number of content ideas possible
- recommended_action: "approve" or "investigate" or "reject"
- notes: Brief explanation

Return ONLY a JSON array of objects. No markdown, no explanation."""

    request = GenTxtRequest(
        messages=[
            ChatMessage(role="system", content="You are a YouTube Shorts niche research expert. Return only valid JSON."),
            ChatMessage(role="user", content=prompt),
        ],
        model="deepseek-v3.2",
    )

    response = await ai_service.gentxt(request)
    content = response.content.strip()

    # Parse JSON from response
    if content.startswith("```"):
        content = content.split("\n", 1)[1].rsplit("```", 1)[0]

    try:
        niches_data = json.loads(content)
    except json.JSONDecodeError:
        return {"error": "Failed to parse AI response", "raw": content}

    created = []
    for n in niches_data:
        total = (
            (n.get("gap_score", 0) * 0.2)
            + (n.get("visual_score", 0) * 0.15)
            + (n.get("repeatability_score", 0) * 0.15)
            + (n.get("global_transfer_score", 0) * 0.15)
            + (n.get("monetization_score", 0) * 0.15)
            + ((100 - n.get("saturation_score", 50)) * 0.1)
            + (n.get("brandability_score", 0) * 0.1)
        )
        candidate = Niche_candidates(
            niche_name=n.get("niche_name", "Unknown"),
            category=category,
            sub_category=n.get("sub_category", ""),
            source="ai_discovery",
            gap_score=n.get("gap_score", 0),
            visual_score=n.get("visual_score", 0),
            repeatability_score=n.get("repeatability_score", 0),
            global_transfer_score=n.get("global_transfer_score", 0),
            monetization_score=n.get("monetization_score", 0),
            saturation_score=n.get("saturation_score", 50),
            brandability_score=n.get("brandability_score", 0),
            risk_score=n.get("risk_score", 50),
            total_score=round(total, 1),
            recommended_action=n.get("recommended_action", "investigate"),
            status="pending",
            notes=n.get("notes", ""),
            content_ideas_count=n.get("content_ideas_count", 0),
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        db.add(candidate)
        created.append(n.get("niche_name", "Unknown"))

    await db.commit()
    return {"created": len(created), "niches": created}


async def approve_candidate(db: AsyncSession, candidate_id: int) -> dict:
    """Approve a niche candidate and create a niche entry."""
    result = await db.execute(select(Niche_candidates).where(Niche_candidates.id == candidate_id))
    candidate = result.scalar_one_or_none()
    if not candidate:
        return {"error": "Candidate not found"}

    # Create niche from candidate
    niche = Niches(
        name=candidate.niche_name,
        slug=candidate.niche_name.lower().replace(" ", "-"),
        category=candidate.category,
        sub_category=candidate.sub_category or "",
        description=candidate.notes or "",
        saturation_level="low" if candidate.saturation_score < 30 else "medium" if candidate.saturation_score < 60 else "high",
        visual_suitability=candidate.visual_score or 0,
        repeatability_score=candidate.repeatability_score or 0,
        global_transfer_score=candidate.global_transfer_score or 0,
        monetization_potential=candidate.monetization_score or 0,
        status="active",
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    db.add(niche)

    # Update candidate status
    await db.execute(
        update(Niche_candidates)
        .where(Niche_candidates.id == candidate_id)
        .values(status="approved", updated_at=datetime.now())
    )

    await db.commit()
    return {"status": "approved", "niche_name": candidate.niche_name}