"""Analytics Processing - Metric calculation and snapshot creation."""
import logging
from datetime import datetime, timedelta
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.channels import Channels
from models.videos import Videos
from models.analytics_snapshots import Analytics_snapshots

logger = logging.getLogger(__name__)


async def create_snapshot(db: AsyncSession, channel_id: int, days: int = 7) -> dict:
    """Create an analytics snapshot for a channel over the last N days."""
    result = await db.execute(select(Channels).where(Channels.id == channel_id))
    channel = result.scalar_one_or_none()
    if not channel:
        return {"error": "Channel not found"}

    period_end = datetime.now()
    period_start = period_end - timedelta(days=days)

    # Get videos in period
    vid_result = await db.execute(
        select(Videos).where(
            Videos.channel_id == channel_id,
            Videos.created_at >= period_start,
        )
    )
    videos = vid_result.scalars().all()

    total_views = sum(v.views or 0 for v in videos)
    videos_published = len([v for v in videos if v.status == "published"])
    avg_3s = sum(v.first_3s_hold or 0 for v in videos) / len(videos) if videos else 0
    avg_watch = sum(v.avg_watch_pct or 0 for v in videos) / len(videos) if videos else 0
    avg_rewatch = sum(v.rewatch_rate or 0 for v in videos) / len(videos) if videos else 0

    # Find top performing video
    top_video = max(videos, key=lambda v: v.views or 0) if videos else None

    snapshot = Analytics_snapshots(
        channel_id=channel_id,
        period_start=period_start,
        period_end=period_end,
        total_views=total_views,
        total_subscribers_gained=0,
        total_subscribers_lost=0,
        avg_first_3s_hold=round(avg_3s, 2),
        avg_watch_pct=round(avg_watch, 2),
        avg_rewatch_rate=round(avg_rewatch, 2),
        authority_score=channel.authority_score or 0,
        topic_drift_score=channel.topic_drift_score or 0,
        audience_match_score=0,
        comments_quality_score=0,
        global_readiness_score=channel.global_readiness_score or 0,
        spam_audience_score=0,
        core_audience_drop=0,
        adjacent_hit_rate=0,
        videos_published=videos_published,
        top_performing_video_id=top_video.id if top_video else 0,
        created_at=datetime.now(),
    )
    db.add(snapshot)
    await db.commit()

    return {
        "channel_id": channel_id,
        "period": f"{period_start.date()} to {period_end.date()}",
        "total_views": total_views,
        "videos_published": videos_published,
        "avg_3s_hold": round(avg_3s, 2),
        "avg_watch_pct": round(avg_watch, 2),
    }