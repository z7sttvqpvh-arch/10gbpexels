import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.strategy_snapshots import Strategy_snapshots

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Strategy_snapshotsService:
    """Service layer for Strategy_snapshots operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Strategy_snapshots]:
        """Create a new strategy_snapshots"""
        try:
            obj = Strategy_snapshots(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created strategy_snapshots with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating strategy_snapshots: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Strategy_snapshots]:
        """Get strategy_snapshots by ID"""
        try:
            query = select(Strategy_snapshots).where(Strategy_snapshots.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching strategy_snapshots {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of strategy_snapshotss"""
        try:
            query = select(Strategy_snapshots)
            count_query = select(func.count(Strategy_snapshots.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Strategy_snapshots, field):
                        query = query.where(getattr(Strategy_snapshots, field) == value)
                        count_query = count_query.where(getattr(Strategy_snapshots, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Strategy_snapshots, field_name):
                        query = query.order_by(getattr(Strategy_snapshots, field_name).desc())
                else:
                    if hasattr(Strategy_snapshots, sort):
                        query = query.order_by(getattr(Strategy_snapshots, sort))
            else:
                query = query.order_by(Strategy_snapshots.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching strategy_snapshots list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Strategy_snapshots]:
        """Update strategy_snapshots"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Strategy_snapshots {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated strategy_snapshots {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating strategy_snapshots {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete strategy_snapshots"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Strategy_snapshots {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted strategy_snapshots {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting strategy_snapshots {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Strategy_snapshots]:
        """Get strategy_snapshots by any field"""
        try:
            if not hasattr(Strategy_snapshots, field_name):
                raise ValueError(f"Field {field_name} does not exist on Strategy_snapshots")
            result = await self.db.execute(
                select(Strategy_snapshots).where(getattr(Strategy_snapshots, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching strategy_snapshots by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Strategy_snapshots]:
        """Get list of strategy_snapshotss filtered by field"""
        try:
            if not hasattr(Strategy_snapshots, field_name):
                raise ValueError(f"Field {field_name} does not exist on Strategy_snapshots")
            result = await self.db.execute(
                select(Strategy_snapshots)
                .where(getattr(Strategy_snapshots, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Strategy_snapshots.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching strategy_snapshotss by {field_name}: {str(e)}")
            raise