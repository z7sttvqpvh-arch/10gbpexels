"""Channel Spawn - New channel creation with validation."""
import logging
from datetime import datetime
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from models.channels import Channels
from models.niches import Niches
from models.channel_brand_profiles import Channel_brand_profiles
from models.strategy_snapshots import Strategy_snapshots

logger = logging.getLogger(__name__)


async def spawn_channel(
    db: AsyncSession,
    name: str,
    slug: str,
    niche_id: int,
    language: str = "en",
    content_mode: str = "faceless",
) -> dict:
    """Create a new channel with brand profile and initial strategy."""
    # Validate niche exists
    result = await db.execute(select(Niches).where(Niches.id == niche_id))
    niche = result.scalar_one_or_none()
    if not niche:
        return {"error": "Niche not found"}

    # Check slug uniqueness
    result = await db.execute(select(Channels).where(Channels.slug == slug))
    if result.scalar_one_or_none():
        return {"error": f"Channel slug '{slug}' already exists"}

    # Create channel
    channel = Channels(
        name=name,
        slug=slug,
        status="incubating",
        stage="micro_niche",
        primary_language=language,
        content_mode=content_mode,
        core_niche_id=niche_id,
        authority_score=0,
        topic_drift_score=0,
        expansion_readiness_score=0,
        global_readiness_score=0,
        domination_readiness_score=0,
        subscriber_count=0,
        total_views=0,
        total_videos=0,
        avg_watch_pct=0,
        first_3s_hold=0,
        rewatch_rate=0,
        upload_frequency_hours=24,
        youtube_channel_id="",
        current_strategy_id=0,
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    db.add(channel)
    await db.flush()

    # Create brand profile
    brand = Channel_brand_profiles(
        channel_id=channel.id,
        channel_name_display=name,
        short_description=f"A {niche.name} focused YouTube Shorts channel",
        slogan="",
        tone="informative",
        thumbnail_style="bold_text_overlay",
        logo_prompt=f"Minimalist logo for {name}, {niche.name} theme",
        banner_prompt=f"YouTube banner for {name}, {niche.name} theme",
        color_primary="#E94560",
        color_secondary="#533483",
        identity_version=1,
        is_active=True,
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    db.add(brand)

    # Create initial strategy
    strategy = Strategy_snapshots(
        channel_id=channel.id,
        stage="micro_niche",
        content_pillars=niche.name,
        content_mix="core:80,adjacent:15,trend:5",
        hook_families="question,shocking_fact,visual_hook",
        title_families="how_to,listicle,versus",
        thumbnail_families="bold_text,before_after,close_up",
        upload_tempo_hours=24,
        content_mode=content_mode,
        target_audience="general",
        authority_score_at=0,
        topic_drift_at=0,
        is_current=True,
        created_at=datetime.now(),
    )
    db.add(strategy)
    await db.flush()

    # Update channel with strategy id
    channel.current_strategy_id = strategy.id
    await db.commit()

    return {
        "channel_id": channel.id,
        "name": name,
        "slug": slug,
        "stage": "micro_niche",
        "niche": niche.name,
        "status": "incubating",
    }