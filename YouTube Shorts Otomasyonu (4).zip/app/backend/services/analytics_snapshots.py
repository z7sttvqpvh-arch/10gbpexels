import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.analytics_snapshots import Analytics_snapshots

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Analytics_snapshotsService:
    """Service layer for Analytics_snapshots operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Analytics_snapshots]:
        """Create a new analytics_snapshots"""
        try:
            obj = Analytics_snapshots(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created analytics_snapshots with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating analytics_snapshots: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Analytics_snapshots]:
        """Get analytics_snapshots by ID"""
        try:
            query = select(Analytics_snapshots).where(Analytics_snapshots.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching analytics_snapshots {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of analytics_snapshotss"""
        try:
            query = select(Analytics_snapshots)
            count_query = select(func.count(Analytics_snapshots.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Analytics_snapshots, field):
                        query = query.where(getattr(Analytics_snapshots, field) == value)
                        count_query = count_query.where(getattr(Analytics_snapshots, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Analytics_snapshots, field_name):
                        query = query.order_by(getattr(Analytics_snapshots, field_name).desc())
                else:
                    if hasattr(Analytics_snapshots, sort):
                        query = query.order_by(getattr(Analytics_snapshots, sort))
            else:
                query = query.order_by(Analytics_snapshots.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching analytics_snapshots list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Analytics_snapshots]:
        """Update analytics_snapshots"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Analytics_snapshots {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated analytics_snapshots {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating analytics_snapshots {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete analytics_snapshots"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Analytics_snapshots {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted analytics_snapshots {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting analytics_snapshots {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Analytics_snapshots]:
        """Get analytics_snapshots by any field"""
        try:
            if not hasattr(Analytics_snapshots, field_name):
                raise ValueError(f"Field {field_name} does not exist on Analytics_snapshots")
            result = await self.db.execute(
                select(Analytics_snapshots).where(getattr(Analytics_snapshots, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching analytics_snapshots by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Analytics_snapshots]:
        """Get list of analytics_snapshotss filtered by field"""
        try:
            if not hasattr(Analytics_snapshots, field_name):
                raise ValueError(f"Field {field_name} does not exist on Analytics_snapshots")
            result = await self.db.execute(
                select(Analytics_snapshots)
                .where(getattr(Analytics_snapshots, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Analytics_snapshots.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching analytics_snapshotss by {field_name}: {str(e)}")
            raise