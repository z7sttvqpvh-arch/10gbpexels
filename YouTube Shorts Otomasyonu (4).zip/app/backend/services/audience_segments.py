import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.audience_segments import Audience_segments

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Audience_segmentsService:
    """Service layer for Audience_segments operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Audience_segments]:
        """Create a new audience_segments"""
        try:
            obj = Audience_segments(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created audience_segments with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating audience_segments: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Audience_segments]:
        """Get audience_segments by ID"""
        try:
            query = select(Audience_segments).where(Audience_segments.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching audience_segments {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of audience_segmentss"""
        try:
            query = select(Audience_segments)
            count_query = select(func.count(Audience_segments.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Audience_segments, field):
                        query = query.where(getattr(Audience_segments, field) == value)
                        count_query = count_query.where(getattr(Audience_segments, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Audience_segments, field_name):
                        query = query.order_by(getattr(Audience_segments, field_name).desc())
                else:
                    if hasattr(Audience_segments, sort):
                        query = query.order_by(getattr(Audience_segments, sort))
            else:
                query = query.order_by(Audience_segments.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching audience_segments list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Audience_segments]:
        """Update audience_segments"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Audience_segments {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated audience_segments {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating audience_segments {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete audience_segments"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Audience_segments {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted audience_segments {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting audience_segments {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Audience_segments]:
        """Get audience_segments by any field"""
        try:
            if not hasattr(Audience_segments, field_name):
                raise ValueError(f"Field {field_name} does not exist on Audience_segments")
            result = await self.db.execute(
                select(Audience_segments).where(getattr(Audience_segments, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching audience_segments by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Audience_segments]:
        """Get list of audience_segmentss filtered by field"""
        try:
            if not hasattr(Audience_segments, field_name):
                raise ValueError(f"Field {field_name} does not exist on Audience_segments")
            result = await self.db.execute(
                select(Audience_segments)
                .where(getattr(Audience_segments, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Audience_segments.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching audience_segmentss by {field_name}: {str(e)}")
            raise