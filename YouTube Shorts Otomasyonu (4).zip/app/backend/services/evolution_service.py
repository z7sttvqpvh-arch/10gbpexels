"""Evolution Engine - Stage review and transition logic."""
import logging
from datetime import datetime
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.channels import Channels
from models.stage_policies import Stage_policies
from models.channel_stage_histories import Channel_stage_histories

logger = logging.getLogger(__name__)

STAGE_ORDER = ["micro_niche", "adjacent_bridge", "global_expand", "category_domination"]


def get_next_stage(current: str) -> str | None:
    idx = STAGE_ORDER.index(current) if current in STAGE_ORDER else -1
    if idx < len(STAGE_ORDER) - 1:
        return STAGE_ORDER[idx + 1]
    return None


def get_prev_stage(current: str) -> str | None:
    idx = STAGE_ORDER.index(current) if current in STAGE_ORDER else -1
    if idx > 0:
        return STAGE_ORDER[idx - 1]
    return None


async def review_channel(db: AsyncSession, channel_id: int) -> dict:
    """Review a channel against its current stage policy and return recommendation."""
    result = await db.execute(select(Channels).where(Channels.id == channel_id))
    channel = result.scalar_one_or_none()
    if not channel:
        return {"error": "Channel not found"}

    result = await db.execute(
        select(Stage_policies).where(
            Stage_policies.stage == channel.stage,
            Stage_policies.is_active == True,
        )
    )
    policy = result.scalar_one_or_none()
    if not policy:
        return {"error": f"No active policy for stage {channel.stage}"}

    checks = []
    passed = 0
    total = 0

    def check_metric(name, value, threshold, op="gte"):
        nonlocal passed, total
        if threshold is None or value is None:
            return
        total += 1
        if op == "gte":
            ok = value >= threshold
        else:
            ok = value <= threshold
        if ok:
            passed += 1
        checks.append({
            "metric": name,
            "value": round(value, 2) if value else 0,
            "threshold": round(threshold, 2) if threshold else 0,
            "operator": op,
            "passed": ok,
        })

    check_metric("Videos", channel.total_videos or 0, policy.min_videos_to_promote, "gte")
    check_metric("Authority Score", channel.authority_score or 0, policy.min_authority_score, "gte")
    check_metric("Topic Drift", channel.topic_drift_score or 0, policy.max_topic_drift, "lte")
    check_metric("First 3s Hold", channel.first_3s_hold or 0, policy.min_first_3s_hold, "gte")
    check_metric("Avg Watch %", channel.avg_watch_pct or 0, policy.min_avg_watch_pct, "gte")
    check_metric("Rewatch Rate", channel.rewatch_rate or 0, policy.min_rewatch_rate, "gte")

    # Determine recommendation
    pass_rate = passed / total if total > 0 else 0
    recommendation = "stay"
    reasons = []

    if pass_rate >= 0.8:
        next_stage = get_next_stage(channel.stage)
        if next_stage:
            recommendation = "promote"
            reasons.append(f"Channel meets {passed}/{total} criteria for promotion to {next_stage}")
        else:
            recommendation = "stay"
            reasons.append("Channel is at the highest stage (Category Domination)")
    elif pass_rate < 0.4:
        # Check rollback thresholds
        rollback = False
        if policy.rollback_authority_threshold and (channel.authority_score or 0) < policy.rollback_authority_threshold:
            rollback = True
            reasons.append(f"Authority score ({channel.authority_score:.1f}) below rollback threshold ({policy.rollback_authority_threshold})")
        if policy.rollback_drift_threshold and (channel.topic_drift_score or 0) > policy.rollback_drift_threshold:
            rollback = True
            reasons.append(f"Topic drift ({channel.topic_drift_score:.1f}) above rollback threshold ({policy.rollback_drift_threshold})")

        if rollback and get_prev_stage(channel.stage):
            recommendation = "rollback"
        else:
            recommendation = "stay"
            if not reasons:
                reasons.append(f"Only {passed}/{total} criteria met. Needs improvement before promotion.")
    else:
        reasons.append(f"Channel meets {passed}/{total} criteria. Close to promotion threshold.")

    failed_checks = [c for c in checks if not c["passed"]]
    for fc in failed_checks:
        op_str = ">=" if fc["operator"] == "gte" else "<="
        reasons.append(f"{fc['metric']}: {fc['value']} (need {op_str} {fc['threshold']})")

    return {
        "channel_id": channel.id,
        "channel_name": channel.name,
        "current_stage": channel.stage,
        "next_stage": get_next_stage(channel.stage),
        "prev_stage": get_prev_stage(channel.stage),
        "recommendation": recommendation,
        "pass_rate": round(pass_rate * 100, 1),
        "passed": passed,
        "total": total,
        "checks": checks,
        "reasons": reasons,
    }


async def execute_transition(
    db: AsyncSession, channel_id: int, decision: str, reason: str, triggered_by: str = "manual"
) -> dict:
    """Execute a stage transition for a channel."""
    result = await db.execute(select(Channels).where(Channels.id == channel_id))
    channel = result.scalar_one_or_none()
    if not channel:
        return {"error": "Channel not found"}

    current_stage = channel.stage
    if decision == "promote":
        new_stage = get_next_stage(current_stage)
    elif decision == "rollback":
        new_stage = get_prev_stage(current_stage)
    else:
        new_stage = current_stage

    if not new_stage:
        return {"error": f"Cannot {decision} from {current_stage}"}

    # Create history record
    history = Channel_stage_histories(
        channel_id=channel_id,
        from_stage=current_stage,
        to_stage=new_stage,
        decision=decision,
        reason=reason,
        authority_score_at=channel.authority_score,
        topic_drift_at=channel.topic_drift_score,
        subscriber_count_at=channel.subscriber_count,
        total_videos_at=channel.total_videos,
        triggered_by=triggered_by,
        created_at=datetime.now(),
    )
    db.add(history)

    # Update channel stage
    if decision != "stay":
        await db.execute(
            update(Channels)
            .where(Channels.id == channel_id)
            .values(stage=new_stage, updated_at=datetime.now())
        )

    await db.commit()

    return {
        "channel_id": channel_id,
        "from_stage": current_stage,
        "to_stage": new_stage,
        "decision": decision,
        "reason": reason,
    }