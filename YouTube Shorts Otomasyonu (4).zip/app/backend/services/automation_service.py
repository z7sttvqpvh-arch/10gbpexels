"""Automation Engine - Full pipeline orchestration for autonomous operation."""
import logging
import json
from datetime import datetime
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.channels import Channels
from models.niches import Niches
from models.niche_candidates import Niche_candidates
from models.videos import Videos
from models.generation_jobs import Generation_jobs
from models.upload_jobs import Upload_jobs
from models.api_keys import Api_keys
from models.system_settings import System_settings
from services.niche_service import discover_niches, approve_candidate
from services.channel_spawn_service import spawn_channel
from services.content_planning_service import generate_content_plan
from services.generation_pipeline_service import generate_script
from services.video_render_service import generate_render_plan, generate_thumbnail
from services.youtube_service import execute_upload, validate_youtube_credentials
from services.analytics_service import create_snapshot
from services.evolution_service import review_channel, execute_transition
from services.channel_proposal_service import generate_proposals

logger = logging.getLogger(__name__)


async def get_api_key(db: AsyncSession, service_name: str) -> str | None:
    """Get an active API key for a service."""
    result = await db.execute(
        select(Api_keys).where(
            Api_keys.service_name == service_name,
            Api_keys.status == "active",
        )
    )
    key = result.scalar_one_or_none()
    return key.key_value if key else None


async def get_setting(db: AsyncSession, key: str) -> str | None:
    """Get a system setting value."""
    result = await db.execute(
        select(System_settings).where(System_settings.setting_key == key)
    )
    setting = result.scalar_one_or_none()
    return setting.setting_value if setting else None


async def run_full_pipeline(db: AsyncSession, channel_id: int) -> dict:
    """Run the full content generation pipeline for a channel.
    
    Steps:
    1. Generate content plan (video ideas)
    2. Generate scripts for draft videos
    3. Create upload jobs for completed videos
    """
    result = await db.execute(select(Channels).where(Channels.id == channel_id))
    channel = result.scalar_one_or_none()
    if not channel:
        return {"error": "Channel not found"}

    steps_completed = []
    errors = []

    # Step 1: Generate content plan if needed
    draft_count_res = await db.execute(
        select(Videos).where(
            Videos.channel_id == channel_id,
            Videos.status == "draft",
        )
    )
    drafts = draft_count_res.scalars().all()

    if len(drafts) < 3:
        try:
            plan_result = await generate_content_plan(db, channel_id, 5)
            if "error" not in plan_result:
                steps_completed.append(f"Generated {plan_result.get('created', 0)} content ideas")
            else:
                errors.append(f"Content planning: {plan_result['error']}")
        except Exception as e:
            errors.append(f"Content planning failed: {str(e)}")

    # Refresh drafts
    draft_res = await db.execute(
        select(Videos).where(
            Videos.channel_id == channel_id,
            Videos.status == "draft",
        )
    )
    drafts = draft_res.scalars().all()

    # Step 2: Generate scripts for draft videos
    scripts_generated = 0
    for video in drafts[:3]:  # Process up to 3 at a time
        try:
            script_result = await generate_script(db, video.id)
            if "error" not in script_result:
                scripts_generated += 1
            else:
                errors.append(f"Script gen for '{video.title}': {script_result['error']}")
        except Exception as e:
            errors.append(f"Script gen failed for '{video.title}': {str(e)}")

    if scripts_generated > 0:
        steps_completed.append(f"Generated {scripts_generated} scripts")

    # Step 3: Generate render plans for videos with scripts
    generating_res = await db.execute(
        select(Videos).where(
            Videos.channel_id == channel_id,
            Videos.status == "generating",
        )
    )
    generating_videos = generating_res.scalars().all()

    renders_created = 0
    for video in generating_videos[:3]:
        try:
            render_result = await generate_render_plan(db, video.id)
            if "error" not in render_result:
                renders_created += 1
                # Also generate thumbnail
                await generate_thumbnail(db, video.id)
            else:
                errors.append(f"Render for '{video.title}': {render_result['error']}")
        except Exception as e:
            errors.append(f"Render failed for '{video.title}': {str(e)}")

    if renders_created > 0:
        steps_completed.append(f"Generated {renders_created} render plans + thumbnails")

    # Step 4: Create upload jobs for rendered videos
    rendered_res = await db.execute(
        select(Videos).where(
            Videos.channel_id == channel_id,
            Videos.status.in_(["rendered", "uploaded"]),
        )
    )
    rendered_videos = rendered_res.scalars().all()

    uploads_created = 0
    for video in rendered_videos:
        # Check if upload job already exists
        existing = await db.execute(
            select(Upload_jobs).where(
                Upload_jobs.video_id == video.id,
                Upload_jobs.status.in_(["pending", "running", "completed"]),
            )
        )
        if existing.scalar_one_or_none():
            continue

        upload_job = Upload_jobs(
            channel_id=channel_id,
            video_id=video.id,
            status="pending",
            priority=5,
            upload_attempts=0,
            max_attempts=3,
            scheduled_at=datetime.now(),
            created_at=datetime.now(),
        )
        db.add(upload_job)
        uploads_created += 1

    if uploads_created > 0:
        await db.commit()
        steps_completed.append(f"Created {uploads_created} upload jobs")

    # Step 5: Execute pending upload jobs (if YouTube credentials are ready)
    yt_status = await validate_youtube_credentials(db)
    if yt_status["ready"]:
        pending_uploads = await db.execute(
            select(Upload_jobs).where(
                Upload_jobs.channel_id == channel_id,
                Upload_jobs.status == "pending",
            ).limit(3)
        )
        pending_jobs = pending_uploads.scalars().all()
        uploads_executed = 0
        for uj in pending_jobs:
            try:
                upload_result = await execute_upload(db, uj.id)
                if "error" not in upload_result:
                    uploads_executed += 1
            except Exception as e:
                errors.append(f"Upload job #{uj.id}: {str(e)}")
        if uploads_executed > 0:
            steps_completed.append(f"Executed {uploads_executed} YouTube uploads")
    else:
        steps_completed.append(f"YouTube: {yt_status['message']}")

    # Step 6: Create analytics snapshot
    try:
        snap_result = await create_snapshot(db, channel_id, 7)
        if "error" not in snap_result:
            steps_completed.append("Analytics snapshot created")
    except Exception as e:
        errors.append(f"Analytics: {str(e)}")

    # Step 7: Evolution review
    try:
        review = await review_channel(db, channel_id)
        if "error" not in review:
            steps_completed.append(f"Evolution review: {review.get('recommendation', 'N/A')} ({review.get('pass_rate', 0)}%)")
            # Auto-promote if recommendation is promote
            if review.get("recommendation") == "promote":
                exec_result = await execute_transition(
                    db, channel_id, "promote",
                    f"Auto-promoted: {review.get('pass_rate')}% criteria met",
                    "automation"
                )
                if "error" not in exec_result:
                    steps_completed.append(f"Auto-promoted to {exec_result.get('to_stage')}")
    except Exception as e:
        errors.append(f"Evolution: {str(e)}")

    return {
        "channel_id": channel_id,
        "channel_name": channel.name,
        "steps_completed": steps_completed,
        "errors": errors,
        "status": "completed" if not errors else "completed_with_errors",
    }


async def run_auto_discovery(db: AsyncSession, categories: list[str] | None = None) -> dict:
    """Run automatic niche discovery across categories."""
    if not categories:
        categories = ["Technology", "Science", "Education", "Entertainment", "Health & Fitness"]

    total_discovered = 0
    results = []

    for category in categories:
        try:
            result = await discover_niches(db, category, 3)
            if "error" not in result:
                total_discovered += result.get("created", 0)
                results.append({"category": category, "discovered": result.get("created", 0)})
            else:
                results.append({"category": category, "error": result["error"]})
        except Exception as e:
            results.append({"category": category, "error": str(e)})

    return {"total_discovered": total_discovered, "results": results}


async def run_auto_approve(db: AsyncSession, min_score: float = 65.0) -> dict:
    """Auto-approve niche candidates above a minimum score threshold."""
    result = await db.execute(
        select(Niche_candidates).where(
            Niche_candidates.status == "pending",
            Niche_candidates.total_score >= min_score,
        )
    )
    candidates = result.scalars().all()

    approved = []
    errors = []
    for c in candidates:
        try:
            res = await approve_candidate(db, c.id)
            if "error" not in res:
                approved.append(c.niche_name)
            else:
                errors.append(f"{c.niche_name}: {res['error']}")
        except Exception as e:
            errors.append(f"{c.niche_name}: {str(e)}")

    return {"approved": len(approved), "names": approved, "errors": errors}


async def run_auto_spawn(db: AsyncSession) -> dict:
    """Generate channel proposals for approved niches (requires user approval to create)."""
    try:
        result = await generate_proposals(db)
        return {
            "spawned": 0,
            "proposals_created": result.get("created", 0),
            "names": result.get("names", []),
            "errors": [],
            "message": f"{result.get('created', 0)} kanal önerisi oluşturuldu. Onayınız bekleniyor.",
        }
    except Exception as e:
        return {"spawned": 0, "proposals_created": 0, "names": [], "errors": [str(e)]}


async def run_full_automation(db: AsyncSession) -> dict:
    """Run the complete automation cycle:
    1. Discover niches
    2. Auto-approve high-scoring candidates
    3. Auto-spawn channels for approved niches
    4. Run full pipeline for all active channels
    """
    results = {
        "started_at": datetime.now().isoformat(),
        "steps": [],
        "errors": [],
    }

    # Step 1: Niche Discovery
    try:
        discovery = await run_auto_discovery(db)
        results["steps"].append({
            "step": "niche_discovery",
            "total_discovered": discovery.get("total_discovered", 0),
            "details": discovery.get("results", []),
        })
    except Exception as e:
        results["errors"].append(f"Discovery: {str(e)}")

    # Step 2: Auto-approve
    try:
        approval = await run_auto_approve(db)
        results["steps"].append({
            "step": "auto_approve",
            "approved": approval.get("approved", 0),
            "names": approval.get("names", []),
        })
    except Exception as e:
        results["errors"].append(f"Auto-approve: {str(e)}")

    # Step 3: Auto-spawn
    try:
        spawn = await run_auto_spawn(db)
        results["steps"].append({
            "step": "auto_spawn",
            "spawned": spawn.get("spawned", 0),
            "names": spawn.get("names", []),
        })
    except Exception as e:
        results["errors"].append(f"Auto-spawn: {str(e)}")

    # Step 4: Run pipeline for all active channels
    ch_res = await db.execute(
        select(Channels).where(
            Channels.status.in_(["active", "incubating"])
        )
    )
    active_channels = ch_res.scalars().all()

    pipeline_results = []
    for ch in active_channels:
        try:
            pipe = await run_full_pipeline(db, ch.id)
            pipeline_results.append({
                "channel": ch.name,
                "steps": pipe.get("steps_completed", []),
                "errors": pipe.get("errors", []),
            })
        except Exception as e:
            pipeline_results.append({
                "channel": ch.name,
                "error": str(e),
            })

    results["steps"].append({
        "step": "pipeline",
        "channels_processed": len(active_channels),
        "details": pipeline_results,
    })

    results["finished_at"] = datetime.now().isoformat()
    results["status"] = "completed" if not results["errors"] else "completed_with_errors"

    return results