"""Generation Pipeline - Script/hook/title/description AI generation."""
import logging
import json
from datetime import datetime
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.videos import Videos
from models.channels import Channels
from models.generation_jobs import Generation_jobs
from services.aihub import AIHubService
from schemas.aihub import GenTxtRequest, ChatMessage

logger = logging.getLogger(__name__)

ai_service = AIHubService()


async def generate_script(db: AsyncSession, video_id: int) -> dict:
    """Generate a full script for a video using AI."""
    result = await db.execute(select(Videos).where(Videos.id == video_id))
    video = result.scalar_one_or_none()
    if not video:
        return {"error": "Video not found"}

    # Create generation job
    job = Generation_jobs(
        channel_id=video.channel_id,
        video_id=video_id,
        job_type="script_gen",
        status="running",
        priority=5,
        input_data=json.dumps({"title": video.title, "hook": video.hook_text}),
        retry_count=0,
        max_retries=3,
        started_at=datetime.now(),
        created_at=datetime.now(),
    )
    db.add(job)
    await db.flush()

    try:
        prompt = f"""Write a YouTube Shorts script (30-60 seconds) for this video:

Title: {video.title}
Hook: {video.hook_text}
Content Type: {video.content_type}
Content Pillar: {video.content_pillar}
Description: {video.description}

Format the script with:
1. HOOK (0-3s): Opening hook to grab attention
2. SETUP (3-10s): Context and setup
3. MAIN (10-40s): Core content delivery
4. CTA (40-50s): Call to action
5. OUTRO (50-60s): Closing

Return the full script text only, no JSON."""

        request = GenTxtRequest(
            messages=[
                ChatMessage(role="system", content="You are a YouTube Shorts scriptwriter. Write engaging, fast-paced scripts."),
                ChatMessage(role="user", content=prompt),
            ],
            model="deepseek-v3.2",
        )

        response = await ai_service.gentxt(request)
        script = response.content.strip()

        # Update video with script
        await db.execute(
            update(Videos)
            .where(Videos.id == video_id)
            .values(script_text=script, status="generating", updated_at=datetime.now())
        )

        # Update job as completed
        job.status = "completed"
        job.output_data = json.dumps({"script_length": len(script)})
        job.finished_at = datetime.now()

        await db.commit()
        return {"video_id": video_id, "job_id": job.id, "status": "completed", "script_preview": script[:200]}

    except Exception as e:
        job.status = "failed"
        job.error_message = str(e)
        job.finished_at = datetime.now()
        await db.commit()
        return {"error": str(e), "job_id": job.id}


async def generate_hooks(db: AsyncSession, video_id: int, count: int = 3) -> dict:
    """Generate alternative hooks for a video."""
    result = await db.execute(select(Videos).where(Videos.id == video_id))
    video = result.scalar_one_or_none()
    if not video:
        return {"error": "Video not found"}

    prompt = f"""Generate {count} alternative hook options for this YouTube Shorts video:

Title: {video.title}
Current Hook: {video.hook_text}
Content Type: {video.content_type}

Each hook should be different in style (question, shocking fact, visual description, etc.)
Return ONLY a JSON array of strings. No markdown."""

    request = GenTxtRequest(
        messages=[
            ChatMessage(role="system", content="You are a YouTube Shorts hook expert. Return only valid JSON."),
            ChatMessage(role="user", content=prompt),
        ],
        model="deepseek-v3.2",
    )

    response = await ai_service.gentxt(request)
    content = response.content.strip()
    if content.startswith("```"):
        content = content.split("\n", 1)[1].rsplit("```", 1)[0]

    try:
        hooks = json.loads(content)
    except json.JSONDecodeError:
        hooks = [content]

    return {"video_id": video_id, "hooks": hooks}