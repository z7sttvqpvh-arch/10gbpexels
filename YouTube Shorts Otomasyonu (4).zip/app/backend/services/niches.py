import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.niches import Niches

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class NichesService:
    """Service layer for Niches operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Niches]:
        """Create a new niches"""
        try:
            obj = Niches(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created niches with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating niches: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Niches]:
        """Get niches by ID"""
        try:
            query = select(Niches).where(Niches.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching niches {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of nichess"""
        try:
            query = select(Niches)
            count_query = select(func.count(Niches.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Niches, field):
                        query = query.where(getattr(Niches, field) == value)
                        count_query = count_query.where(getattr(Niches, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Niches, field_name):
                        query = query.order_by(getattr(Niches, field_name).desc())
                else:
                    if hasattr(Niches, sort):
                        query = query.order_by(getattr(Niches, sort))
            else:
                query = query.order_by(Niches.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching niches list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Niches]:
        """Update niches"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Niches {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated niches {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating niches {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete niches"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Niches {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted niches {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting niches {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Niches]:
        """Get niches by any field"""
        try:
            if not hasattr(Niches, field_name):
                raise ValueError(f"Field {field_name} does not exist on Niches")
            result = await self.db.execute(
                select(Niches).where(getattr(Niches, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching niches by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Niches]:
        """Get list of nichess filtered by field"""
        try:
            if not hasattr(Niches, field_name):
                raise ValueError(f"Field {field_name} does not exist on Niches")
            result = await self.db.execute(
                select(Niches)
                .where(getattr(Niches, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Niches.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching nichess by {field_name}: {str(e)}")
            raise