import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.channel_stage_histories import Channel_stage_histories

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Channel_stage_historiesService:
    """Service layer for Channel_stage_histories operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Channel_stage_histories]:
        """Create a new channel_stage_histories"""
        try:
            obj = Channel_stage_histories(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created channel_stage_histories with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating channel_stage_histories: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Channel_stage_histories]:
        """Get channel_stage_histories by ID"""
        try:
            query = select(Channel_stage_histories).where(Channel_stage_histories.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching channel_stage_histories {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of channel_stage_historiess"""
        try:
            query = select(Channel_stage_histories)
            count_query = select(func.count(Channel_stage_histories.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Channel_stage_histories, field):
                        query = query.where(getattr(Channel_stage_histories, field) == value)
                        count_query = count_query.where(getattr(Channel_stage_histories, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Channel_stage_histories, field_name):
                        query = query.order_by(getattr(Channel_stage_histories, field_name).desc())
                else:
                    if hasattr(Channel_stage_histories, sort):
                        query = query.order_by(getattr(Channel_stage_histories, sort))
            else:
                query = query.order_by(Channel_stage_histories.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching channel_stage_histories list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Channel_stage_histories]:
        """Update channel_stage_histories"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Channel_stage_histories {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated channel_stage_histories {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating channel_stage_histories {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete channel_stage_histories"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Channel_stage_histories {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted channel_stage_histories {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting channel_stage_histories {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Channel_stage_histories]:
        """Get channel_stage_histories by any field"""
        try:
            if not hasattr(Channel_stage_histories, field_name):
                raise ValueError(f"Field {field_name} does not exist on Channel_stage_histories")
            result = await self.db.execute(
                select(Channel_stage_histories).where(getattr(Channel_stage_histories, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching channel_stage_histories by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Channel_stage_histories]:
        """Get list of channel_stage_historiess filtered by field"""
        try:
            if not hasattr(Channel_stage_histories, field_name):
                raise ValueError(f"Field {field_name} does not exist on Channel_stage_histories")
            result = await self.db.execute(
                select(Channel_stage_histories)
                .where(getattr(Channel_stage_histories, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Channel_stage_histories.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching channel_stage_historiess by {field_name}: {str(e)}")
            raise