import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.stage_policies import Stage_policies

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Stage_policiesService:
    """Service layer for Stage_policies operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Stage_policies]:
        """Create a new stage_policies"""
        try:
            obj = Stage_policies(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created stage_policies with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating stage_policies: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Stage_policies]:
        """Get stage_policies by ID"""
        try:
            query = select(Stage_policies).where(Stage_policies.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching stage_policies {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of stage_policiess"""
        try:
            query = select(Stage_policies)
            count_query = select(func.count(Stage_policies.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Stage_policies, field):
                        query = query.where(getattr(Stage_policies, field) == value)
                        count_query = count_query.where(getattr(Stage_policies, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Stage_policies, field_name):
                        query = query.order_by(getattr(Stage_policies, field_name).desc())
                else:
                    if hasattr(Stage_policies, sort):
                        query = query.order_by(getattr(Stage_policies, sort))
            else:
                query = query.order_by(Stage_policies.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching stage_policies list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Stage_policies]:
        """Update stage_policies"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Stage_policies {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated stage_policies {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating stage_policies {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete stage_policies"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Stage_policies {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted stage_policies {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting stage_policies {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Stage_policies]:
        """Get stage_policies by any field"""
        try:
            if not hasattr(Stage_policies, field_name):
                raise ValueError(f"Field {field_name} does not exist on Stage_policies")
            result = await self.db.execute(
                select(Stage_policies).where(getattr(Stage_policies, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching stage_policies by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Stage_policies]:
        """Get list of stage_policiess filtered by field"""
        try:
            if not hasattr(Stage_policies, field_name):
                raise ValueError(f"Field {field_name} does not exist on Stage_policies")
            result = await self.db.execute(
                select(Stage_policies)
                .where(getattr(Stage_policies, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Stage_policies.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching stage_policiess by {field_name}: {str(e)}")
            raise