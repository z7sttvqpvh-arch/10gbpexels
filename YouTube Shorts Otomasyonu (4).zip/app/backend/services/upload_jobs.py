import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.upload_jobs import Upload_jobs

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Upload_jobsService:
    """Service layer for Upload_jobs operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Upload_jobs]:
        """Create a new upload_jobs"""
        try:
            obj = Upload_jobs(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created upload_jobs with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating upload_jobs: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Upload_jobs]:
        """Get upload_jobs by ID"""
        try:
            query = select(Upload_jobs).where(Upload_jobs.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching upload_jobs {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of upload_jobss"""
        try:
            query = select(Upload_jobs)
            count_query = select(func.count(Upload_jobs.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Upload_jobs, field):
                        query = query.where(getattr(Upload_jobs, field) == value)
                        count_query = count_query.where(getattr(Upload_jobs, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Upload_jobs, field_name):
                        query = query.order_by(getattr(Upload_jobs, field_name).desc())
                else:
                    if hasattr(Upload_jobs, sort):
                        query = query.order_by(getattr(Upload_jobs, sort))
            else:
                query = query.order_by(Upload_jobs.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching upload_jobs list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Upload_jobs]:
        """Update upload_jobs"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Upload_jobs {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated upload_jobs {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating upload_jobs {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete upload_jobs"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Upload_jobs {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted upload_jobs {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting upload_jobs {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Upload_jobs]:
        """Get upload_jobs by any field"""
        try:
            if not hasattr(Upload_jobs, field_name):
                raise ValueError(f"Field {field_name} does not exist on Upload_jobs")
            result = await self.db.execute(
                select(Upload_jobs).where(getattr(Upload_jobs, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching upload_jobs by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Upload_jobs]:
        """Get list of upload_jobss filtered by field"""
        try:
            if not hasattr(Upload_jobs, field_name):
                raise ValueError(f"Field {field_name} does not exist on Upload_jobs")
            result = await self.db.execute(
                select(Upload_jobs)
                .where(getattr(Upload_jobs, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Upload_jobs.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching upload_jobss by {field_name}: {str(e)}")
            raise