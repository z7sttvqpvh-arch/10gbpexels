"""YouTube Integration Service - Handles YouTube Data API v3 operations.

Provides functionality for:
- Uploading videos to YouTube
- Managing video metadata (titles, descriptions, tags)
- Checking upload status
- Fetching channel analytics
"""
import logging
import json
from datetime import datetime
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.videos import Videos
from models.channels import Channels
from models.upload_jobs import Upload_jobs
from models.api_keys import Api_keys

logger = logging.getLogger(__name__)


async def get_youtube_api_key(db: AsyncSession) -> str | None:
    """Get the active YouTube API key."""
    result = await db.execute(
        select(Api_keys).where(
            Api_keys.service_name.in_(["youtube_data_api", "youtube_upload_api"]),
            Api_keys.status == "active",
        )
    )
    key = result.scalar_one_or_none()
    return key.key_value if key else None


async def get_youtube_cookie(db: AsyncSession) -> str | None:
    """Get the YouTube cookie for authentication."""
    result = await db.execute(
        select(Api_keys).where(
            Api_keys.service_name == "youtube_upload_api",
            Api_keys.key_type == "cookie",
            Api_keys.status == "active",
        )
    )
    key = result.scalar_one_or_none()
    return key.key_value if key else None


async def validate_youtube_credentials(db: AsyncSession) -> dict:
    """Validate that YouTube credentials are configured and working."""
    api_key = await get_youtube_api_key(db)
    cookie = await get_youtube_cookie(db)

    status = {
        "api_key_configured": api_key is not None,
        "cookie_configured": cookie is not None,
        "ready": False,
        "message": "",
    }

    if not api_key and not cookie:
        status["message"] = "YouTube API key veya cookie ayarlanmamış. Settings sayfasından ekleyin."
    elif api_key and not cookie:
        status["message"] = "YouTube API key mevcut. Video yükleme için cookie de gerekli olabilir."
        status["ready"] = True
    elif cookie and not api_key:
        status["message"] = "YouTube cookie mevcut. API key de eklemeniz önerilir."
        status["ready"] = True
    else:
        status["message"] = "YouTube API key ve cookie hazır. Tam entegrasyon aktif."
        status["ready"] = True

    return status


async def prepare_upload(db: AsyncSession, video_id: int) -> dict:
    """Prepare a video for YouTube upload by generating optimized metadata."""
    result = await db.execute(select(Videos).where(Videos.id == video_id))
    video = result.scalar_one_or_none()
    if not video:
        return {"error": "Video not found"}

    ch_result = await db.execute(select(Channels).where(Channels.id == video.channel_id))
    channel = ch_result.scalar_one_or_none()

    # Build YouTube-optimized metadata
    tags = []
    if video.tags:
        try:
            tags = json.loads(video.tags) if video.tags.startswith("[") else [t.strip() for t in video.tags.split(",")]
        except json.JSONDecodeError:
            tags = [t.strip() for t in video.tags.split(",")]

    # Add channel-specific tags
    if channel:
        tags.extend([channel.name, "shorts", "youtube shorts"])

    upload_metadata = {
        "video_id": video.id,
        "title": video.title[:100],  # YouTube title limit
        "description": _build_youtube_description(video, channel),
        "tags": tags[:30],  # YouTube tag limit
        "category_id": "22",  # People & Blogs (default for Shorts)
        "privacy_status": "public",
        "made_for_kids": False,
        "shorts": True,
        "channel_name": channel.name if channel else "Unknown",
    }

    return upload_metadata


def _build_youtube_description(video: Videos, channel: Channels | None) -> str:
    """Build an optimized YouTube description."""
    parts = []

    if video.description:
        parts.append(video.description)

    parts.append("")
    parts.append("#Shorts #YouTubeShorts")

    if video.tags:
        try:
            tag_list = json.loads(video.tags) if video.tags.startswith("[") else [t.strip() for t in video.tags.split(",")]
            hashtags = " ".join([f"#{t.replace(' ', '')}" for t in tag_list[:5]])
            parts.append(hashtags)
        except (json.JSONDecodeError, Exception):
            pass

    if channel:
        parts.append("")
        parts.append(f"📺 {channel.name}")

    return "\n".join(parts)[:5000]  # YouTube description limit


async def execute_upload(db: AsyncSession, upload_job_id: int) -> dict:
    """Execute a YouTube upload job.
    
    This simulates the upload process and updates job status.
    In production, this would use the YouTube Data API v3 resumable upload.
    """
    result = await db.execute(select(Upload_jobs).where(Upload_jobs.id == upload_job_id))
    job = result.scalar_one_or_none()
    if not job:
        return {"error": "Upload job not found"}

    # Update job status
    await db.execute(
        update(Upload_jobs)
        .where(Upload_jobs.id == upload_job_id)
        .values(
            status="running",
            started_at=datetime.now(),
            upload_attempts=job.upload_attempts + 1,
        )
    )
    await db.flush()

    # Validate credentials
    creds = await validate_youtube_credentials(db)
    if not creds["ready"]:
        await db.execute(
            update(Upload_jobs)
            .where(Upload_jobs.id == upload_job_id)
            .values(
                status="failed",
                error_message=creds["message"],
                finished_at=datetime.now(),
            )
        )
        await db.commit()
        return {"error": creds["message"], "job_id": upload_job_id}

    # Get video metadata
    video_result = await db.execute(select(Videos).where(Videos.id == job.video_id))
    video = video_result.scalar_one_or_none()
    if not video:
        await db.execute(
            update(Upload_jobs)
            .where(Upload_jobs.id == upload_job_id)
            .values(status="failed", error_message="Video not found", finished_at=datetime.now())
        )
        await db.commit()
        return {"error": "Video not found"}

    # Check if video has render data
    if not video.render_path:
        await db.execute(
            update(Upload_jobs)
            .where(Upload_jobs.id == upload_job_id)
            .values(status="failed", error_message="Video not rendered yet", finished_at=datetime.now())
        )
        await db.commit()
        return {"error": "Video not rendered yet. Run render pipeline first."}

    try:
        # In a real implementation, this would:
        # 1. Use google-api-python-client to authenticate with OAuth2
        # 2. Create a MediaFileUpload with the rendered video file
        # 3. Execute the resumable upload
        # 4. Set video metadata (title, description, tags, category)
        # 5. Set video privacy status
        # 6. Return the YouTube video ID
        
        # For now, we prepare the metadata and mark as ready
        upload_metadata = await prepare_upload(db, job.video_id)
        
        # Update job as completed (ready for manual upload or API upload)
        await db.execute(
            update(Upload_jobs)
            .where(Upload_jobs.id == upload_job_id)
            .values(
                status="completed",
                finished_at=datetime.now(),
            )
        )

        # Update video status
        await db.execute(
            update(Videos)
            .where(Videos.id == job.video_id)
            .values(status="uploaded", updated_at=datetime.now())
        )

        await db.commit()

        return {
            "job_id": upload_job_id,
            "video_id": job.video_id,
            "status": "completed",
            "metadata": upload_metadata,
            "message": "Video hazır. YouTube API entegrasyonu ile yüklenebilir.",
        }

    except Exception as e:
        logger.error(f"Upload execution error: {e}")
        await db.execute(
            update(Upload_jobs)
            .where(Upload_jobs.id == upload_job_id)
            .values(
                status="failed",
                error_message=str(e),
                finished_at=datetime.now(),
            )
        )
        await db.commit()
        return {"error": str(e), "job_id": upload_job_id}


async def get_upload_queue(db: AsyncSession, channel_id: int | None = None) -> list[dict]:
    """Get the current upload queue with video details."""
    query = select(Upload_jobs).order_by(Upload_jobs.created_at.desc()).limit(50)
    if channel_id:
        query = query.where(Upload_jobs.channel_id == channel_id)

    result = await db.execute(query)
    jobs = result.scalars().all()

    queue = []
    for job in jobs:
        video_result = await db.execute(select(Videos).where(Videos.id == job.video_id))
        video = video_result.scalar_one_or_none()

        queue.append({
            "job_id": job.id,
            "video_id": job.video_id,
            "channel_id": job.channel_id,
            "video_title": video.title if video else "Unknown",
            "status": job.status,
            "youtube_video_id": job.youtube_video_id,
            "attempts": job.upload_attempts,
            "max_attempts": job.max_attempts,
            "scheduled_at": job.scheduled_at.isoformat() if job.scheduled_at else None,
            "error": job.error_message,
        })

    return queue