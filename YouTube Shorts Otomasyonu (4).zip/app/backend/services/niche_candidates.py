import logging
from typing import Optional, Dict, Any, List

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.niche_candidates import Niche_candidates

logger = logging.getLogger(__name__)


# ------------------ Service Layer ------------------
class Niche_candidatesService:
    """Service layer for Niche_candidates operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any]) -> Optional[Niche_candidates]:
        """Create a new niche_candidates"""
        try:
            obj = Niche_candidates(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created niche_candidates with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating niche_candidates: {str(e)}")
            raise

    async def get_by_id(self, obj_id: int) -> Optional[Niche_candidates]:
        """Get niche_candidates by ID"""
        try:
            query = select(Niche_candidates).where(Niche_candidates.id == obj_id)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching niche_candidates {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get paginated list of niche_candidatess"""
        try:
            query = select(Niche_candidates)
            count_query = select(func.count(Niche_candidates.id))
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Niche_candidates, field):
                        query = query.where(getattr(Niche_candidates, field) == value)
                        count_query = count_query.where(getattr(Niche_candidates, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Niche_candidates, field_name):
                        query = query.order_by(getattr(Niche_candidates, field_name).desc())
                else:
                    if hasattr(Niche_candidates, sort):
                        query = query.order_by(getattr(Niche_candidates, sort))
            else:
                query = query.order_by(Niche_candidates.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching niche_candidates list: {str(e)}")
            raise

    async def update(self, obj_id: int, update_data: Dict[str, Any]) -> Optional[Niche_candidates]:
        """Update niche_candidates"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Niche_candidates {obj_id} not found for update")
                return None
            for key, value in update_data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated niche_candidates {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating niche_candidates {obj_id}: {str(e)}")
            raise

    async def delete(self, obj_id: int) -> bool:
        """Delete niche_candidates"""
        try:
            obj = await self.get_by_id(obj_id)
            if not obj:
                logger.warning(f"Niche_candidates {obj_id} not found for deletion")
                return False
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted niche_candidates {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting niche_candidates {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Niche_candidates]:
        """Get niche_candidates by any field"""
        try:
            if not hasattr(Niche_candidates, field_name):
                raise ValueError(f"Field {field_name} does not exist on Niche_candidates")
            result = await self.db.execute(
                select(Niche_candidates).where(getattr(Niche_candidates, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching niche_candidates by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Niche_candidates]:
        """Get list of niche_candidatess filtered by field"""
        try:
            if not hasattr(Niche_candidates, field_name):
                raise ValueError(f"Field {field_name} does not exist on Niche_candidates")
            result = await self.db.execute(
                select(Niche_candidates)
                .where(getattr(Niche_candidates, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Niche_candidates.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching niche_candidatess by {field_name}: {str(e)}")
            raise