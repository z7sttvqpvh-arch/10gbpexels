"""Content Planning - AI-powered stage-aware content plan generation with 2026 algorithm strategies."""
import logging
import json
from datetime import datetime
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from models.channels import Channels
from models.niches import Niches
from models.strategy_snapshots import Strategy_snapshots
from models.videos import Videos
from services.aihub import AIHubService
from schemas.aihub import GenTxtRequest, ChatMessage

logger = logging.getLogger(__name__)

ai_service = AIHubService()

# YouTube Shorts 2026 Strategy Knowledge Base (derived from video transcript analysis)
STRATEGY_KNOWLEDGE = """
## YouTube Shorts 2026 Algorithm Strategy Rules

### CRITICAL: 3-Second Hook Rule
- 70% of viewers swipe within 2-3 seconds if the hook fails
- The video NEVER reaches FYP if the first test fails
- Use questions, shocking facts, or curiosity-driven openings
- The hook text MUST align with the title and description

### CRITICAL: 3 Distribution Waves
- Wave 1 (100-500 viewers): First 3s retention must be ≥30%
- Wave 2 (1K-10K viewers): Like rate ≥4%, comment rate ≥0.5%
- Wave 3 (10K+ viewers): Share rate ≥1%, subscribe conversion ≥0.5%
- Failing any wave stops further distribution

### CRITICAL: Metadata Synchronization
- Title must contain the main keyword
- Description must repeat the keyword 2-3 times
- Tags must have 5 keyword variations
- First 3 seconds of video must SAY the keyword
- YouTube now analyzes subtitles and transcripts for topic verification

### HIGH: Niche Consistency
- Random topic switching confuses the algorithm
- YouTube can't determine who to recommend the content to
- Stay focused on one niche per channel
- Start new channels with 3-4 videos targeting the same audience

### HIGH: Quality Over Quantity (2026)
- YouTube no longer prioritizes upload frequency
- Viewer response is what matters, not consistency alone
- Poor-performing old videos negatively affect new video distribution
- One quality video beats five mediocre ones

### HIGH: Originality
- YouTube is against unoriginal content, not AI content
- Own voice + AI visuals = high originality score
- Strong editing + sound effects + background music = original
- Pure AI TTS channels get low RPM

### HIGH: Custom Thumbnails for Shorts
- Shorts now appear on homepage, search, and Google
- Custom cover photos with big text, arrows, emojis
- Design to trigger curiosity and clicks
- Directly impacts CTR

### MEDIUM: Video Duration
- Keep under 30 seconds for higher completion rate
- Completion rate is a top algorithm metric
- Short = higher rewatch rate
- Don't pad content unnecessarily

### MEDIUM: Viral Formats
- ASMR-style cutting/slicing videos get millions of views
- Satisfying content: cleaning, organizing, transformation
- Follow trends but add original touch
- AI can generate ASMR visuals (Sora, Kling, Gemini)

### MEDIUM: CTA & Engagement
- End with clear Call to Action
- Encourage likes, comments, subscriptions
- Reply to comments to build community
- Engagement rate is a key algorithm signal
"""


async def generate_content_plan(db: AsyncSession, channel_id: int, count: int = 5) -> dict:
    """Generate a content plan for a channel based on its stage, strategy, and 2026 algorithm rules."""
    result = await db.execute(select(Channels).where(Channels.id == channel_id))
    channel = result.scalar_one_or_none()
    if not channel:
        return {"error": "Channel not found"}

    # Get niche
    niche_name = "general"
    if channel.core_niche_id:
        niche_res = await db.execute(select(Niches).where(Niches.id == channel.core_niche_id))
        niche = niche_res.scalar_one_or_none()
        if niche:
            niche_name = niche.name

    # Get current strategy
    strategy = None
    if channel.current_strategy_id:
        strat_res = await db.execute(select(Strategy_snapshots).where(Strategy_snapshots.id == channel.current_strategy_id))
        strategy = strat_res.scalar_one_or_none()

    content_mix = strategy.content_mix if strategy else "core:80,adjacent:15,trend:5"
    hook_families = strategy.hook_families if strategy else "question,shocking_fact,curiosity"
    title_families = strategy.title_families if strategy else "how_to,listicle,challenge"

    prompt = f"""You are an expert YouTube Shorts content strategist for 2026. Create {count} video ideas for a channel.

{STRATEGY_KNOWLEDGE}

Channel: {channel.name}
Stage: {channel.stage}
Niche: {niche_name}
Content Mode: {channel.content_mode}
Content Mix: {content_mix}
Hook Families: {hook_families}
Title Families: {title_families}

IMPORTANT RULES FOR EACH VIDEO:
1. hook_text MUST be powerful enough to stop scrolling in 3 seconds
2. title MUST contain the main keyword for the niche
3. description MUST repeat the main keyword 2-3 times naturally
4. tags MUST include 5+ keyword variations
5. script_outline MUST start with the hook and end with a CTA
6. Target video duration: 15-30 seconds (short and impactful)
7. Each video should maintain niche consistency

For each video, provide:
- title: Catchy YouTube Shorts title with keyword (max 60 chars)
- hook_text: First 3 seconds hook text (must stop the scroll!)
- description: YouTube description with keyword repeated 2-3x (2-3 sentences)
- tags: Comma-separated tags with 5+ keyword variations
- content_pillar: core, adjacent, or trend
- content_type: tutorial, fact, story, comparison, challenge, transformation, asmr, satisfying
- script_outline: Brief 5-point script outline (hook → content → CTA)
- target_duration: Recommended duration in seconds (15-30)
- thumbnail_concept: Brief description of ideal thumbnail/cover image

Return ONLY a JSON array. No markdown."""

    request = GenTxtRequest(
        messages=[
            ChatMessage(role="system", content="You are a YouTube Shorts content strategist specialized in 2026 algorithm optimization. Return only valid JSON."),
            ChatMessage(role="user", content=prompt),
        ],
        model="deepseek-v3.2",
    )

    response = await ai_service.gentxt(request)
    content = response.content.strip()
    if content.startswith("```"):
        content = content.split("\n", 1)[1].rsplit("```", 1)[0]

    try:
        plans = json.loads(content)
    except json.JSONDecodeError:
        return {"error": "Failed to parse AI response", "raw": content}

    created_videos = []
    for p in plans:
        video = Videos(
            channel_id=channel_id,
            title=p.get("title", "Untitled"),
            description=p.get("description", ""),
            tags=p.get("tags", ""),
            hook_text=p.get("hook_text", ""),
            script_text=p.get("script_outline", ""),
            content_pillar=p.get("content_pillar", "core"),
            content_type=p.get("content_type", "tutorial"),
            status="draft",
            duration_seconds=p.get("target_duration", 25),
            views=0,
            likes=0,
            comments_count=0,
            first_3s_hold=0,
            avg_watch_pct=0,
            rewatch_rate=0,
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        db.add(video)
        created_videos.append({
            "title": p.get("title", "Untitled"),
            "hook": p.get("hook_text", ""),
            "type": p.get("content_type", "tutorial"),
            "duration": p.get("target_duration", 25),
            "thumbnail_concept": p.get("thumbnail_concept", ""),
        })

    await db.commit()
    return {"channel_id": channel_id, "created": len(created_videos), "videos": created_videos}