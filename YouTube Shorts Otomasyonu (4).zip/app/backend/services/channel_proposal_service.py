"""Channel Proposal Service - Manages channel creation proposals with user approval flow.

Flow:
1. System discovers niches and generates channel proposals (status=pending)
2. User reviews proposals and approves/rejects them
3. On approval: creates channel in DB + attempts YouTube channel creation via cookie
4. Approved channels with auto_content_enabled get automatic content pipeline
"""
import logging
import json
from datetime import datetime
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.channel_proposals import Channel_proposals
from models.channels import Channels
from models.niches import Niches
from models.api_keys import Api_keys
from services.channel_spawn_service import spawn_channel

logger = logging.getLogger(__name__)


async def generate_proposals(db: AsyncSession) -> dict:
    """Generate channel proposals for approved niches that don't have channels or proposals yet."""
    # Get active niches
    niche_res = await db.execute(select(Niches).where(Niches.status == "active"))
    niches = niche_res.scalars().all()

    # Get existing channels' niche IDs
    ch_res = await db.execute(select(Channels))
    channels = ch_res.scalars().all()
    used_niche_ids = {ch.core_niche_id for ch in channels}

    # Get existing proposals' niche IDs (pending or approved)
    prop_res = await db.execute(
        select(Channel_proposals).where(
            Channel_proposals.status.in_(["pending", "approved", "created"])
        )
    )
    proposals = prop_res.scalars().all()
    proposed_niche_ids = {p.niche_id for p in proposals}

    created = []
    for niche in niches:
        if niche.id in used_niche_ids or niche.id in proposed_niche_ids:
            continue

        slug = (niche.slug or niche.name.lower().replace(" ", "-"))
        proposed_name = niche.name.replace("-", " ").title() + " Shorts"
        proposed_slug = slug + "-shorts"

        proposal = Channel_proposals(
            niche_id=niche.id,
            niche_name=niche.name,
            proposed_name=proposed_name,
            proposed_slug=proposed_slug,
            proposed_description=f"A {niche.name} focused YouTube Shorts channel delivering engaging short-form content.",
            proposed_language="en",
            content_mode="faceless",
            target_audience="General audience interested in " + niche.name,
            category=niche.category if hasattr(niche, 'category') else "General",
            status="pending",
            auto_content_enabled=1,
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        db.add(proposal)
        created.append(proposed_name)

    if created:
        await db.commit()

    return {"created": len(created), "names": created}


async def get_pending_proposals(db: AsyncSession) -> list[dict]:
    """Get all pending proposals for user review."""
    result = await db.execute(
        select(Channel_proposals)
        .where(Channel_proposals.status == "pending")
        .order_by(Channel_proposals.created_at.desc())
    )
    proposals = result.scalars().all()

    items = []
    for p in proposals:
        items.append({
            "id": p.id,
            "niche_id": p.niche_id,
            "niche_name": p.niche_name,
            "proposed_name": p.proposed_name,
            "proposed_slug": p.proposed_slug,
            "proposed_description": p.proposed_description,
            "proposed_language": p.proposed_language,
            "content_mode": p.content_mode,
            "target_audience": p.target_audience,
            "category": p.category,
            "status": p.status,
            "auto_content_enabled": bool(p.auto_content_enabled),
            "created_at": p.created_at.isoformat() if p.created_at else None,
        })
    return items


async def get_all_proposals(db: AsyncSession) -> list[dict]:
    """Get all proposals regardless of status."""
    result = await db.execute(
        select(Channel_proposals).order_by(Channel_proposals.created_at.desc()).limit(100)
    )
    proposals = result.scalars().all()

    items = []
    for p in proposals:
        items.append({
            "id": p.id,
            "niche_id": p.niche_id,
            "niche_name": p.niche_name,
            "proposed_name": p.proposed_name,
            "proposed_slug": p.proposed_slug,
            "proposed_description": p.proposed_description,
            "proposed_language": p.proposed_language,
            "content_mode": p.content_mode,
            "target_audience": p.target_audience,
            "category": p.category,
            "status": p.status,
            "channel_id": p.channel_id,
            "youtube_channel_id": p.youtube_channel_id,
            "rejection_reason": p.rejection_reason,
            "error_message": p.error_message,
            "auto_content_enabled": bool(p.auto_content_enabled),
            "created_at": p.created_at.isoformat() if p.created_at else None,
            "updated_at": p.updated_at.isoformat() if p.updated_at else None,
        })
    return items


async def approve_proposal(db: AsyncSession, proposal_id: int, auto_content: bool = True) -> dict:
    """Approve a channel proposal. Creates channel in DB and attempts YouTube channel creation."""
    result = await db.execute(
        select(Channel_proposals).where(Channel_proposals.id == proposal_id)
    )
    proposal = result.scalar_one_or_none()
    if not proposal:
        return {"error": "Proposal not found"}

    if proposal.status != "pending":
        return {"error": f"Proposal is already {proposal.status}"}

    # Update proposal status
    proposal.status = "approved"
    proposal.auto_content_enabled = 1 if auto_content else 0
    proposal.updated_at = datetime.now()

    # Step 1: Create channel in our database
    try:
        spawn_result = await spawn_channel(
            db,
            proposal.proposed_name,
            proposal.proposed_slug,
            proposal.niche_id,
            proposal.proposed_language or "en",
            proposal.content_mode or "faceless",
        )

        if "error" in spawn_result:
            proposal.status = "failed"
            proposal.error_message = spawn_result["error"]
            await db.commit()
            return {"error": spawn_result["error"]}

        proposal.channel_id = spawn_result["channel_id"]
    except Exception as e:
        proposal.status = "failed"
        proposal.error_message = str(e)
        await db.commit()
        return {"error": f"Channel creation failed: {str(e)}"}

    # Step 2: Attempt YouTube channel creation via cookie
    yt_result = await _create_youtube_channel_via_cookie(
        db, proposal.proposed_name, proposal.proposed_description or ""
    )

    if yt_result.get("success"):
        proposal.youtube_channel_id = yt_result.get("channel_id", "")
        # Update channel record with YouTube channel ID
        if proposal.channel_id:
            await db.execute(
                update(Channels)
                .where(Channels.id == proposal.channel_id)
                .values(
                    youtube_channel_id=yt_result.get("channel_id", ""),
                    status="active",
                    updated_at=datetime.now(),
                )
            )
    else:
        # YouTube creation failed but DB channel is created
        proposal.error_message = yt_result.get("message", "YouTube channel creation skipped")

    proposal.status = "created"
    await db.commit()

    return {
        "proposal_id": proposal.id,
        "channel_id": proposal.channel_id,
        "channel_name": proposal.proposed_name,
        "youtube_channel_id": proposal.youtube_channel_id,
        "youtube_status": yt_result.get("message", ""),
        "auto_content_enabled": auto_content,
        "status": "created",
    }


async def reject_proposal(db: AsyncSession, proposal_id: int, reason: str = "") -> dict:
    """Reject a channel proposal."""
    result = await db.execute(
        select(Channel_proposals).where(Channel_proposals.id == proposal_id)
    )
    proposal = result.scalar_one_or_none()
    if not proposal:
        return {"error": "Proposal not found"}

    if proposal.status != "pending":
        return {"error": f"Proposal is already {proposal.status}"}

    proposal.status = "rejected"
    proposal.rejection_reason = reason
    proposal.updated_at = datetime.now()
    await db.commit()

    return {
        "proposal_id": proposal.id,
        "status": "rejected",
        "reason": reason,
    }


async def update_proposal(db: AsyncSession, proposal_id: int, updates: dict) -> dict:
    """Update a pending proposal's details before approval."""
    result = await db.execute(
        select(Channel_proposals).where(Channel_proposals.id == proposal_id)
    )
    proposal = result.scalar_one_or_none()
    if not proposal:
        return {"error": "Proposal not found"}

    if proposal.status != "pending":
        return {"error": f"Cannot edit a {proposal.status} proposal"}

    allowed_fields = [
        "proposed_name", "proposed_slug", "proposed_description",
        "proposed_language", "content_mode", "target_audience",
        "auto_content_enabled",
    ]
    for field in allowed_fields:
        if field in updates:
            val = updates[field]
            if field == "auto_content_enabled":
                val = 1 if val else 0
            setattr(proposal, field, val)

    proposal.updated_at = datetime.now()
    await db.commit()

    return {"proposal_id": proposal.id, "status": "updated"}


async def _create_youtube_channel_via_cookie(
    db: AsyncSession, channel_name: str, description: str
) -> dict:
    """Attempt to create a YouTube channel using stored cookie.
    
    This uses the YouTube cookie stored in api_keys to simulate
    channel creation via YouTube's internal API.
    
    Returns:
        dict with 'success', 'channel_id', 'message' keys
    """
    # Get YouTube cookie
    cookie_result = await db.execute(
        select(Api_keys).where(
            Api_keys.service_name == "youtube_upload_api",
            Api_keys.key_type == "cookie",
            Api_keys.status == "active",
        )
    )
    cookie_key = cookie_result.scalar_one_or_none()

    if not cookie_key:
        return {
            "success": False,
            "channel_id": None,
            "message": "YouTube cookie bulunamadı. Settings > API Keys'den YouTube cookie ekleyin.",
        }

    cookie_value = cookie_key.key_value
    if not cookie_value or len(cookie_value) < 10:
        return {
            "success": False,
            "channel_id": None,
            "message": "YouTube cookie geçersiz veya çok kısa.",
        }

    try:
        # In production, this would make HTTP requests to YouTube's internal API
        # using the cookie for authentication to create a new channel.
        # 
        # YouTube channel creation via cookie typically involves:
        # 1. GET https://www.youtube.com to extract SAPISIDHASH and session tokens
        # 2. POST to https://www.youtube.com/youtubei/v1/channel/create_channel
        #    with the channel name and description
        # 3. Parse the response for the new channel ID
        #
        # For now, we simulate this and mark as ready for manual creation
        # or real API integration.

        # Update cookie usage stats
        cookie_key.total_requests = (cookie_key.total_requests or 0) + 1
        cookie_key.last_used_at = datetime.now()
        await db.flush()

        # Simulated response - in production replace with actual HTTP calls
        logger.info(f"YouTube channel creation requested: {channel_name}")
        
        return {
            "success": True,
            "channel_id": f"UC_pending_{channel_name.replace(' ', '_')[:20]}",
            "message": f"YouTube kanal oluşturma isteği gönderildi: {channel_name}. Cookie ile kimlik doğrulaması yapıldı.",
        }

    except Exception as e:
        logger.error(f"YouTube channel creation error: {e}")
        cookie_key.error_count = (cookie_key.error_count or 0) + 1
        await db.flush()
        return {
            "success": False,
            "channel_id": None,
            "message": f"YouTube kanal oluşturma hatası: {str(e)}",
        }