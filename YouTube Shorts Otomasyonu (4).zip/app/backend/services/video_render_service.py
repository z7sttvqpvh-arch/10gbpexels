"""Video Render Service - Generates video render plans and manages the render pipeline.

Uses AI to create visual scene descriptions, stock footage search queries,
and assembles a render plan that can be executed by external tools (FFmpeg/Remotion).
"""
import logging
import json
from datetime import datetime
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.videos import Videos
from models.channels import Channels
from models.generation_jobs import Generation_jobs
from services.aihub import AIHubService
from schemas.aihub import GenTxtRequest, ChatMessage

logger = logging.getLogger(__name__)
ai_service = AIHubService()


async def generate_render_plan(db: AsyncSession, video_id: int) -> dict:
    """Generate a detailed render plan for a video including scene descriptions,
    stock footage queries, text overlays, and audio instructions."""
    result = await db.execute(select(Videos).where(Videos.id == video_id))
    video = result.scalar_one_or_none()
    if not video:
        return {"error": "Video not found"}

    if not video.script_text:
        return {"error": "Video has no script. Generate script first."}

    # Create generation job
    job = Generation_jobs(
        channel_id=video.channel_id,
        video_id=video_id,
        job_type="render_plan",
        status="running",
        priority=5,
        input_data=json.dumps({"title": video.title}),
        retry_count=0,
        max_retries=3,
        started_at=datetime.now(),
        created_at=datetime.now(),
    )
    db.add(job)
    await db.flush()

    try:
        prompt = f"""Create a detailed video render plan for this YouTube Shorts video.

Title: {video.title}
Script:
{video.script_text}

Return a JSON object with this structure:
{{
  "duration_seconds": 45,
  "scenes": [
    {{
      "scene_number": 1,
      "start_time": 0,
      "end_time": 3,
      "section": "HOOK",
      "narration_text": "exact text to speak",
      "visual_description": "what should be shown on screen",
      "stock_search_query": "search query for stock footage",
      "text_overlay": "text to show on screen or null",
      "text_position": "center/top/bottom",
      "transition": "cut/fade/zoom"
    }}
  ],
  "background_music": "upbeat electronic",
  "color_scheme": "vibrant",
  "font_style": "bold modern sans-serif"
}}

Create 5-8 scenes covering the full script. Return ONLY valid JSON, no markdown."""

        request = GenTxtRequest(
            messages=[
                ChatMessage(role="system", content="You are a video production expert. Return only valid JSON."),
                ChatMessage(role="user", content=prompt),
            ],
            model="deepseek-v3.2",
        )

        response = await ai_service.gentxt(request)
        content = response.content.strip()
        if content.startswith("```"):
            content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()

        render_plan = json.loads(content)

        # Update video with render plan
        await db.execute(
            update(Videos)
            .where(Videos.id == video_id)
            .values(
                render_path=json.dumps(render_plan),
                duration_seconds=render_plan.get("duration_seconds", 45),
                status="rendered",
                updated_at=datetime.now(),
            )
        )

        job.status = "completed"
        job.output_data = json.dumps({"scenes_count": len(render_plan.get("scenes", []))})
        job.finished_at = datetime.now()
        await db.commit()

        return {
            "video_id": video_id,
            "job_id": job.id,
            "status": "completed",
            "scenes_count": len(render_plan.get("scenes", [])),
            "duration": render_plan.get("duration_seconds", 0),
        }

    except json.JSONDecodeError as e:
        job.status = "failed"
        job.error_message = f"Invalid JSON from AI: {str(e)}"
        job.finished_at = datetime.now()
        await db.commit()
        return {"error": f"AI returned invalid render plan: {str(e)}", "job_id": job.id}
    except Exception as e:
        job.status = "failed"
        job.error_message = str(e)
        job.finished_at = datetime.now()
        await db.commit()
        return {"error": str(e), "job_id": job.id}


async def generate_thumbnail(db: AsyncSession, video_id: int) -> dict:
    """Generate a thumbnail description/prompt for a video."""
    result = await db.execute(select(Videos).where(Videos.id == video_id))
    video = result.scalar_one_or_none()
    if not video:
        return {"error": "Video not found"}

    prompt = f"""Create a YouTube Shorts thumbnail description for this video:

Title: {video.title}
Hook: {video.hook_text}

Return a JSON object:
{{
  "thumbnail_prompt": "detailed image generation prompt for the thumbnail",
  "text_overlay": "short text to overlay on thumbnail (max 5 words)",
  "color_scheme": "dominant colors",
  "style": "photorealistic/cartoon/3d/minimalist"
}}

Return ONLY valid JSON."""

    request = GenTxtRequest(
        messages=[
            ChatMessage(role="system", content="You are a YouTube thumbnail expert. Return only valid JSON."),
            ChatMessage(role="user", content=prompt),
        ],
        model="deepseek-v3.2",
    )

    response = await ai_service.gentxt(request)
    content = response.content.strip()
    if content.startswith("```"):
        content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()

    try:
        thumbnail_data = json.loads(content)
    except json.JSONDecodeError:
        thumbnail_data = {"thumbnail_prompt": content, "text_overlay": video.title[:30]}

    # Save thumbnail info
    await db.execute(
        update(Videos)
        .where(Videos.id == video_id)
        .values(thumbnail_path=json.dumps(thumbnail_data), updated_at=datetime.now())
    )
    await db.commit()

    return {"video_id": video_id, "thumbnail": thumbnail_data}


async def generate_tts_script(db: AsyncSession, video_id: int) -> dict:
    """Extract narration segments from the render plan for TTS processing."""
    result = await db.execute(select(Videos).where(Videos.id == video_id))
    video = result.scalar_one_or_none()
    if not video:
        return {"error": "Video not found"}

    if not video.render_path:
        return {"error": "No render plan found. Generate render plan first."}

    try:
        render_plan = json.loads(video.render_path)
    except json.JSONDecodeError:
        return {"error": "Invalid render plan data"}

    scenes = render_plan.get("scenes", [])
    narration_segments = []
    for scene in scenes:
        if scene.get("narration_text"):
            narration_segments.append({
                "scene_number": scene["scene_number"],
                "text": scene["narration_text"],
                "start_time": scene.get("start_time", 0),
                "end_time": scene.get("end_time", 0),
            })

    full_narration = " ".join([s["text"] for s in narration_segments])

    return {
        "video_id": video_id,
        "segments": narration_segments,
        "full_narration": full_narration,
        "total_segments": len(narration_segments),
    }